package com.jingxi.smartlife.pad.util;

import java.util.Map;

/**
 * Created by Administrator on 2017/5/5.
 */

public final class ConfigUtil {
    static {
        System.loadLibrary("pad_pros");
    }

//    public static final String BASE_URL = "http://api.house-keeper.cn/";
    public static final String BASE_URL = "http://openapi.house-keeper.cn/";
    public static String OSS_ENDPOINT = "http://oss-cn-shanghai.aliyuncs.com";
    public static String OSS_PATH = "http://image.house-keeper.cn/";
    public static String OSS_BUCKET_NAME = "smartlife-images";
    public static String ALI_ACCESSKEYID = "LTAIVfeAmu8GNe6R";
    public static String ALI_ACCESSKEYSECRET = "G4tvR1nIaXiGTme6ln0wvqhQDl4Ejy";

    public static native String decode(String source);

    public static native String encodeForHttp(Map<String, String> map, String token);
}
