package com.jingxi.smartlife.pad.sdk.push;

public class PushManagerImpl implements PushManager{

    /**
     *
     */
    public PushManagerImpl(){
        AliPushUtil.getInstance();
    }

    @Override
    public void addCallback(OnPushedListener listener) {
        AliPushUtil.getInstance().addListener(listener);
    }

    @Override
    public void removeCallback(OnPushedListener listener) {
        AliPushUtil.getInstance().removeListener(listener);
    }

    @Override
    public void bindAccount(String accid) {
        AliPushUtil.getInstance().bindAccount(accid);
    }

    @Override
    public void unBindAccount() {
        AliPushUtil.getInstance().unbindAccount();
    }

    @Override
    public void bindTags(String accid,String... tags) {
        AliPushUtil.getInstance().bindTag(accid,tags);
    }

    @Override
    public void unBindTags(String... tag) {
        AliPushUtil.getInstance().unbindTags(tag);
    }

    @Override
    public void unBindAllTags() {
        AliPushUtil.getInstance().unbindAllTag();
    }
}
