package com.jingxi.smartlife.pad.sdk;

import android.app.Application;

import com.jingxi.smartlife.pad.sdk.doorAccess.DoorAccessManager;
import com.jingxi.smartlife.pad.sdk.neighbor.NeighborManager;
import com.jingxi.smartlife.pad.sdk.neighbor.NeighborManagerImpl;
import com.jingxi.smartlife.pad.sdk.push.PushManager;
import com.jingxi.smartlife.pad.sdk.push.PushManagerImpl;
import com.jingxi.smartlife.pad.sdk.utils.JXContextWrapper;

public final class JXPadSdk {
    private static DoorAccessManager doorAccessManager;
    private static NeighborManager neighborManager;
    private static PushManager pushManager;

    /**
     * 保存一个Application的引用
     * @param application
     */
    public static void init(Application application){
        JXContextWrapper.context = application;
    }

    /**
     * 保存当前登录信息
     * @param appKey
     * @param accessToken
     */
    public static void setAppKey(String appKey,String accessToken){
        JXContextWrapper.appKey = appKey;
        JXContextWrapper.accessToken = accessToken;
    }

    /**
     * 保存当前的语言,切换系统语言后需要调用这个方法更新
     * @param lang
     */
    public static void setLang(String lang){
        JXContextWrapper.lang = lang;
    }

    /**
     * 保存当前的社区id
     * @param communityId
     */
    public static void setCommunityId(String communityId){
        JXContextWrapper.communityId = communityId;
    }

    /**
     * 保存当前的家庭id
     * @param familyInfoId
     */
    public static void setFamilyInfoId(String familyInfoId){
        JXContextWrapper.familyInfoId = familyInfoId;
    }

    /**
     * 登录接口返回的  padAccid  字段
     * @param accid
     */
    public static void setAccid(String accid){
        JXContextWrapper.accid = accid;
    }

    /**
     * 初始化门禁服务
     */
    public static void initDoorAccess(){
        doorAccessManager = DoorAccessManager.getInstance();
    }

    /**
     * 初始化邻里墙
     */
    public static void initNeighbor(){
        neighborManager = new NeighborManagerImpl();
    }

    /**
     * 初始化推送模块
     */
    public static void initPushManager(){
        pushManager = new PushManagerImpl();
    }

    public static DoorAccessManager getDoorAccessManager(){
        return doorAccessManager;
    }

    public static NeighborManager getNeighborManager(){
        return neighborManager;
    }

    public static PushManager getPushManager(){
        return pushManager;
    }
}
