package com.jingxi.smartlife.pad.sdk.network;

public class BaseEntry {

    public boolean result;

    public String msg;

    public int code;

    /**
     * JSONObject or JSONArray
     */
    public String content;

    public String totalSize;
}
