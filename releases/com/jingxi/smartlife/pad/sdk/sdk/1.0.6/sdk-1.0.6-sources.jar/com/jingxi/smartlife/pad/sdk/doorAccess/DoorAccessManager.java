//package com.jingxi.smartlife.pad.sdk.doorAccess;
//
//import android.view.SurfaceView;
//
//import com.intercom.sdk.IntercomObserver;
//import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorDevice;
//import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorRecordBean;
//import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.DoorAccessConversationUI;
//import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.DoorAccessListUI;
//import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.DoorAccessListener;
//
//import java.util.List;
//
//public interface DoorAccessManager {
//
//    /**
//     * 设备列表页面时监听设备变化
//     * @param listener
//     */
//    void setListUIListener(DoorAccessListUI listener);
//
//    /**
//     * 会话页面时监听新事件
//     * @param listener
//     */
//    void setConversationUIListener(DoorAccessConversationUI listener);
//
//    /**
//     * 监听开锁和呼叫事件
//     * @param listener
//     */
//    void setDoorAccessListener(DoorAccessListener listener);
//
//    /**
//     *
//     * @param familyID      初始化对应的门禁
//     * @param buttonKey
//     */
//    void initAccess(String familyID,String buttonKey);
//
//    /**
//     *
//     * @param familyID      反初始化对应的门禁
//     */
//    void unInitAccess(String familyID);
//
//    /**
//     * 获取所有在线的设备
//     * @return
//     */
//    List<DoorDevice> getDevices(String familyID);
//
//    /**
//     * 获取设备在线状态
//     */
//    void checkDeviceOnline(String familyID);
//
//    /**
//     * 外呼
//     * @return sessionId
//     */
//    String monitor(String familyID,DoorDevice doorDevice);
//
//    /**
//     * 接听呼叫
//     */
//    void acceptCall(String sessionId);
//
//    /**
//     * 挂断呼叫
//     */
//    void hangupCall(String sessionId);
//
//    /**
//     * 更新门禁呼叫视图
//     * @param surfaceView
//     */
//    void updateCallWindow(String sessionId,SurfaceView surfaceView);
//
//    /**
//     * 获取回放列表
//     * @param type {@link DoorRecordBean#RECORD_TYPE_DOOR} or {@link DoorRecordBean#RECORD_TYPE_P2P}
//     * @param pageStart     数据的起始下标 0 ...{n}
//     * @param pageSize      每次获取到的数据量
//     */
//    List<DoorRecordBean> getHistoryList(String familyID,@DoorRecordBean.RECORD_TYPE int type,int pageStart,int pageSize);
//
//    /**
//     * 开始回放
//     */
//    void startPlayBack(String sessionId);
//
//    /**
//     * 暂停回放
//     */
//    void pausePlayBack(String sessionId);
//
//    /**
//     * 调整回放进度
//     */
//    void seekPlayBack(String sessionId,int seek);
//
//    /**
//     * 更新回放视图
//     * @param surfaceView
//     */
//    void updatePlayBackWindow(String sessionId,SurfaceView surfaceView);
//
//    /**
//     * 回放记录的监听
//     * @param onPlaybackListener
//     */
//    void addPlayBackListener(IntercomObserver.OnPlaybackListener onPlaybackListener);
//
//    /**
//     * 删除回放监听
//     * @param onPlaybackListener
//     */
//    void removePlayBackListener(IntercomObserver.OnPlaybackListener onPlaybackListener);
//}
