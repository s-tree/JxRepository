package com.jingxi.smartlife.pad.sdk.neighbor;

import com.jingxi.smartlife.pad.sdk.network.BaseEntry;

import java.util.List;

import io.reactivex.Observable;

public interface NeighborManager {
    String NEIGHBOR_TYPE_CHAT = "chat";
    String NEIGHBOR_TYPE_ACTIVITY = "event";
    String NEIGHBOR_TYPE_HELP = "support";
    String NEIGHBOR_TYPE_SELL = "swapping";

    /**
     * 发布一个新的邻里墙
     * @param content
     * @param boardType
     * @param imageList
     * @param originalPrice
     * @param price
     * @param deadline
     * @param activityInfo
     * @return
     */
    Observable<BaseEntry> uploadNewNeighbor(String content, final String boardType, List<String> imageList,
                                            String originalPrice, String price, String deadline, String activityInfo);

    /**
     * 获取邻里墙类型
     */
    Observable<BaseEntry> queryNeighborBoardTypeList();

    /**
     * 获取邻里墙列表
     * @param typeId 邻里墙type ,全部则为空
     * @param otherAccId 要查询邻里墙的accid
     */
    Observable<BaseEntry> getNeighborBoardList(String typeId, String pageIndex, String otherAccId);

    /**
     * 社区新鲜事点赞接口
     *
     * @param neighborBoardId 社区新鲜事Id
     * @param isFavour        点赞或取消赞
     **/
    Observable<BaseEntry> updateFavour(String neighborBoardId, boolean isFavour);

    /**
     * 社区新鲜事删除接口
     *
     * @param neighborBoardId 社区新鲜事Id
     **/
    Observable<BaseEntry> deleteNeighborBoard(String neighborBoardId);

    /**
     * 获取单条社区新鲜事刷新
     *
     * @param neighborBoardId 社区新鲜事Id
     **/
    Observable<BaseEntry> getNeighborBoardInfo(String neighborBoardId);

    /**
     * 查询社区新鲜事用户信息
     *
     * @param userAccid 要查询的用户信息
     */
    Observable<BaseEntry> getNeighborBoardMemberInfo(String userAccid);

    /**
     * 举报
     *
     * @param neighborBoardId 社区新鲜事id
     * @param content         举报内容
     */
    Observable<BaseEntry> reportNeighborhood(String neighborBoardId, String content);

    /**
     * 参加活动
     *
     * @param neighborBoardId 社区新鲜事id
     * @param name            姓名
     * @param mobile          电话
     * @param building        楼号
     */
    Observable<BaseEntry> joinActivity(String neighborBoardId, String name, String mobile, String building);

    /**
     * 查询社区新鲜事回复列表
     *
     * @param neighborBoardId 社区新鲜事id
     * @param pageIndex
     */
    Observable<BaseEntry> queryNeighborBoardReply(String neighborBoardId, int pageIndex);

    /**
     * 获取左边所有我的信息列表
     *
     * @param scene 我的消息:notice,我的赞:favour,我参加的活动:activity
     */
    Observable<BaseEntry> getAboutMeNeighborList(String scene, String pageIndex);

    /**
     * 回复社区新鲜事
     *
     * @param neighborBoardId 社区新鲜事id
     * @param replyId
     * @param content
     */
    Observable<BaseEntry> sendReply(String neighborBoardId, String replyId, String content);

    /**
     * 获取社区新鲜事消息通知
     *
     * @param pageIndex 页码
     */
    Observable<BaseEntry> queryNeighborBoardNotice(int pageIndex);

    /**
     * 停止活动的报名
     *
     * @param neighborBoardId 社区新鲜事Id
     */
    Observable<BaseEntry> terminationActivityJoin(String neighborBoardId);

    /**
     * 获取已报名的用户
     *
     * @param neighborBoardId 社区新鲜事id
     */
    Observable<BaseEntry> getActivityMember(String neighborBoardId);

    /**
     * 查询邻里墙动态总数
     * @return
     */
    Observable<BaseEntry> getCountNeighborBoardNotice();
}