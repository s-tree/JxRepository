package com.jingxi.smartlife.pad.sdk.push;

import android.content.Context;

import com.alibaba.sdk.android.push.MessageReceiver;
import com.alibaba.sdk.android.push.notification.CPushMessage;

import java.util.Map;

/**
 * Created by Administrator on 2017/6/26.
 */

public class JXPushReceiver extends MessageReceiver {

    @Override
    public void onNotification(Context context, String title, String summary, Map<String, String> extraMap) {
    }

    @Override
    public void onMessage(Context context, CPushMessage cPushMessage) {
        String content = cPushMessage.getContent();
        AliPushUtil.getInstance().notifyMessage(content);
    }

    @Override
    public void onNotificationOpened(Context context, String title, String summary, String extraMap) {
    }

    @Override
    protected void onNotificationClickedWithNoAction(Context context, String title, String summary, String extraMap) {
    }

    @Override
    protected void onNotificationReceivedInApp(Context context, String title, String summary, Map<String, String> extraMap, int openType, String openActivity, String openUrl) {
    }

    @Override
    protected void onNotificationRemoved(Context context, String messageId) {
    }
}
