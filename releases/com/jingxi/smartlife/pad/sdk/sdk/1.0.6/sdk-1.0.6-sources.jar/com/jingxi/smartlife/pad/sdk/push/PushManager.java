package com.jingxi.smartlife.pad.sdk.push;

public interface PushManager {

    /**
     * 监听消息的回调
     */
    void addCallback(OnPushedListener listener);
    /**
     * 删除回调
     */
    void removeCallback(OnPushedListener listener);
    /**
     * 绑定账号
     * @param accid
     */
    void bindAccount(String accid);

    /**
     * 解绑账号
     */
    void unBindAccount();

    /**
     * 批量绑定标签
     * @param tags
     */
    void bindTags(String accid,String... tags);

    /**
     * 批量解绑标签
     * @param tags
     */
    void unBindTags(String... tags);

    /**
     * 解绑所有标签
     */
    void unBindAllTags();

}
