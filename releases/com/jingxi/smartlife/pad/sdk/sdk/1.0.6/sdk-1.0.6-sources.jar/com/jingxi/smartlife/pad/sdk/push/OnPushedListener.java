package com.jingxi.smartlife.pad.sdk.push;

public interface OnPushedListener {

    void onReceiverMessage(String content);
}
