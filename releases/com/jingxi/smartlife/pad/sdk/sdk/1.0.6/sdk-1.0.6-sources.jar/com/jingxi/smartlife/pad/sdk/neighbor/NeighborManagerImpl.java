package com.jingxi.smartlife.pad.sdk.neighbor;

import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.jingxi.smartlife.pad.sdk.network.BaseEntry;
import com.jingxi.smartlife.pad.sdk.network.NetWorkManager;
import com.jingxi.smartlife.pad.sdk.utils.JXContextWrapper;
import com.jingxi.smartlife.pad.util.PadHttpParams;

import java.util.List;

import io.reactivex.Observable;

public class NeighborManagerImpl implements NeighborManager {
    public NeighborManagerImpl() {
    }

    public final static int PAGESIZE = 20;

    /**
     * 获取楼列表
     * type 为  {@link NeighborManager#NEIGHBOR_TYPE_CHAT} 和 {@link NeighborManager#NEIGHBOR_TYPE_HELP} 时 只需要传 content,boardType
     * type 为  {@link NeighborManager#NEIGHBOR_TYPE_ACTIVITY} 时 需要传 deadline,activityInfo
     * type 为  {@link NeighborManager#NEIGHBOR_TYPE_SELL} 时 需要传 originalPrice,price
     * imageList 如果有就传，没有就不传
     * 不需要传的参数为空
     *
     * @param content       发布内容
     * @param boardType     社区新鲜事分类
     * @param imageList     图片集合
     * @param originalPrice 原价
     * @param price         现价
     * @param deadline      活动报名截止时间
     * @param activityInfo  活动详情
     */
    @Override
    public Observable<BaseEntry> uploadNewNeighbor(String content, final String boardType, List<String> imageList, String originalPrice, String price, String deadline, String activityInfo){
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put(PadHttpParams.PublicKey.ACCID, JXContextWrapper.accid);
        map.put(PadHttpParams.PublicKey.COMMUNITYID, JXContextWrapper.communityId);
        map.put(PadHttpParams.PublicKey.CONTENT, content);
        map.put(PadHttpParams.NeighborHood.Key.BOARDTYPE, boardType);
        if(imageList != null && imageList.size() > 0){
            StringBuilder result = new StringBuilder();
            for (String each : imageList) {
                if(result.length() != 0){
                    result.append(",");
                }
                result.append(each);
            }
            map.put(PadHttpParams.PublicKey.IMAGES, result.toString());
        }
        if (!TextUtils.isEmpty(originalPrice)) {
            map.put(PadHttpParams.NeighborHood.Key.ORIGINAL_PRICE, originalPrice);
        }
        if (!TextUtils.isEmpty(price)) {
            map.put(PadHttpParams.NeighborHood.Key.PRICE, price);
        }
        if (!TextUtils.isEmpty(deadline)) {
            map.put(PadHttpParams.NeighborHood.Key.DEAD_LINE, deadline);
        }
        if (!TextUtils.isEmpty(activityInfo)) {
            map.put(PadHttpParams.NeighborHood.Key.ACTIVITY_INFO, activityInfo);
        }
        return NetWorkManager.post(NetMethods.UPLOAD_NEW_NEIGHBORHOOD,map);
    }

    @Override
    public Observable<BaseEntry> queryNeighborBoardTypeList() {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put(PadHttpParams.PublicKey.COMMUNITYID, JXContextWrapper.communityId);
        return NetWorkManager.post(NetMethods.QUERY_NEIGHBOR_TYPE,map);
    }

    @Override
    public Observable<BaseEntry> getNeighborBoardList(String typeId, String pageIndex, String otherAccId) {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put(PadHttpParams.PublicKey.ACCID, JXContextWrapper.accid);
        map.put(PadHttpParams.PublicKey.COMMUNITYID, JXContextWrapper.communityId);
        map.put(PadHttpParams.PublicKey.OTHERACCID, otherAccId);
        map.put(PadHttpParams.PublicKey.PAGEINDEX, pageIndex);
        map.put(PadHttpParams.PublicKey.PAGESIZE, String.valueOf(PAGESIZE));
        if (!TextUtils.isEmpty(typeId)) {
            map.put(PadHttpParams.NeighborHood.Key.TYPEID, typeId);
        }
        return NetWorkManager.post(NetMethods.QUERY_NEIGHBOR_LIST,map);
    }

    @Override
    public Observable<BaseEntry> updateFavour(String neighborBoardId, boolean isFavour) {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put(PadHttpParams.PublicKey.ACCID, JXContextWrapper.accid);
        map.put(PadHttpParams.NeighborHood.Key.NEIGHBORBOARDID, neighborBoardId);
        map.put(PadHttpParams.NeighborHood.Key.ISFAVOUR, String.valueOf(isFavour));
        return NetWorkManager.post(NetMethods.FAVOUR_NEIGHBOR,map);
    }

    @Override
    public Observable<BaseEntry> deleteNeighborBoard(String neighborBoardId) {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put(PadHttpParams.NeighborHood.Key.NEIGHBORBOARDID, neighborBoardId);
        return NetWorkManager.post(NetMethods.REMOVE_NEIGHBOR,map);
    }

    @Override
    public Observable<BaseEntry> getNeighborBoardInfo(String neighborBoardId) {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put(PadHttpParams.PublicKey.ACCID, JXContextWrapper.accid);
        map.put(PadHttpParams.NeighborHood.Key.NEIGHBORBOARDID, neighborBoardId);
        return NetWorkManager.post(NetMethods.QUERY_DETAIL_NEIGHBOR,map);
    }

    @Override
    public Observable<BaseEntry> getNeighborBoardMemberInfo(String userAccid) {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put(PadHttpParams.PublicKey.ACCID, userAccid);
        map.put(PadHttpParams.PublicKey.COMMUNITYID, JXContextWrapper.communityId);
        return NetWorkManager.post(NetMethods.QUERY_USER_NEIGHBOR,map);
    }

    @Override
    public Observable<BaseEntry> reportNeighborhood(String neighborBoardId, String content) {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put(PadHttpParams.NeighborHood.Key.NEIGHBORBOARDID, neighborBoardId);
        map.put(PadHttpParams.PublicKey.ACCID, JXContextWrapper.accid);
        map.put(PadHttpParams.PublicKey.CONTENT, content);
        return NetWorkManager.post(NetMethods.REPORT_NEIGHBOR,map);
    }

    @Override
    public Observable<BaseEntry> joinActivity(String neighborBoardId, String name, String mobile, String building) {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put(PadHttpParams.NeighborHood.Key.NEIGHBORBOARDID, neighborBoardId);
        map.put(PadHttpParams.PublicKey.ACCID, JXContextWrapper.accid);
        map.put(PadHttpParams.PublicKey.NAME, name);
        map.put(PadHttpParams.PublicKey.MOBILE, mobile);
        map.put(PadHttpParams.PublicKey.BUILDING, building);
        return NetWorkManager.post(NetMethods.JOIN_ACTIVITY,map);
    }

    @Override
    public Observable<BaseEntry> queryNeighborBoardReply(String neighborBoardId, int pageIndex) {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put(PadHttpParams.PublicKey.ACCID, JXContextWrapper.accid);
        map.put(PadHttpParams.NeighborHood.Key.NEIGHBORBOARDID, neighborBoardId);
        map.put(PadHttpParams.PublicKey.PAGEINDEX, String.valueOf(pageIndex));
        map.put(PadHttpParams.NeighborHood.Key.ISHOST, PadHttpParams.PublicValue.FALSE);
        return NetWorkManager.post(NetMethods.QUERY_NEIGHBOR_REPLYS,map);
    }

    @Override
    public Observable<BaseEntry> getAboutMeNeighborList(String scene, String pageIndex) {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put(PadHttpParams.PublicKey.ACCID, JXContextWrapper.accid);
        map.put(PadHttpParams.PublicKey.COMMUNITYID, JXContextWrapper.communityId);
        map.put(PadHttpParams.PublicKey.PAGEINDEX, pageIndex);
        map.put(PadHttpParams.PublicKey.PAGESIZE, String.valueOf(PAGESIZE));
        map.put(PadHttpParams.PublicKey.SCENE, scene);
        return NetWorkManager.post(NetMethods.QUERY_NEIGHBOR_LIST,map);
    }

    @Override
    public Observable<BaseEntry> sendReply(String neighborBoardId, String replyId, String content) {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put(PadHttpParams.PublicKey.ACCID, JXContextWrapper.accid);
        map.put(PadHttpParams.NeighborHood.Key.NEIGHBORBOARDID, neighborBoardId);
        if (!TextUtils.isEmpty(replyId)) {
            map.put(PadHttpParams.NeighborHood.Key.REPLYID, replyId);
        }
        map.put(PadHttpParams.PublicKey.CONTENT, content);
        return NetWorkManager.post(NetMethods.SEND_REPLY,map);
    }

    @Override
    public Observable<BaseEntry> queryNeighborBoardNotice(int pageIndex) {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put(PadHttpParams.PublicKey.ACCID, JXContextWrapper.accid);
        map.put(PadHttpParams.PublicKey.PAGEINDEX, String.valueOf(pageIndex));
        map.put(PadHttpParams.PublicKey.SCENE, PadHttpParams.NeighborHood.Value.SCENE_NOTICE);
        return NetWorkManager.post(NetMethods.QUERY_NEIGHBOR_NOTICES,map);
    }

    @Override
    public Observable<BaseEntry> terminationActivityJoin(String neighborBoardId) {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put(PadHttpParams.NeighborHood.Key.NEIGHBORBOARDID, neighborBoardId);
        return NetWorkManager.post(NetMethods.STOP_ACTIVITY,map);
    }

    @Override
    public Observable<BaseEntry> getActivityMember(String neighborBoardId) {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put(PadHttpParams.NeighborHood.Key.NEIGHBORBOARDID, neighborBoardId);
        return NetWorkManager.post(NetMethods.QUERY_ACTIVITY_MEMBER,map);
    }

    @Override
    public Observable<BaseEntry> getCountNeighborBoardNotice() {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put(PadHttpParams.PublicKey.ACCID, JXContextWrapper.accid);
        return NetWorkManager.post(NetMethods.QUERY_NEIGHBOR_NOTICES_COUNT,map);
    }
}
