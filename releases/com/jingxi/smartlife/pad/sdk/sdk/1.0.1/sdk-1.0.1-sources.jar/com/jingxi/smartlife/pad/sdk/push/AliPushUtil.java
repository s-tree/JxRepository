package com.jingxi.smartlife.pad.sdk.push;

import android.text.TextUtils;

import com.alibaba.sdk.android.push.CloudPushService;
import com.alibaba.sdk.android.push.CommonCallback;
import com.alibaba.sdk.android.push.noonesdk.PushServiceFactory;
import com.jingxi.smartlife.pad.sdk.utils.JXContextWarpper;
import com.jingxi.smartlife.pad.sdk.utils.JXLogUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/8/11.
 */

public class AliPushUtil {

    public static final int TAG_BIND_WITH_DEVICE = 1;
    public static final int TAG_BIND_WITH_ACCOUNT = 2;

    private static final String TAG = "AliPushUtil";
    private List<OnPushedListener> listeners = new ArrayList<>();

    private static AliPushUtil pushUtil;
    protected static AliPushUtil getInstance(){
        if(pushUtil == null){
            synchronized (AliPushUtil.class){
                if(pushUtil == null){
                    pushUtil = new AliPushUtil();
                }
            }
        }
        return pushUtil;
    }

    private AliPushUtil(){
        PushServiceFactory.init(JXContextWarpper.context);
        CloudPushService pushService = PushServiceFactory.getCloudPushService();
        pushService.register(JXContextWarpper.context, new CommonCallback() {
            @Override
            public void onSuccess(String response) {
                JXLogUtil.logW(TAG, "init success ");
            }

            @Override
            public void onFailed(String errorCode, String errorMessage) {
                JXLogUtil.logW(TAG, "init faild errorCode = " + errorCode + " errorMessage = " + errorMessage);
            }
        });
    }

    protected void addListener(OnPushedListener listener){
        if(listeners.contains(listener)){
            return;
        }
        listeners.add(listener);
    }

    protected void removeListener(OnPushedListener listener){
        if(!listeners.contains(listener)){
            return;
        }
        listeners.remove(listener);
    }

    protected void bindTag(String accid,String[] tag){
        PushServiceFactory.getCloudPushService().bindTag(
                TAG_BIND_WITH_DEVICE,
                tag,
                accid,
                new CommonCallback() {
                    @Override
                    public void onSuccess(String s) {
                        JXLogUtil.logW(TAG, "bindTag success ");
                    }

                    @Override
                    public void onFailed(String s, String s1) {
                        JXLogUtil.logW(TAG, "bindTag faild " + s + "  " + s1);
                    }
                });
    }

    protected void unbindAllTag(){
        PushServiceFactory.getCloudPushService().listTags(TAG_BIND_WITH_DEVICE, new CommonCallback() {
            @Override
            public void onSuccess(String s) {
                JXLogUtil.logW(TAG ," success PUSH listTag = " + s);
                if(TextUtils.isEmpty(s)){
                   return;
                }
                unbindTags(s.split(","));
            }

            @Override
            public void onFailed(String s, String s1) {
                JXLogUtil.logW(TAG," faild PUSH listTag = " + s);
            }
        });
    }

    protected void unbindTags(String... tags){
        PushServiceFactory.getCloudPushService().unbindTag(TAG_BIND_WITH_DEVICE,tags,null,doNothingCallBack);
    }

    private CommonCallback unbindAccountCallback = new CommonCallback() {
        @Override
        public void onSuccess(String s) {
            JXLogUtil.logW(TAG,"unbind account success " + s);
        }

        @Override
        public void onFailed(String s, String s1) {
            JXLogUtil.logW(TAG,"unbind account faild " + s + " , " + s1);
        }
    };

    private CommonCallback doNothingCallBack = new CommonCallback() {
        @Override
        public void onSuccess(String s) {
            JXLogUtil.logW(TAG,"unbind tag success " + s);
        }

        @Override
        public void onFailed(String s, String s1) {
            JXLogUtil.logW(TAG,"unbind tag faild " + s + " , " + s1);
        }
    };

    protected void bindAccount(String account){
        PushServiceFactory.getCloudPushService().bindAccount(account, new CommonCallback() {
            @Override
            public void onSuccess(String s) {
                JXLogUtil.logW(TAG,"bindAccount success " + s);
            }

            @Override
            public void onFailed(String s, String s1) {
                JXLogUtil.logW(TAG,"bindAccount faild " + s + " , " + s1);
            }
        });
    }

    protected void unbindAccount(){
        PushServiceFactory.getCloudPushService().unbindAccount(unbindAccountCallback);
    }

    protected void notifyMessage(String message){
        if(listeners.isEmpty()){
            return;
        }
        List<OnPushedListener> tempListeners = new ArrayList<>(listeners);
        for(OnPushedListener listener : tempListeners){
            listener.onReceiverMessage(message);
        }
    }
}
