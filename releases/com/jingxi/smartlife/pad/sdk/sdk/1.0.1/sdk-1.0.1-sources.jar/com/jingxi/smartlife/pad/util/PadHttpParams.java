package com.jingxi.smartlife.pad.util;

/**
 * Created by Administrator on 2018/5/16.
 */

public interface PadHttpParams {
    interface PublicKey {
        String EMPTY = "";
        String METHOD = "methodName";
        String COMMUNITYID = "communityId";
        String FAMILYMEMBERID = "familyMemberId";
        String FAMILYINFOID = "familyInfoId";
        String FAMILYACCID = "familyAccId";
        String TIME_STAMP = "timestamp";
        String ACCID = "accId";
        String PAGEINDEX = "pageIndex";
        String PAGESIZE = "pageSize";
        String ID = "id";
        String TYPE = "type";
        String BUILDNO = "buildNo";
        String REMARK = "remark";
        String OWNERACCID = "ownerAccId";
        String DATE = "date";
        String CONTENT = "content";
        String IMAGES = "images";
        String OTHERACCID = "otherAccId";
        String MOBILE = "mobile";
        String BUILDING = "building";
        String SCENE = "scene";
        String RESULT = "result";
        String MSG = "msg";
        String PadSN = "padSn";
        String NAME = "name";
        String HEADIMG = "headImg";
        String FAMILY_NICKNAME = "familyNickName";
        String OWNER_MOBILE = "ownerMobile";
        String BUILDING_INFO = "buildingInfoId";
        String PHOTO_URL = "photoUrl";
        String DEVICE_TYPE = "deviceType";
        String DEVICE_NAME = "deviceName";
        String ISSHOW = "isShow";
        String APPKEY = "appKey";
        String ACCESSTOKEN = "accessToken";
        String ADDRESS = "address";
        String FAMILY_ID = "familyId";
    }

    interface PublicValue {
        String FALSE = "false";
        String TRUE = "true";
        String TYPE_CLASS = "class";
        String TYPE_PAD = "pad";
    }


    interface NeighborHood {
        interface Key {
            String BOARDTYPE = "boardType";
            String TYPEID = "typeId";
            String NEIGHBORBOARDID = "neighborBoardId";
            String ISFAVOUR = "isFavour";
            String ISHOST = "isHot";
            String REPLYID = "replyId";
            String ORIGINAL_PRICE = "originalPrice";
            String PRICE = "price";
            String DEAD_LINE = "deadline";
            String ACTIVITY_INFO = "activityInfo";
            String NEIGHBOR_TYPE_ID = "neighborBoardTypeId";
            String LANG = "lang";
        }

        interface Value {
            String SCENE_NOTICE = "notice";
            String SCENE_FAVOUR = "favour";
            String SCENE_ACTIVITY = "activity";
        }
    }

    interface Door {
        interface Key {
            String DOCK_SN = "dockerSn";
            String ROOM_INFO = "roomInfo";
            String SSID = "ssid";
            String P2P_SESSION = "p2pSessionID";
            String P2P_RESULT = "p2pResult";
        }
    }

}
