package com.jingxi.smartlife.pad.sdk.neighbor;

public interface NetMethods {

    /**
     * 发布邻里墙
     */
    String UPLOAD_NEW_NEIGHBORHOOD = "api/v2/boardServer/neighborRest/sendNeighborBoard";

    /**
     * 查询邻里墙类型
     */
    String QUERY_NEIGHBOR_TYPE = "api/v2/boardServer/neighborRest/queryNeighborBoardTypeList";

    /**
     * 获取邻里墙列表
     */
    String QUERY_NEIGHBOR_LIST = "api/v2/boardServer/neighborRest/queryNeighborBoardList";

    /**
     * 邻里墙点赞
     */
    String FAVOUR_NEIGHBOR = "api/v2/boardServer/neighborRest/favourNeighborBoard";

    /**
     * 删除邻里墙
     */
    String REMOVE_NEIGHBOR = "api/v2/boardServer/neighborRest/removeNeighborBoard";

    /**
     * 查询邻里墙详情
     */
    String QUERY_DETAIL_NEIGHBOR = "api/v2/boardServer/neighborRest/queryNeighborBoardInfo";

    /**
     * 查询用户所发的邻里墙
     */
    String QUERY_USER_NEIGHBOR = "api/v2/boardServer/neighborRest/getNeighborBoardMemberInfo";

    /**
     * 举报邻里墙
     */
    String REPORT_NEIGHBOR = "api/v2/boardServer/neighborRest/reportNeighborhood";

    /**
     * 加入活动
     */
    String JOIN_ACTIVITY = "api/v2/boardServer/neighborRest/joinActivity";

    /**
     * 查询邻里墙回复列表
     */
    String QUERY_NEIGHBOR_REPLYS = "api/v2/boardServer/neighborRest/queryNeighborBoardReply";

    /**
     * 发送评论
     */
    String SEND_REPLY = "api/v2/boardServer/neighborRest/sendReply";

    /**
     * 查询邻里墙的动态通知
     */
    String QUERY_NEIGHBOR_NOTICES = "api/v2/boardServer/neighborRest/queryNeighborBoardNotice";

    /**
     * 停止活动报名
     */
    String STOP_ACTIVITY = "api/v2/boardServer/neighborRest/terminationActivityJoin";

    /**
     * 查询已报名的用户
     */
    String QUERY_ACTIVITY_MEMBER = "api/v2/boardServer/neighborRest/getActivityMember";

    /**
     * 查询邻里墙动态总数
     */
    String QUERY_NEIGHBOR_NOTICES_COUNT = "api/v2/boardServer/neighborRest/countNeighborBoardNotice";
}
