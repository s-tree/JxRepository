package com.jingxi.smartlife.pad.sdk.network;

import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.jingxi.smartlife.pad.sdk.utils.JXContextWrapper;
import com.jingxi.smartlife.pad.sdk.utils.JXLogUtil;
import com.jingxi.smartlife.pad.util.ConfigUtil;
import com.jingxi.smartlife.pad.util.PadHttpParams;

import java.util.SortedMap;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Function;
import io.reactivex.functions.Predicate;
import io.reactivex.schedulers.Schedulers;
import okhttp3.Call;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class NetWorkManager {

    private static OkHttpClient httpClient;

    static {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        builder.connectTimeout(6, TimeUnit.SECONDS);
        builder.hostnameVerifier(new HostnameVerifier() {
            @Override
            public boolean verify(String s, SSLSession sslSession) {
                return true;
            }
        });
        httpClient = builder.build();
    }

    public static Observable<BaseEntry> get(String method, ArrayMap<String,String> params){
        Request.Builder builder = new Request.Builder();
        builder.get().url(appendGetUrl(method,params));
        return buildObservable(builder.build());
    }

    public static Observable<BaseEntry> post(String method,ArrayMap<String,String> params){
        if(TextUtils.isEmpty(JXContextWrapper.appKey)
                || TextUtils.isEmpty(JXContextWrapper.accessToken)){
            JXLogUtil.logW("HTTP FAILD : JXPadSDK.setAppKey() is not called");
            return buildEmptyObserver();
        }
        Request.Builder builder = new Request.Builder();
        builder.url(TextUtils.concat(ConfigUtil.BASE_URL,method).toString())
                .post(buildPostParams(params, JXContextWrapper.appKey, JXContextWrapper.accessToken));
        return buildObservable(builder.build());
    }

    private static final String appendGetUrl(String method,ArrayMap<String,String> params){
        StringBuilder builder = new StringBuilder();
        builder.append(ConfigUtil.BASE_URL);
        builder.append(method);
        builder.append("?");
        boolean isFirst = true;
        for(String key : params.keySet()){
            if(!isFirst){
                builder.append("&");
            }else{
                isFirst = false;
            }
            builder.append(key);
            builder.append("=");
            builder.append(params.get(key));
        }
        return builder.toString();
    }

    private static final FormBody buildPostParams(ArrayMap<String,String> params, String appKey, String accessToken){
        params.put(PadHttpParams.PublicKey.APPKEY,appKey);
        params.put(PadHttpParams.PublicKey.ACCESSTOKEN, accessToken);
        params.put(PadHttpParams.PublicKey.TIME_STAMP,String.valueOf(System.currentTimeMillis()));
        params.put(PadHttpParams.NeighborHood.Key.LANG, JXContextWrapper.lang);
        FormBody.Builder formBuilder = new FormBody.Builder();
        for(String key : params.keySet()){
            formBuilder.add(key,params.get(key));
        }
        return formBuilder.build();
    }

    private static Observable<BaseEntry> buildObservable(final Request request){
        return Observable.just(httpClient.newCall(request))
                .subscribeOn(Schedulers.newThread())
                .observeOn(Schedulers.newThread())
                .map(new Function<Call, BaseEntry>() {
                    @Override
                    public BaseEntry apply(Call call) throws Exception {
                        Response response = call.execute();
                        if(!response.isSuccessful() || response.body() == null){
                            return null;
                        }
                        BaseEntry result = null;
                        try{
                            String content = response.body().string();
                            result = JSON.parseObject(content,BaseEntry.class);
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                        return result;
                    }
                })
                .filter(new Predicate<BaseEntry>() {
                    @Override
                    public boolean test(BaseEntry entry) throws Exception {
                        return entry != null;
                    }
                })
                .observeOn(AndroidSchedulers.mainThread());
    }

    private static Observable<BaseEntry> buildEmptyObserver(){
        return Observable.just(buildFaildEntry());
    }

    private static BaseEntry buildFaildEntry(){
        BaseEntry entry = new BaseEntry();
        entry.result = false;
        entry.msg = "HTTP FAILD : JXPadSDK.setAppKey() is not called";
        entry.content = "";
        return entry;
    }
}
