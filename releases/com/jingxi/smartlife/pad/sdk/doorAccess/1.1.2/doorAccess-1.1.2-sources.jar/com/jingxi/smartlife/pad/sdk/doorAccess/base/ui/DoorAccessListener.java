package com.jingxi.smartlife.pad.sdk.doorAccess.base.ui;

import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorSessionManager;

public interface DoorAccessListener {

    /**
     * 响铃,可从 {@link DoorSessionManager#getCurrentDevice(String session)} 获取到当前的呼叫设备
     */
    void onRinging(String sessionId);

    /**
     * 门锁已开
     */
    void onUnLock();

    /**
     * 设备列表在线状态
     */
    void onDeviceChanged(String familyID,boolean isDoorDeviceOnLine,boolean isUnitDeviceOnline,boolean isPropertyDeviceOnLine);

    /**
     * 底座的按键事件
     * @param buttonKey
     *
     *  @param cmd   对应底座5个按钮事件
     * {@link com.intercom.sdk.IntercomConstants#kButtonSOS}
     * {@link com.intercom.sdk.IntercomConstants#kButtonUser}
     * {@link com.intercom.sdk.IntercomConstants#kButtonMonitor}
     * {@link com.intercom.sdk.IntercomConstants#kButtonUnlock}
     * {@link com.intercom.sdk.IntercomConstants#kButtonPickup}
     *
     *  以下两个对应移动感应
     * {@link com.intercom.sdk.IntercomConstants#kButtonHumanNear}
     * {@link com.intercom.sdk.IntercomConstants#kButtonHumanNear}
     */
    void onBaseButtonClick(String buttonKey,String cmd);
}
