package com.jingxi.smartlife.pad.sdk.doorAccess.base;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.SurfaceView;

import com.google.gson.Gson;
import com.intercom.sdk.BundleToJSON;
import com.intercom.sdk.IntercomClientManager;
import com.intercom.sdk.IntercomConstants;
import com.intercom.sdk.IntercomManager;
import com.intercom.sdk.IntercomMediaPlayer;
import com.intercom.sdk.IntercomMessage;
import com.intercom.sdk.IntercomNetDevice;
import com.intercom.sdk.IntercomObserver;
import com.intercom.sdk.NetClient;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.CallOutBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorDevice;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorEvent;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorRecordBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.ExtDeviceBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.orm.DoorAccessOrmUtil;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * @author bjj
 * 门禁3.0 控制封装
 */
public class DoorManagerUtil {

    /**
     * 门禁查看监控
     */
    public static String monitor(String familyDockSn, DoorDevice subDevice){
        String sessionId = "";
        CallOutBean callOutBean = DoorMessageFactory.buildMonitorCallOutBean(familyDockSn,subDevice);
        if(callOutBean == null){
            return sessionId;
        }
        sessionId = callOutBean.message.getSession_id();
        IntercomManager.Intercom intercom = callout(familyDockSn,callOutBean);

        DoorRecordBean recordBean = DoorRecordBean.parseDoorRecord(
                familyDockSn,
                IntercomConstants.kIntercomScheme,
                callOutBean.message.getFrom(),
                callOutBean.message.getUsername(),
                callOutBean.message.getSession_id(),
                DoorRecordBean.CALL_EVENT_CALLOUT);
        DoorAccessOrmUtil.saveRecord(recordBean);

        DoorEvent event = new DoorEvent();
        event.intercom = intercom;
        event.sessionId = sessionId;
        event.message = callOutBean.message;
        event.router = callOutBean.router;

        DoorSessionManager.monitor(subDevice,event,sessionId);

        return sessionId;
    }

    /**
     * 室内通消息外呼
     * @param extDeviceBean     室内通对象
     * @param isMonitor         是否是监控模式
     * @return sessionID
     */
    public static String callExtOut(String familyDockSn, ExtDeviceBean extDeviceBean, boolean isMonitor){
        CallOutBean callOutBean = DoorMessageFactory.buildExtCallOutBean(familyDockSn,extDeviceBean,isMonitor);
        if(callOutBean == null){
            return "";
        }

        IntercomManager.Intercom intercom = callout(familyDockSn,callOutBean);

        int chatEvent = isMonitor ? DoorRecordBean.CALL_EVENT_EXT_MONITOR : DoorRecordBean.CALL_EVENT_CALLOUT;

        String sessionId = callOutBean.message.getSession_id();
        DoorRecordBean recordBean = DoorRecordBean.parseExtRecord(
                familyDockSn,
                sessionId,
                extDeviceBean.clientBean.getButton_key(),
                extDeviceBean.clientBean.getSub_type(),
                chatEvent);

        DoorAccessOrmUtil.saveRecord(recordBean);

        DoorEvent event = new DoorEvent();
        event.intercom = intercom;
        event.sessionId = sessionId;
        event.message = callOutBean.message;
        event.router = callOutBean.router;

        DoorSessionManager.monitorExt(event,sessionId);

        return sessionId;
    }

    /**
     * 户户通消息外呼
     * @param number            communityid+户户通呼出的房号
     * @return sessionID
     */
    public static String callP2POut(String familyDockSn, String number){
        CallOutBean callOutBean = DoorMessageFactory.buildP2PCalloutBean(familyDockSn,number);
        if(callOutBean == null){
            return "";
        }
        IntercomManager.Intercom intercom = callout(familyDockSn,callOutBean);
        String sessionId = callOutBean.message.getSession_id();

        DoorRecordBean recordBean = DoorRecordBean.parseP2PRecord(
                familyDockSn,
                IntercomConstants.kIntercomScheme,
                callOutBean.message.getFrom(),
                callOutBean.message.getUsername(),
                sessionId,
                DoorRecordBean.CALL_EVENT_CALLOUT);

        DoorAccessOrmUtil.saveRecord(recordBean);

        DoorEvent event = new DoorEvent();
        event.intercom = intercom;
        event.sessionId = sessionId;
        event.message = callOutBean.message;
        event.router = callOutBean.router;

        DoorSessionManager.monitorP2P(event,sessionId);
        return callOutBean.message.getSession_id();
    }

    /**
     * 呼叫指定设备
     */
    private static IntercomManager.Intercom callout(String familyDockSn, CallOutBean callOutBean){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyDockSn);
        if(intercom == null){
            return null;
        }
        intercom.sessionManager.callout(callOutBean.router,callOutBean.netClient,callOutBean.message);
        return intercom;
    }

    /**
     * 接收通话,一般在 onInvite 中调用
     */
    public static void accept(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message){
        if(intercom != null){
            intercom.sessionManager.accept(router,netClient,message);
        }
    }

    public static void decline(IntercomManager.Intercom intercom, int router, NetClient netClient,
                               IntercomMessage message, int result){
        if (intercom != null) {
            intercom.sessionManager.decline(router, netClient, message, result);
        }
    }

    /**
     * 接听通话
     */
    public static void pickUp(IntercomManager.Intercom intercom, String sessionId){
        if(intercom != null){
            intercom.sessionManager.pickUp(sessionId);
            DoorSessionManager.pickUp(sessionId);
        }
    }

    /**
     * 挂断通话
     */
    public static void hangUp(IntercomManager.Intercom intercom, String sessionId, int messageResult){
        if(intercom != null){
            intercom.sessionManager.hangUp(sessionId, messageResult);
        }
        DoorSessionManager.hangup(sessionId);
        DoorAccessOrmUtil.updateChatHangup(sessionId,true);
    }

    /**
     * 开锁
     */
    public static void openDoor(IntercomManager.Intercom intercom, String sessionId){
        if(intercom != null){
            intercom.sessionManager.unlock(sessionId);
        }
    }

    /**
     * 播放指定session 的历史记录
     * @param hisSessionId          需要回放的历史记录session
     */
    public static void startPlayBack(String hisSessionId){
        IntercomMediaPlayer player = IntercomManager.getInstance().getMediaPlayer(hisSessionId);
        if(player == null){
            return;
        }
        DoorSessionManager.addPlayBack(hisSessionId);
        player.start();
    }

    /**
     * 播放指定session 的历史记录
     * @param hisSessionId          需要回放的历史记录session
     */
    public static void stopPlayBack(String hisSessionId){
        IntercomMediaPlayer player = IntercomManager.getInstance().getMediaPlayer(hisSessionId);
        DoorSessionManager.hangup(hisSessionId);
        if(player == null){
            return;
        }
        player.stop();
    }

    /**
     * 播放指定session 的历史记录
     * @param hisSessionId          需要回放的历史记录session
     */
    public static void seekPlayBack(String hisSessionId,int seek){
        IntercomMediaPlayer player = IntercomManager.getInstance().getMediaPlayer(hisSessionId);
        if(player == null){
            return;
        }
        player.seek(seek);
    }

    public static void addPlayBackListener(IntercomObserver.OnPlaybackListener onPlaybackListener){
        IntercomManager.getInstance().playback_listener.add(onPlaybackListener);
    }

    public static void removePlayBackListener(IntercomObserver.OnPlaybackListener onPlaybackListener){
        IntercomManager.getInstance().playback_listener.remove(onPlaybackListener);
    }

    /**
     * 启用/禁用 本地音频
     * @param sessionId         当前的会话id
     * @param isEnabled         启用/禁用
     */
    public static void enableLocalAudio(String familyDockSn, String sessionId, boolean isEnabled){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyDockSn);
        if(intercom != null){
            intercom.sessionManager.enableAudio(sessionId,true,isEnabled);
        }
    }

    /**
     * 启用/禁用 本地视频
     * @param sessionId         当前的会话id
     * @param isEnabled         启用/禁用
     */
    public static void enableLocalVideo(String familyDockSn, String sessionId, boolean isEnabled){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyDockSn);
        if(intercom != null){
            intercom.sessionManager.enableVideo(sessionId,isEnabled);
        }
    }

    /**
     * 启用/禁用 对方音频
     * @param sessionId         当前的会话id
     * @param isEnabled         启用/禁用
     */
    public static void enableRemoteAudio(String familyDockSn, String sessionId, boolean isEnabled){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyDockSn);
        if(intercom != null){
            intercom.sessionManager.enableAudio(sessionId,false,isEnabled);
        }
    }

    /**
     * 更新播放历史记录的Surface
     * @param hisSessionId      回放历史记录的session
     */
    public static void updatePlayBackSurface(String hisSessionId, SurfaceView surfaceView){
        IntercomManager.getInstance().updatePlaybackSurface(hisSessionId,surfaceView == null ? null : surfaceView.getHolder().getSurface());
    }

    /**
     * 通话时更新本地Surface
     */
    public static void updateLocalSurface(SurfaceView surfaceView){
        IntercomManager.getInstance().updatePreviewSurface(surfaceView == null ? null : surfaceView.getHolder().getSurface());
    }

    /**
     * 通话时更新对方 Surface
     */
    public static void updateRemoteSurface(IntercomManager.Intercom intercom, String sessionId, SurfaceView surfaceView){
        if(intercom == null){
            return;
        }
        intercom.updateSurface(sessionId,surfaceView == null ? null : surfaceView.getHolder().getSurface());
    }

    /**
     * 监听到网络变化后重启所有Intercom 的 proxy
     */
    public static void reStartAllProxy(){
        Collection<IntercomManager.Intercom> intercoms = IntercomManager.getInstance().getAllIntercom();
        List<IntercomManager.Intercom> tempList = new ArrayList<>(intercoms);
        for(IntercomManager.Intercom intercom : tempList){
            intercom.stopProxy();
            intercom.startProxy(DoorConfigs.getProxyConfig());
        }
    }

    /**
     * 停止所有Intercom 的 proxy
     */
    public static void stopAllProxy(){
        Collection<IntercomManager.Intercom> intercoms = IntercomManager.getInstance().getAllIntercom();
        List<IntercomManager.Intercom> tempList = new ArrayList<>(intercoms);
        for(IntercomManager.Intercom intercom : tempList){
            intercom.stopProxy();
        }
    }

    public static void takeSnapshot(String familyId, String sessionId){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyId);
        if(intercom != null){
            intercom.sessionManager.takeSnapshot(sessionId);
        }
    }

    public static void enablePreview(boolean enable){
        IntercomManager.getInstance().EnablePreview(enable);
    }

    /**
     * 是否支持修改设备名
     * @param familyId
     * @param subDevice
     * @return
     */
    public static boolean isSupportChangeDeviceName(String familyId,DoorDevice subDevice){
        if(TextUtils.isEmpty(familyId) || subDevice == null){
            return false;
        }
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyId);
        if(intercom == null){
            return false;
        }

        IntercomClientManager.IntercomProxy proxy = intercom.clientManager.findProxy(subDevice.getProxy_id());
        if(proxy == null){
            return false;
        }

        if(!proxy.lanOnline() && !proxy.wanOnline()){
            return false;
        }
        IntercomClientManager.IntercomProxyDescription proxyDescription = proxy.lanOnline() ? proxy.lanProxy : proxy.wanProxy;
        if(proxyDescription.netDevice == null || proxyDescription.netDevice.devices == null || proxyDescription.netDevice.devices.isEmpty()){
            return false;
        }
        for(IntercomNetDevice.NetDeviceItem item : proxyDescription.netDevice.devices){
            if(TextUtils.equals(item.name,subDevice.getCalledName())){
                if(!(item.subDevices.contains(subDevice))){
                    continue;
                }
                return item.deviceProperty != null && item.deviceProperty.dynamicTable;
            }
        }
        return false;
    }

    /**
     * 更改设备名
     * @param familyId
     * @param subDevice
     * @param newName
     * @return
     */
    public static boolean changeDeviceName(String familyId,IntercomNetDevice.SubDevice subDevice,String newName){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyId);
        if(intercom == null){
            return false;
        }

        IntercomClientManager.IntercomProxy proxy = intercom.clientManager.findProxy(subDevice.getProxy_id());
        if(proxy == null){
            return false;
        }

        IntercomClientManager.IntercomProxyDescription proxyDescription = proxy.lanOnline() ? proxy.lanProxy : proxy.wanProxy;
        if(proxyDescription == null || proxyDescription.netDevice == null
                || proxyDescription.netDevice.devices == null || proxyDescription.netDevice.devices.isEmpty()){
            return false;
        }

        IntercomNetDevice.NetDeviceItem deviceItem = null;
        for(IntercomNetDevice.NetDeviceItem item : proxyDescription.netDevice.devices){
            if(item.subDevices.contains(subDevice)){
                deviceItem = item;
                break;
            }
        }

        if(deviceItem == null){
            return false;
        }

        IntercomMessage message = new IntercomMessage();
        message.setCmd(IntercomConstants.kIntercomCommandChangeDeviceDescription);
        message.setFrom(intercom.getNetClient().getClient_id());
        message.setTo(deviceItem.name);

        message.setClient_id(subDevice.getProxy_id());
        Bundle content = new Bundle();
        content.putString("name", subDevice.name);
        content.putString("alias", newName);
        message.setContent(BundleToJSON.toString(content));

        Bundle bundle = new Bundle();
        bundle.putString("scheme", IntercomConstants.kIntercomScheme);

        NetClient netClient = null;
        int router = 0;
        if(proxy.lanOnline()){
            router = IntercomConstants.Router.LAN;
            netClient = proxy.lanProxy.netClient;
        }
        else {
            router = IntercomConstants.Router.PROXY;
            netClient = proxy.wanProxy.netClient;
        }

        bundle.putInt("router", router);
        boolean result = false;
        try {
            Gson g = new Gson();

            String clientString = g.toJson(netClient);
            String messageString = g.toJson(message);
            bundle.putString("client", clientString);
            bundle.putString("message", messageString);
            result = intercom.sendIntercomMessage(bundle);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
}
