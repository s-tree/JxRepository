package com.jingxi.smartlife.pad.sdk.doorAccess.base;

import android.util.SparseArray;

import com.intercom.sdk.IntercomClientManager;
import com.intercom.sdk.IntercomConstants;
import com.intercom.sdk.IntercomManager;
import com.intercom.sdk.IntercomMessage;
import com.intercom.sdk.NetClient;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.CallOutBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorDevice;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.ExtDeviceBean;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * @author bjj
 * 门禁消息构建
 */
public class DoorMessageFactory {
    private static SparseArray<String> hangupResult;
    static {
        hangupResult = new SparseArray<>();
        hangupResult.put(IntercomConstants.IntercomMessageResult.IntercomMessageResultErr,"未知错误");
        hangupResult.put(IntercomConstants.IntercomMessageResult.IntercomMessageResultDeviceName,"呼叫设备参数错误");
        hangupResult.put(IntercomConstants.IntercomMessageResult.IntercomMessageResultSessionId,"呼叫设备toekn错误");
        hangupResult.put(IntercomConstants.IntercomMessageResult.IntercomMessageResultNOAuthority,"用户认证失败");
        hangupResult.put(IntercomConstants.IntercomMessageResult.IntercomMessageResultUnsupportCommand,"未知操作");
        hangupResult.put(IntercomConstants.IntercomMessageResult.IntercomMessageResultNotConnected,"连接失败");
        hangupResult.put(IntercomConstants.IntercomMessageResult.IntercomMessageResultDeviceBusy,"设备正忙");
        hangupResult.put(IntercomConstants.IntercomMessageResult.IntercomMessageResultUserName,"呼叫设备参数错误");
        hangupResult.put(IntercomConstants.IntercomMessageResult.IntercomMessageResultNet,"连接设备失败");
        hangupResult.put(IntercomConstants.IntercomMessageResult.IntercomMessageResultTransport,"数据传输失败");
    }

    public static String getHangupMessage(int result){
        return hangupResult.get(result);
    }


    /**
     * 根据代理id 获取到CalloutBean
     */
    private static CallOutBean getCalloutBean(String familyDockSn, String proxyId){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyDockSn);
        if(intercom == null || intercom.sessionManager == null){
            return null;
        }
        IntercomClientManager.IntercomProxy proxy = intercom.clientManager.findProxy(proxyId);
        if(proxy == null ){
            return null;
        }
        if(!proxy.lanOnline() && !proxy.wanOnline()){
            return null;
        }
        NetClient netClient = null;
        int router = IntercomConstants.Router.LAN;
        if(proxy.lanOnline()){
            netClient = proxy.lanProxy.netClient;
        }else if(proxy.wanOnline()){
            netClient = proxy.wanProxy.netClient;
            router = IntercomConstants.Router.PROXY;
        }
        CallOutBean callOutBean = new CallOutBean();
        callOutBean.router = router;
        callOutBean.netClient = netClient;
        return callOutBean;
    }

    /**
     * 创建门禁外呼消息
     */
    public static CallOutBean buildMonitorCallOutBean(String familyDockSn, DoorDevice device){
        CallOutBean callOutBean = getCalloutBean(familyDockSn,device.getProxy_id());
        if(callOutBean == null){
            return null;
        }
        callOutBean.message = buildMonitorMessage(device);
        return callOutBean;
    }

    /**
     * 创建门禁外呼消息内容
     */
    private static IntercomMessage buildMonitorMessage(DoorDevice device){
        IntercomMessage message = new IntercomMessage();
        message.setTo(device.getCalledName());
        message.setUsername(device.name);
        message.setCmd(IntercomConstants.kIntercomCommandCall);
        message.setSession_id(IntercomManager.createSessionId());
        message.setRecord(true);
        message.setVideo(true);
        message.setAudio(true);
        return message;
    }

    /**
     * 创建室内通外呼消息
     * @param isMonitor         是否是监控模式
     */
    public static CallOutBean buildExtCallOutBean(String familyDockSn, ExtDeviceBean deviceBean, boolean isMonitor){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyDockSn);
        if(intercom == null){
            return null;
        }
        IntercomMessage message = buildExtCallOutMessage(deviceBean,isMonitor);
        IntercomClientManager.IntercomClient intercomClient = IntercomManager.getInstance().getIntercom(familyDockSn)
                .clientManager.findClient(deviceBean.clientId);
        CallOutBean callOutBean = null;
        if (intercomClient.lanOnline()) {
            List<String> proxyIds = new ArrayList<>(intercomClient.lanClients.keySet());
            if(!proxyIds.isEmpty()){
                message.setTo(DoorFinal.NAME_EXT);
                String proxyId = proxyIds.get(0);
                callOutBean = getCalloutBean(familyDockSn,proxyId);
            }
        }
        if (callOutBean == null && intercomClient.wanOnline()) {
            callOutBean = new CallOutBean();
            callOutBean.netClient = intercomClient.wanClient;
            message.setTo(callOutBean.netClient.getClient_id());
            callOutBean.router = IntercomConstants.Router.PROXY;
        }
        callOutBean.message = message;
        return callOutBean;
    }

    /**
     * 创建室内通外呼消息内容
     * @param isMonitor         是否是监控模式
     */
    private static IntercomMessage buildExtCallOutMessage(ExtDeviceBean extDeviceBean, boolean isMonitor){
        IntercomMessage message = new IntercomMessage();
        message.setCmd(IntercomConstants.kIntercomCommandCall);
        message.setAudio(true);
        message.setVideo(extDeviceBean.clientBean.getSub_type() != IntercomConstants.NetClientSubType.NetClientSubTypeEmbedded);
        message.setRecord(false);
        message.setSession_id(IntercomManager.createSessionId());
        message.setContent(createExtContent(extDeviceBean.clientId, "有消息2", isMonitor,false));
        return message;
    }

    /**
     *  创建室内通消息正文
     * @param isHandHangup      是否是主动挂断
     */
    private static String createExtContent(String clientId, String message, boolean isMonitor, boolean isHandHangup){
        String command = "";
        try {
            JSONObject object = new JSONObject();
            object.put(DoorFinal.MESSAGE_KEY_CLIENTID,clientId);
            object.put(DoorFinal.MESSAGE_KEY_MESSAGE,message);
            object.put(DoorFinal.MESSAGE_KEY_ISMONITOR,isMonitor);
            object.put(DoorFinal.MESSAGE_KEY_ISHANDHANGUP,isHandHangup);
            return IntercomManager.base64(true, object.toString());
        }catch (Exception e){
            e.printStackTrace();
        }
        return command;
    }

    /**
     * 创建p2p 的外呼消息
     * @param number            外呼的房号
     */
    public static CallOutBean buildP2PCalloutBean(String familyDockSn, String number) {
        String[] p2pDevice = DoorDeviceManager.getP2PDeviceID(familyDockSn);
        if(p2pDevice == null || p2pDevice.length < 2){
            return null;
        }
        IntercomMessage message = new IntercomMessage();
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyDockSn);
        if(intercom == null){
            return null;
        }
        CallOutBean callOutBean = getCalloutBean(familyDockSn,p2pDevice[0]);
        if(callOutBean == null){
            return null;
        }
        message.setFrom(intercom.getNetClient().getClient_id());
        message.setTo(p2pDevice[1]);
        message.setClient_id(p2pDevice[0]);
        message.setCmd(IntercomConstants.kIntercomCommandCall);
        message.setRecord(false);
        message.setUsername(number);
        message.setSession_id(IntercomManager.createSessionId());
        message.setVideo(true);
        message.setAudio(true);
        callOutBean.message = message;
        return callOutBean;
    }
}
