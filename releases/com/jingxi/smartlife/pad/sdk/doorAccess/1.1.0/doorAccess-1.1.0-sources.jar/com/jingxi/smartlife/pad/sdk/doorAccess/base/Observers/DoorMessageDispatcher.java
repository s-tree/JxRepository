package com.jingxi.smartlife.pad.sdk.doorAccess.base.Observers;

import android.text.TextUtils;
import android.util.SparseArray;

import com.intercom.sdk.IntercomConstants;
import com.intercom.sdk.IntercomManager;
import com.intercom.sdk.IntercomMessage;
import com.intercom.sdk.NetClient;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorDeviceManager;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorFinal;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorSessionManager;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorEvent;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.DoorAccessListener;
import com.jingxi.smartlife.pad.sdk.utils.JXLogUtil;

public class DoorMessageDispatcher {
    private static final String TAG = "DoorMessageDispatcher";
    private static SparseArray<BaseDoorObserver> observerMap;
    static {
        observerMap = new SparseArray<>();
        observerMap.put(DoorEvent.TYPE_DOOR,new DoorOberver());
        observerMap.put(DoorEvent.TYPE_EXT,new ExtOberver());
        observerMap.put(DoorEvent.TYPE_P2P,new P2PObserver());
    }
    private static DoorAccessListener listener;

    public static DoorAccessListener getDoorListener() {
        return listener;
    }

    public static void setDoorListener(DoorAccessListener observer) {
        listener = observer;
    }

    public static void onIntercomMessageArrival(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message) {
        if(listener == null){
            JXLogUtil.logW(TAG + " [DoorAccessListener] : listener is null" );
            return;
        }
        /**
         * ROUTER_LAN 状态下使用Message 中的from 来判断消息来源
         * ROUTER_WAN 状态下，NetClientType == Proxy 时为门禁设备，
         *                    NetClientType == Client 时 ，from == p2p 为户户通消息，否则为室内通消息
         */
        int from = message.getFrom().contains(DoorFinal.NAME_P2P) ? DoorEvent.TYPE_P2P : DoorEvent.TYPE_DOOR;
        if ((router == IntercomConstants.Router.LAN && message.getFrom().contains(DoorFinal.NAME_EXT))
                || (router == IntercomConstants.Router.PROXY && netClient.getType() == IntercomConstants.NetClientType.NetClientTypeClient)) {
            from = DoorEvent.TYPE_EXT;
        }
        BaseDoorObserver baseDoorObserver = observerMap.get(from);
        if(baseDoorObserver == null){
            return;
        }
        String cmd = message.getCmd();
        boolean isNeedShowUI = false;
        if(TextUtils.equals(cmd, IntercomConstants.kIntercomCommandInvite)){
            isNeedShowUI = baseDoorObserver.onInvite(intercom,router,netClient,message);
        }
        else if(TextUtils.equals(cmd, IntercomConstants.kIntercomCommandCall)){
            isNeedShowUI = baseDoorObserver.onCall(intercom,router,netClient,message);
        }
        else if(TextUtils.equals(cmd, IntercomConstants.kIntercomCommandRinging)){
            if(message.isAck()){
                return;
            }
            isNeedShowUI = baseDoorObserver.onRinging(intercom,router,netClient,message);
        }
        else if(TextUtils.equals(cmd, IntercomConstants.kIntercomCommandPickup)){
            isNeedShowUI = baseDoorObserver.onPickup(intercom,router,netClient,message);
        }
        else if(TextUtils.equals(cmd, IntercomConstants.kIntercomCommandPickupByOther)){
            isNeedShowUI = baseDoorObserver.onPickupByOther(intercom,router,netClient,message);
        }
        else if(TextUtils.equals(cmd, IntercomConstants.kIntercomCommandHangup)){
            isNeedShowUI = baseDoorObserver.onHangup(intercom,router,netClient,message);
        }
        else if(TextUtils.equals(cmd, IntercomConstants.kIntercomCommandUnlock)){
            baseDoorObserver.onUnLock(intercom,router,netClient,message);
            listener.onUnLock();
            isNeedShowUI = false;
        }
        else if(TextUtils.equals(cmd, IntercomConstants.kIntercomCommandSessionTimeout)){
            isNeedShowUI = baseDoorObserver.onTimeOut(intercom,router,netClient,message);
        }
        if(!isNeedShowUI){
            return;
        }
        DoorEvent event = new DoorEvent();
        event.netClient = netClient;
        event.intercom = intercom;
        event.message = message;
        event.type = from;
        event.sessionId = message.getSession_id();
        event.cmd = message.getCmd();

        if(event.canStartUI()){
            DoorSessionManager.ringing(from,event);
            DoorSessionManager.setCurrentDevice(message.getSession_id(), DoorDeviceManager.getDoorDeviceByName(intercom,router,message.getUsername()));
            listener.onRinging(message.getSession_id());
            return;
        }

        /**
         * new event
         */
        if( DoorSessionManager.getConversationUI() != null){
            DoorSessionManager.getConversationUI().refreshEvent(event);
        }
    }
}
