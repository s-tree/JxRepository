package com.jingxi.smartlife.pad.sdk.doorAccess.base;

import android.support.annotation.IntDef;
import android.support.annotation.StringDef;

import com.intercom.sdk.IntercomConstants;
import com.intercom.sdk.IntercomManager;
import com.intercom.sdk.IntercomMessage;
import com.intercom.sdk.NetClient;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorAccessSession;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorDevice;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorEvent;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.DoorAccessConversationUI;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.DoorAccessListUI;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.HashMap;
import java.util.Map;

public class DoorSessionManager {
    /**
     * Session 管理
     */
    /**
     * 用IntDef 包含几个常量
     * 枚举类名用接口替代
     */
    @IntDef({FREE,MONITOR,RINGING,CHATTING,PLAY_BACK})
    @Retention(RetentionPolicy.SOURCE)
    public @interface Status{}

    //空闲
    public static final int FREE = 0;
    //本地看监控
    public static final int MONITOR = 1;
    //有响铃
    public static final int RINGING = 2;
    //接听呼叫通话中
    public static final int CHATTING = 3;
    //正在回放
    public static final int PLAY_BACK = 4;

//    private static @Status int mStatus ;
//    private static DoorEvent mDoorEvent;
//    private static String mSessionId;
//    private static DoorDevice currentDevice;
//    private static ExtDeviceBean extDeviceBean;
    private static DoorAccessListUI listUI;
    private static DoorAccessConversationUI conversationUI;

    private static Map<String,DoorAccessSession> sessions = new HashMap<>();

    public static void setListUI(DoorAccessListUI mListUI){
        listUI = mListUI;
    }

    public static DoorAccessListUI getListUI() {
        return listUI;
    }

    public static DoorAccessConversationUI getConversationUI() {
        return conversationUI;
    }

    public static void setConversationUI(DoorAccessConversationUI conversationUI) {
        DoorSessionManager.conversationUI = conversationUI;
    }

    /**
     * 获取到 DoorAccessSession 并可以 autoCreate
     * @param sessionId
     * @return
     */
    private static DoorAccessSession getSession(String sessionId){
        return getSession(DoorEvent.TYPE_DOOR,sessionId);
    }

    /**
     * 获取到 DoorAccessSession 并可以 autoCreate
     * @param sessionId
     * @return
     */
    private static DoorAccessSession getSession(@DoorEvent.DoorMessageType int callType, String sessionId){
        if(sessions.containsKey(sessionId)){
            return sessions.get(sessionId);
        }
        DoorAccessSession session = new DoorAccessSession(sessionId);
        session.callType = callType;
        sessions.put(sessionId,session);
        return session;
    }

    public static IntercomManager.Intercom getCurrentIntercom(String sessionId){
        DoorAccessSession session = sessions.get(sessionId);
        return session != null && session.doorEvent != null ? session.doorEvent.intercom : null;
    }

    public static IntercomMessage getCurrentMessage(String sessionId){
        DoorAccessSession session = sessions.get(sessionId);
        return session != null && session.doorEvent != null ? session.doorEvent.message : null;
    }

    public static int getCurrentRouter(String sessionId){
        DoorAccessSession session = sessions.get(sessionId);
        return session != null && session.doorEvent != null ? session.doorEvent.router : IntercomConstants.Router.LAN;
    }

    public static NetClient getCurrentNetClient(String sessionId){
        DoorAccessSession session = sessions.get(sessionId);
        return session != null && session.doorEvent != null ? session.doorEvent.netClient : null;
    }

    public static DoorDevice getCurrentDevice(String sessionId) {
        DoorAccessSession session = sessions.get(sessionId);
        return session != null ? session.currentDevice : null;
    }

    public static void setCurrentDevice(String sessionId,DoorDevice currentDevice) {
        getSession(sessionId).currentDevice = currentDevice;
    }

    public static int getStatus(String sessionId) {
        DoorAccessSession session = sessions.get(sessionId);
        return session != null ? session.status : FREE;
    }

    private static void setStatus(String sessionId,@Status int newState){
        getSession(sessionId).status = newState;
    }

    public static DoorEvent getDoorEvent(String sessionId) {
        DoorAccessSession session = sessions.get(sessionId);
        return session != null ? session.doorEvent : null;
    }

    public static void setDoorEvent(String sessionId,DoorEvent doorEvent) {
        getSession(sessionId).doorEvent = doorEvent;
    }

    public static @DoorEvent.DoorMessageType int getRingingType(String sessionId){
        DoorAccessSession session = getSession(sessionId);
        return session.callType;
    }

    /**
     * 当前状态是否可以弹出门禁响铃
     * @return
     */
    public static boolean canCalling(String sessionId){
        return true;
    }

    public static void monitor(DoorDevice subDevice, String sessionId){
        DoorAccessSession session = getSession(sessionId);
        session.currentDevice = subDevice;
        session.status = MONITOR;
        session.doorEvent = null;
    }

    public static void monitorP2P(String sessionId){
        DoorAccessSession session = getSession(DoorEvent.TYPE_P2P,sessionId);
        session.status = MONITOR;
        session.doorEvent = null;
    }

    public static void ringing(int callType,DoorEvent doorEvent){
        if(doorEvent == null){
            return;
        }
        DoorAccessSession session = getSession(callType,doorEvent.sessionId);
        session.doorEvent = doorEvent;
        session.status = RINGING;
        session.currentDevice = DoorDeviceManager.getDeviceByName(doorEvent.intercom.id,doorEvent.message.getUsername());
    }

    public static void pickUp(String sessionId){
        DoorAccessSession session = sessions.get(sessionId);
        if(session != null && session.status == RINGING){
            session.status = CHATTING;
        }
    }

    public static void hangup(String sessionId){
        sessions.remove(sessionId);
    }

    public static void hangupAll(){
        sessions.clear();
    }

}
