package com.jingxi.smartlife.pad.sdk.doorAccess.base;

import android.text.TextUtils;
import android.util.SparseArray;

import com.intercom.sdk.IntercomClientManager;
import com.intercom.sdk.IntercomConstants;
import com.intercom.sdk.IntercomManager;
import com.intercom.sdk.IntercomMessage;
import com.intercom.sdk.IntercomNetDevice;
import com.intercom.sdk.NetClient;
import com.jingxi.smartlife.pad.sdk.doorAccess.R;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.Observers.DoorMessageDispatcher;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorDevice;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.ExtDeviceBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.DoorAccessListener;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DoorDeviceManager {
    private static OnExtDeviceChanged mOnExtDeviceChanged;

    public static void setOnExtDeviceChanged(OnExtDeviceChanged onExtDeviceChanged) {
        mOnExtDeviceChanged = onExtDeviceChanged;
    }

    /**
     *
     * @return result[0]    proxy_id
     *          result[1]    device_id
     * //         result[2]    format
     */
    public static String[] getP2PDeviceID(String familyDockSn) {
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyDockSn);
        if (intercom == null) {
            return null;
        }
        Map<String, IntercomClientManager.IntercomProxy> proxies = intercom.clientManager.proxies;
        if (proxies.isEmpty()) {
            return null;
        }
        Collection<IntercomClientManager.IntercomProxy> intercomProxies = proxies.values();
        if (intercomProxies.isEmpty()) {
            return null;
        }
        IntercomClientManager.IntercomProxyDescription proxyBean = null;
        for (IntercomClientManager.IntercomProxy intercomProxy : intercomProxies) {
            if (intercomProxy.lanOnline()) {
                proxyBean = intercomProxy.lanProxy;
            } else if (intercomProxy.wanOnline()) {
                proxyBean = intercomProxy.wanProxy;
            }
            if (proxyBean != null && proxyBean.netDevice != null && proxyBean.netDevice.devices != null) {
                for (IntercomNetDevice.NetDeviceItem netDeviceItem : proxyBean.netDevice.devices) {
                    if (TextUtils.equals(netDeviceItem.device_class, DoorFinal.NAME_P2P)) {
                        String[] result = new String[3];
                        result[0] = proxyBean.netDevice.proxy_id;
                        result[1] = netDeviceItem.name;
                        //                    result[2] = netDeviceItem.deviceProperty.p2pNumberMask;
                        return result;
                    }
                }
            }
        }
        return null;
    }

    public static boolean isSupportExt(String familyID){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyID);
        if (intercom == null) {
            return false;
        }
        Map<String, IntercomClientManager.IntercomProxy> proxies = intercom.clientManager.proxies;
        if (proxies.isEmpty()) {
            return false;
        }
        Collection<IntercomClientManager.IntercomProxy> intercomProxies = proxies.values();
        if (intercomProxies.isEmpty()) {
            return false;
        }
        IntercomClientManager.IntercomProxyDescription proxyBean = null;
        for (IntercomClientManager.IntercomProxy intercomProxy : intercomProxies) {
            if (intercomProxy.lanOnline()) {
                proxyBean = intercomProxy.lanProxy;
            } else if (intercomProxy.wanOnline()) {
                proxyBean = intercomProxy.wanProxy;
            }
            if (proxyBean != null && proxyBean.netDevice != null && proxyBean.netDevice.devices != null) {
                for (IntercomNetDevice.NetDeviceItem netDeviceItem : proxyBean.netDevice.devices) {
                    if (TextUtils.equals(netDeviceItem.device_class, DoorFinal.NAME_EXT)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public static boolean isSupportSecurity(String familyID){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyID);
        if (intercom == null) {
            return false;
        }
        Map<String, IntercomClientManager.IntercomProxy> proxies = intercom.clientManager.proxies;
        if (proxies.isEmpty()) {
            return false;
        }
        Collection<IntercomClientManager.IntercomProxy> intercomProxies = proxies.values();
        if (intercomProxies.isEmpty()) {
            return false;
        }
        IntercomClientManager.IntercomProxyDescription proxyBean = null;
        for (IntercomClientManager.IntercomProxy intercomProxy : intercomProxies) {
            if (intercomProxy.lanOnline()) {
                proxyBean = intercomProxy.lanProxy;
            } else if (intercomProxy.wanOnline()) {
                proxyBean = intercomProxy.wanProxy;
            }
            if (proxyBean != null && proxyBean.netDevice != null && proxyBean.netDevice.devices != null) {
                for (IntercomNetDevice.NetDeviceItem netDeviceItem : proxyBean.netDevice.devices) {
                    if (TextUtils.equals(netDeviceItem.device_class, DoorFinal.NAME_SECURITY)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public static List<ExtDeviceBean> getExtDevices(String familyID,String selfButtonKey){
        if(!isSupportExt(familyID)){
            return new ArrayList<>();
        }
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyID);
        List<ExtDeviceBean> deviceBeans = new ArrayList<>();
        Map<String,IntercomClientManager.IntercomClient> clients = intercom.clientManager.clients;
        for(IntercomClientManager.IntercomClient client : clients.values()){
            if(client.wanOnline() && (!TextUtils.equals(client.wanClient.getButton_key(),selfButtonKey) || client.wanClient.getSub_type() != DoorConfigs.getClientType() )){
                deviceBeans.add(ExtDeviceBean.obtain(client.wanClient));
            }
            if(client.lanOnline()){
                for(NetClient netClient : client.lanClients.values()){
                    if((!TextUtils.equals(netClient.getButton_key(),selfButtonKey) || netClient.getSub_type() != DoorConfigs.getClientType() )){
                        deviceBeans.add(ExtDeviceBean.obtain(netClient));
                    }
                }
            }
        }
        return deviceBeans;
    }

    public static ExtDeviceBean getExtDeviceByClientId(NetClient netClient, int router, IntercomMessage message, IntercomManager.Intercom intercom) {
        String clientID;
        if (router == IntercomConstants.Router.LAN) {
            clientID = DoorMessageFactory.getClientIDFromMessageContent(message.getContent());
            Map<String, IntercomClientManager.IntercomClient> clients = intercom.clientManager.clients;
            for (IntercomClientManager.IntercomClient client : clients.values()) {
                for (NetClient nc : client.lanClients.values()) {
                    if (TextUtils.equals(nc.getClient_id(), clientID)) {
                        return ExtDeviceBean.obtain(nc);
                    }
                }
            }
        } else {
            clientID = netClient.getClient_id();
            return ExtDeviceBean.obtain(netClient);
        }
        return null;
    }

    public static void notifyExtDeviceChanged(IntercomManager.Intercom intercom, String client_id, boolean isOnline){
        if(mOnExtDeviceChanged == null){
            return;
        }
        ExtDeviceBean extDeviceBean = null;
        if(isOnline) {
            IntercomClientManager.IntercomClient client = intercom.clientManager.findClient(client_id);
            if(client.wanOnline()){
                extDeviceBean = ExtDeviceBean.obtain(client.wanClient);
            }
            if(client.lanOnline()){
                for(NetClient nc : client.lanClients.values()){
                    extDeviceBean = ExtDeviceBean.obtain(nc);
                    break;
                }
            }
        }else{
            extDeviceBean = new ExtDeviceBean(client_id);
        }
        mOnExtDeviceChanged.onExtChanged(extDeviceBean,isOnline);
    }

    /**
     * 获取指定from_name 的地址格式
     */
    public static int[] getHHTAddressFormat(String familyId){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyId);
        if(intercom == null){
            return new int[]{0};
        }
        Collection<IntercomClientManager.IntercomProxy> intercomProxies = intercom.clientManager.proxies.values();
        for (IntercomClientManager.IntercomProxy intercomProxy : intercomProxies) {
            IntercomClientManager.IntercomProxyDescription proxyBean;
            if (intercomProxy.lanOnline()) {
                proxyBean = intercomProxy.lanProxy;
            } else if (intercomProxy.wanOnline()) {
                proxyBean = intercomProxy.wanProxy;
            } else {
                continue;
            }
            if (proxyBean.netDevice == null || proxyBean.netDevice.devices == null || proxyBean.netDevice.devices.size() < 1) {
                continue;
            }
            for (IntercomNetDevice.NetDeviceItem netDeviceItem : proxyBean.netDevice.devices) {
                if (TextUtils.equals(netDeviceItem.name, DoorFinal.NAME_P2P)) {
                    int[] mask = netDeviceItem.deviceProperty.p2pNumberMask;
                    if(mask == null){
                        return new int[]{0};
                    }
                    return netDeviceItem.deviceProperty.p2pNumberMask;
                }
            }
        }
        return new int[]{0};
    }

    /**
     * 获取 门口机、室外机、物业及的在线状态
     */
    public static void checkDeviceOnline(String familyID){
        DoorAccessListener listener = DoorMessageDispatcher.getDoorListener();
        if(listener == null){
            return;
        }
        SparseArray<DoorDevice> mTypes = new SparseArray<>();
        List<DoorDevice> devices = getFamilyDevices(familyID);
        for(DoorDevice doorDevice : devices){
            if(doorDevice.getMyDeviceType() < DoorDevice.TYPE_DOOR || doorDevice.getMyDeviceType() > DoorDevice.TYPE_MANAGER){
                continue;
            }
            mTypes.append(doorDevice.getMyDeviceType(),doorDevice);
            if(mTypes.size() == 3){
                break;
            }
        }
        listener.onDeviceChanged(
                familyID,
                mTypes.get(DoorDevice.TYPE_DOOR) != null,
                mTypes.get(DoorDevice.TYPE_UNIT) != null,
                mTypes.get(DoorDevice.TYPE_MANAGER) != null);

    }

    public static List<DoorDevice> getFamilyDevices(String familyID){
        List<DoorDevice> allDevices = new ArrayList<>();
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyID);
        if(intercom == null){
            return allDevices;
        }
        Map<String, IntercomClientManager.IntercomProxy> proxies = intercom.clientManager.proxies;
        if(proxies.isEmpty()){
            return allDevices;
        }
        List<IntercomClientManager.IntercomProxy> allProxyies = new ArrayList<>(proxies.values());
        for(IntercomClientManager.IntercomProxy proxy : allProxyies){
            String proxyId = proxy.proxy_id;
            IntercomNetDevice netDevice = null;
            if(proxy.lanOnline()){
                netDevice = proxy.lanProxy.netDevice;
            }
            else if(proxy.wanOnline()){
                netDevice = proxy.wanProxy.netDevice;
            }
            if(netDevice == null){
                continue;
            }
            List<IntercomNetDevice.NetDeviceItem> netDeviceItems = netDevice.devices;
            if(netDeviceItems == null || netDeviceItems.isEmpty()){
                continue;
            }
            for(IntercomNetDevice.NetDeviceItem item : netDeviceItems){
                allDevices.addAll(decodeDeviceModens(item,proxyId));
            }
        }
        return allDevices;
    }

    public static DoorDevice getDeviceByName(String familyID,String name){
        List<DoorDevice> allDevices = getFamilyDevices(familyID);
        for(DoorDevice doorDevice : allDevices){
            if(TextUtils.equals(doorDevice.name,name)){
                return doorDevice;
            }
        }
        return null;
    }

    //1=36050@,室外机,1,0,2
    private static List<DoorDevice> decodeDeviceModens(IntercomNetDevice.NetDeviceItem netDeviceItem, String proxyId) {
        ArrayList<DoorDevice> devices = new ArrayList<>();
        if (netDeviceItem.subDevices == null || netDeviceItem.subDevices.isEmpty()) {
            return devices;
        }
        for (IntercomNetDevice.SubDevice subDevice : netDeviceItem.subDevices) {
            DoorDevice doorDevice = decodeDoorDevice(subDevice,netDeviceItem.name,proxyId);
            if(doorDevice == null){
                continue;
            }
            devices.add(doorDevice);
        }
        return devices;
    }

    public static DoorDevice getDoorDeviceByName(IntercomManager.Intercom intercom,int router,String name){
        if(intercom == null){
            return null;
        }
        Map<String, IntercomClientManager.IntercomProxy> proxies = intercom.clientManager.proxies;
        if(proxies.isEmpty()){
            return null;
        }
        Map<String,IntercomClientManager.IntercomProxy> tempProxies = new HashMap<>(proxies);
        for(IntercomClientManager.IntercomProxy proxy : tempProxies.values()){
            IntercomClientManager.IntercomProxyDescription description = null;
            if(router == IntercomConstants.Router.LAN){
                description = proxy.lanProxy;
            }else{
                description = proxy.wanProxy;
            }
            if(description == null){
                continue;
            }
            IntercomNetDevice netDevice = description.netDevice;
            if(netDevice == null){
                continue;
            }
            List<IntercomNetDevice.NetDeviceItem> devices = netDevice.devices;
            if(devices == null || devices.isEmpty()){
                continue;
            }
            List<IntercomNetDevice.NetDeviceItem> tempDevices = new ArrayList<>(devices);
            for(IntercomNetDevice.NetDeviceItem item : tempDevices){
                if(item.subDevices == null || item.subDevices.isEmpty()){
                    continue;
                }
                List<IntercomNetDevice.SubDevice> subDevices = item.subDevices;
                for(IntercomNetDevice.SubDevice subDevice : subDevices){
                    if(TextUtils.equals(subDevice.name,name)){
                        return decodeDoorDevice(subDevice,item.name,proxy.proxy_id);
                    }
                }
            }
        }
        return null;
    }

    private static DoorDevice decodeDoorDevice(IntercomNetDevice.SubDevice subDevice,String name,String proxyId){
        DoorDevice doorDevice = DoorDevice.parse(subDevice);
        doorDevice.setCalledName(name);
        doorDevice.setProxy_id(proxyId);
        if (subDevice.deviceType == 4 || subDevice.alias.contains("门口") || subDevice.alias.contains("别墅")) {
            doorDevice.setMyDeviceType(1);
            doorDevice.setImgResource(R.mipmap.door_device_1);
        } else if (subDevice.deviceType == 1 || subDevice.deviceType == 3 || subDevice.alias.contains("围墙") || subDevice.alias.contains("室外")) {
            doorDevice.setMyDeviceType(2);
            doorDevice.setImgResource(R.mipmap.door_device_2);
        }
        else if (subDevice.deviceType == 2 || subDevice.alias.contains("管理")) {
            doorDevice.setMyDeviceType(DoorDevice.TYPE_MANAGER);
                doorDevice.setImgResource(R.mipmap.door_device_0);
        }
        else {
            return null;
        }
        return doorDevice;
//            手机端不需要显示管理设备和其他设备
//            else {
//                subDevice.alias = StringUtils.getString(R.string.unKnow);
//                subDevice.setImgResource(R.mipmap.door_device_0);
//            }
    }

    private boolean isDoor(String scheme, DoorDevice subDevice){
        return !TextUtils.isEmpty(scheme)
                && TextUtils.equals(scheme, IntercomConstants.kIntercomScheme)
                && ( subDevice.getMyDeviceType() == 1 || subDevice.getMyDeviceType() == 2 );
    }

    public static boolean isWuYe(DoorDevice subDevice){
        return subDevice.alias != null && subDevice.alias.contains("管理") && subDevice.getMyDeviceType() == 3;
    }

    public static boolean isProxyOffline(String familyID){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyID);
        return intercom == null || intercom.clientManager.proxies.isEmpty();
    }

    public interface OnExtDeviceChanged{

        void onExtChanged(ExtDeviceBean extDeviceBean,boolean isOnline);
    }
}
