package com.jingxi.smartlife.pad.sdk.doorAccess.base;

import android.os.Build;

import com.intercom.sdk.IntercomConstants;

public class DoorKit {

    /**
     * 初始化一些参数
     *
     * @param options
     */
    public static void init(Options options) {
        if (options == null) {
            return;
        }
        DoorConfigs.options = options;
    }

    public static Options getOptions() {
        return DoorConfigs.options;
    }

    public static class Options {
        protected static Options getDefault() {
            return new Options();
        }

        private Options() {

        }

        /**
         * 是否开启跟管理机对讲时的视频
         */
        public boolean enableManagerVideo = false;

        /**
         * {@link com.intercom.sdk.IntercomConstants.NetClientSubType}
         * 默认是平板
         * 平板是 NetClientSubTypePad
         * 移动端是 NetClientSubTypeMobile
         */
        public int platform = IntercomConstants.NetClientSubType.NetClientSubTypePad;

        /**
         * 室内通使用
         * 该设备的备注
         */
        public String alias = null;

        /**
         * 设备的sn，移动端可传入accid，最终用于底层生成一个随机数
         */
        public String sn = "";

        /**
         * 一个唯一值，用于此设备的id，如不传，则为程序生成
         */
        public String clientID = null;

        /**
         * 最大可保存的门禁视频记录数量
         */
        public int maxRecordCount = 50;

        /**
         * 离线推送的ali
         */
        public String publishID = "";

        /**
         * 代理服务器地址
         */
        public String proxyServerUrl = DoorConfigs.PROXY_SERVER_URL;

        /**
         * 代理服务器重连
         */
        public int proxyRetryInterval = 5;

        /**
         * 代理服务器心跳间隔
         */
        public int proxykeepalive = 30;

        /**
         * 代理工作目录
         */
        public String portConf = DoorConfigs.PORT_CONF;

        public String clientConf = DoorConfigs.PATH;

        /**
         * 渠道
         */
        public String channel = DoorConfigs.APP_CHANNEL;

        /**
         * 门禁服务工作的存储空间目录
         */
        public String doorAccessWorkDir = DoorConfigs.PATH;
        /**
         * 门禁服务服务端工作的存储空间目录
         */
        public String doorServerWorkDir = DoorConfigs.SERVER_PATH;

        /**
         * 门禁服务的注册服务器
         */
        public String intercomServerUrl = DoorConfigs.INTERCOM_SERVER_URL;
        /**
         * 证书路径
         */
        public String sslCertPath       = DoorConfigs.sslCertPath;

        public String deviceMonitorUrl = DoorConfigs.DEVICE_MONITOR_URL;

        /**
         * 平板使用SERIAL，手机使用accid
         */
        public String systemId = Build.SERIAL;

        /**
         * 代理工作目录
         */
        public String proxyWorkDir = "";

        public String remoteServiceConf = "{\"request_interval\":3600,\"conf\":[{\"url\":\"192.168.150.188:8080/remoteservice/cmd\"}]}";

        /**
         * 音频增益(播放), 1 - 30，无需增益传 0
         */
        public int audio_play_agc_level = 0;
        /**
         * 麦克风增益
         */
        public int audio_send_agc_level = 0;

        /**
         * 通话等待时间(秒)
         */
        public int max_session_wait_time = DoorConfigs.max_session_wait_time;
        /**
         * 通话过程超时时间(秒)
         */
        public int intercom_max_session_connect_time = DoorConfigs.intercom_max_session_connect_time;
        /**
         * 户户通超时时间
         * "p2p,1800,300"
         * 1800 : LAN模式下30分钟
         * 300  : WAN模式下 5分钟
         */
        public String special_p2p_device = DoorConfigs.special_p2p_device;
        /**
         * 室内通超时时间
         * "ext,2592000,86400"
         * 2592000 : LAN模式下30天
         * 86400   : WAN模式下24小时
         */
        public String speical_ext_device = DoorConfigs.speical_ext_device;

        /**
         * 是否禁止软件消回(true : 屏蔽软件消回，使用硬件消回芯片)
         */
        public boolean disable_aec = false;

        /**
         * 麦克风增益
         */
        public int aec_latency = 80;

        /**
         * 麦克风去噪,disable_aec == false 时无需设置
         */
        public boolean audio_send_denoise = false;

        /**
         * 播放去噪,disable_aec == false 时无需设置
         */
        public boolean audio_play_denoise = false;

        /**
         * 一体机连接楼宇对讲的网口名
         */
        public String lan_broadcast_exclude_interface = "eth1";

        /**
         * 是否是主机(捆绑 lan_broadcast_exclude_interface 使用)
         * false 时忽略
         */
        public boolean master_device = false;

        /**
         * 日志登记
         */
        public boolean logDebug = false;

        /**
         * 编码的数据包帧大小
         */
        public int video_encode_codec_width = 640;
        public int video_encode_codec_height = 480;

        /**
         * 传输的视频帧率
         */
        public int frame_rate = 25;

        /**
         * 室内机摄像头视频的尺寸
         */
        public int  capture_video_width = 640;
        public int  capture_video_height = 480;

        /**
         * 视频帧 fps
         */
        public int capture_video_fps = 25;
        /**
         *视频编码和解码引擎,0: FFMPEG, 1: MediaCodec, 2: MPP
         *移动端使用FFMPEG，平板根据平台可以选择使用 FFMPEG，或者MediaCodec，只有经过仔细验证，才可以使用MPP
         */
        public int video_decode_engine = 0;

        public int video_encode_engine = 0;

        /**移动端一律选择Java，室内机和室外机选择Opensles。AAudio目前的android版本支持的不好，如果有Android 9.0版本可以使用。
         * {@link IntercomConstants.AudioEngine}
         */
        public int audio_engine;

        public int audio_samplerate = 8000;

        /**
         * android移动端，设置为80000，IOS设置为40000，室内机和室外机设置为40000，
         * 这个表示音频播放缓冲区时间长度，
         * 当缓冲区存储的音频样本超过这个长度，将被丢弃。以确保音频的延迟在规定的范围内。
         */
        public int max_audio_delay_us = 45000;

        /**
         * 是否启用低延迟模式
         */
        public boolean audio_low_latency = false;

        /**
         * openwrt 播放增益,默认为20
         */
        public int audio_play_agc_compression_gain_db = 20;

        /**
         * openwrt 麦克风增益,默认为20
         */
        public int audio_send_agc_compression_gain_db = 20;

        public boolean screen_portrait;
//
//        /**
//         * 使用的声卡模式
//         * {@link IntercomConstants.AudioEngine}
//         */
//        public int audio_engine = IntercomConstants.AudioEngine.AudioEngine_JAVA;
//
//        /**
//         * 缓冲区的音频缓存时长
//         * 单位为微秒,传入值最小 20ms = 20000;
//         */
//        public long max_audio_delay_us = 20000;
//
//        /**
//         * 当声卡需要播放时，缓冲区如无数据，最大的等待时间
//         * 单位为微秒,传入值最小 20ms = 20000;
//         */
//        public long max_audio_playout_waiting_us = 8000;
//        /**
//         * 每次发送的音频时间长度，默认:40ms,单位 毫秒
//         */
//        public int audio_ptime = 40;
    }
}
