package com.jingxi.smartlife.pad.sdk.doorAccess.base;

import com.intercom.sdk.IntercomConstants;

public class DoorKit {

    /**
     * 初始化一些参数
     * @param options
     */
    public static void init(Options options){
        if(options == null){
            return;
        }
        DoorConfigs.CLIENT_TYPE = options.platform;
        DoorConfigs.alias = options.alias;
        DoorConfigs.clientID = options.clientID;
    }

    public static class Options{

        /**
         * {@link com.intercom.sdk.IntercomConstants.NetClientSubType}
         * 默认是平板
         * 平板是 NetClientSubTypePad
         * 移动端是 NetClientSubTypeMobile
         */
        public int platform = IntercomConstants.NetClientSubType.NetClientSubTypePad;

        /**
         * 室内通使用
         * 该设备的备注
         */
        public String alias = null;

        /**
         * 一个唯一值，用于此设备的id，如不传，则为程序生成
         */
        public String clientID = null;
    }
}
