package com.jingxi.smartlife.pad.sdk.doorAccess.base;

import android.os.Bundle;

import com.google.gson.Gson;
import com.intercom.sdk.ButtonMessage;
import com.intercom.sdk.IntercomManager;
import com.intercom.sdk.IntercomMessage;
import com.intercom.sdk.IntercomObserver;
import com.intercom.sdk.NetClient;
import com.intercom.sdk.SecurityMessage;
import com.intercom.sdk.SmartHomeManager;
import com.intercom.sdk.SmartHomeMessage;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.Observers.DoorMessageDispatcher;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.orm.DoorAccessOrmUtil;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.DoorAccessConversationUI;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.DoorAccessListener;
import com.jingxi.smartlife.pad.sdk.utils.JXLogUtil;

import java.util.ArrayList;

/**
 * @author bjj
 * 门禁3.0 回调
 */
public class DoorMessageCallback implements IntercomObserver.OnProxyListener,
        IntercomObserver.OnSmartHomeListener,IntercomObserver.OnIntercomClientListener,
        IntercomObserver.OnIntercomListener, IntercomObserver.OnAppListener{

    @Override
    public void onIntercomAppIntialized(boolean result) {
        JXLogUtil.logW(DoorConfigs.DOOR_LOG_TAG + " onIntercomAppIntialized");
    }

    @Override
    public void onIntercomClientInitializeResult(IntercomManager.Intercom intercom, boolean result) {
        JXLogUtil.logW(DoorConfigs.DOOR_LOG_TAG + " onIntercomClientInitializeResult");
        DoorConfigs.clientIds.put(intercom.id,intercom.getNetClient().getClient_id());
    }

    @Override
    public void onIntercomMediaDeviceStateChanged(int mediaType, int state) {
        JXLogUtil.logW(DoorConfigs.DOOR_LOG_TAG + " onIntercomMediaDeviceStateChanged");
    }

    @Override
    public void onMCUMessageArrival(int type, boolean ack, int result, String message) {
        JXLogUtil.logW(DoorConfigs.DOOR_LOG_TAG + " onMCUMessageArrival");
    }

    @Override
    public void onMCUStateChanged(boolean online) {
        JXLogUtil.logW(DoorConfigs.DOOR_LOG_TAG + " onMCUStateChanged");
    }

    @Override
    public void onButtonEvent(int event, String id, String sound) {
        JXLogUtil.logW(DoorConfigs.DOOR_LOG_TAG + " onButtonEvent");
    }

    @Override
    public void onButtonClick(String id) {
        JXLogUtil.logW(DoorConfigs.DOOR_LOG_TAG + " onButtonClick");
    }

    /**
     * 代理状态
     */
    @Override
    public void onIntercomProxyStateChanged(IntercomManager.Intercom intercom, String proxyId, boolean online) {
        JXLogUtil.logW(DoorConfigs.DOOR_LOG_TAG + " onIntercomProxyStateChanged onLine = " + online);
        DoorDeviceManager.checkDeviceOnline(intercom.id);
//        if(DoorSessionManager.getListUI() != null){
//            DoorSessionManager.getListUI().refreshList();
//        }
    }

    /**
     * 代理在线状态
     */
    @Override
    public void onIntercomProxyOnlineStateChanged(IntercomManager.Intercom intercom, String proxyId, int router, boolean online) {
        JXLogUtil.logW(DoorConfigs.DOOR_LOG_TAG + " onIntercomProxyOnlineStateChanged router = " + router + " onLine = " + online);
        DoorDeviceManager.checkDeviceOnline(intercom.id);
        if(DoorMessageDispatcher.getDoorListener() != null){
            DoorMessageDispatcher.getDoorListener().onProxyOnlineStateChanged(intercom.id,proxyId,router,online);
        }
//        if(DoorSessionManager.getListUI() != null){
//            DoorSessionManager.getListUI().refreshList();
//        }
    }

    /**
     * 设备状态
     */
    @Override
    public void onIntercomClientStateChanged(IntercomManager.Intercom intercom, String proxyId, boolean online) {
        JXLogUtil.logW(DoorConfigs.DOOR_LOG_TAG + " onIntercomClientStateChanged ");
        DoorDeviceManager.checkDeviceOnline(intercom.id);
        if(DoorSessionManager.getListUI() != null){
            DoorSessionManager.getListUI().refreshList();
        }
        /**
         * 更新室内通在线状态
         */
        DoorDeviceManager.notifyExtDeviceChanged(intercom.getNetClient(),online);
    }

    /**
     * 设备在线状态
     */
    @Override
    public void onIntercomClientOnlineStateChanged(IntercomManager.Intercom intercom, String clientId, String proxyId, int router, boolean online) {
        JXLogUtil.logW(DoorConfigs.DOOR_LOG_TAG + " onIntercomClientOnlineStateChanged router = " + router  + " online = " + online);
        DoorDeviceManager.checkDeviceOnline(intercom.id);
        if(DoorSessionManager.getListUI() != null){
            DoorSessionManager.getListUI().refreshList();
        }
    }

    @Override
    public void onIntercomInternetStateChanged(IntercomManager.Intercom intercom, boolean online) {
        JXLogUtil.logW(DoorConfigs.DOOR_LOG_TAG + " onIntercomInternetStateChanged onLine = " + online);
    }

    /**
     * 收到的按钮事件消息
     */
    @Override
    public void onIntercomButtonMessageArrival(IntercomManager.Intercom intercom, int router, NetClient netClient, ButtonMessage message) {
        JXLogUtil.logW(DoorConfigs.DOOR_LOG_TAG + " onIntercomButtonMessageArrival = " + new Gson().toJson(message));
        DoorAccessListener listener = DoorMessageDispatcher.getDoorListener();
        if(listener == null){
            return;
        }
        listener.onBaseButtonClick(netClient.getButton_key(),message.getCmd(),message.getTime());
    }

    @Override
    public void onIntercomProxyMessageArrival(IntercomManager.Intercom intercom, Bundle bundle) {
        JXLogUtil.logW(DoorConfigs.DOOR_LOG_TAG + " onIntercomProxyMessageArrival");
    }

    /**
     * 收到的消息
     */
    @Override
    public void onIntercomMessageArrival(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message) {
        JXLogUtil.logW(DoorConfigs.DOOR_LOG_TAG + " onIntercomMessageArrival [message] : " + new Gson().toJson(message));
        DoorMessageDispatcher.onIntercomMessageArrival(intercom,router,netClient,message);
    }

    /**
     * 视频文件准备好，可以截取快照
     */
    @Override
    public void onIntercomVideoReady(IntercomManager.Intercom intercom, String sessionId) {
        JXLogUtil.logW(DoorConfigs.DOOR_LOG_TAG + " onIntercomVideoReady");
        intercom.sessionManager.takeSnapshot(sessionId);
    }

    /**
     * 快照文件保存完成
     * @param filename 文件保存的路径
     */
    @Override
    public void onIntercomSnapshotReady(IntercomManager.Intercom intercom, String sessionId, String filename) {
        JXLogUtil.logW(DoorConfigs.DOOR_LOG_TAG + " onIntercomSnapshotReady");
        DoorAccessOrmUtil.updateThumb(sessionId,filename);
        if(DoorMessageDispatcher.getDoorListener() != null){
            DoorMessageDispatcher.getDoorListener().onSnapshotReady(intercom.id,sessionId,filename);
        }
    }

    /**
     * sip 连接状态
     * @param state see com.intercom.sdk.IntercomConstants#SipRegistrationState
     */
    @Override
    public void onIntercomSipStateChanged(IntercomManager.Intercom intercom, String proxy, int state) {
        JXLogUtil.logW(DoorConfigs.DOOR_LOG_TAG + " onIntercomSipStateChanged state = " + state );
    }

    /**
     * 流媒体数据状态
     * @param state see com.intercom.sdk.IntercomConstants#StreamState
     */
    @Override
    public void onIntercomStreamStateChanged(IntercomManager.Intercom intercom, String sessionId, int mediaType, int state) {
        JXLogUtil.logW(DoorConfigs.DOOR_LOG_TAG + " onIntercomStreamStateChanged state = " + state);
    }

    @Override
    public void onStreamTransportStart(IntercomManager.Intercom intercom, String sessionId, int mediaType) {
        JXLogUtil.logW(DoorConfigs.DOOR_LOG_TAG + " onStreamTransportStart sessionId = " + sessionId + " mediaType = " + mediaType);
        /**
         * 避免集合在遍历时出现数据增删导致的问题
         */
        ArrayList<DoorAccessConversationUI> tempUI = new ArrayList<>(DoorSessionManager.getConversationUI());
        for(DoorAccessConversationUI ui : tempUI){
            ui.startTransPort(sessionId);
        }
    }

    @Override
    public void onIntercomTransportStatistics(IntercomManager.Intercom intercom, String sessionId, int mediaType, int interval, long recvBytes, long sendBytes) {
        JXLogUtil.logW(DoorConfigs.DOOR_LOG_TAG + " onIntercomTransportStatistics");
    }

    /**
     * 通话建立后，所使用传输通道的回调
     * @param result   0 : p2p直连
     *                  1 : 中转
     */
    @Override
    public void onIntercomTransportIceNegotiationResult(IntercomManager.Intercom intercom, String sessionId, int mediaType, int result) {
        JXLogUtil.logW(DoorConfigs.DOOR_LOG_TAG + " onIntercomTransportIceNegotiationResult");
    }

    @Override
    public void onSmartHomeSecurityDeviceStateChanged(IntercomManager.Intercom intercom, SmartHomeManager.SecurityDevice device, boolean online) {
        JXLogUtil.logW(DoorConfigs.DOOR_LOG_TAG + " onSmartHomeSecurityDeviceStateChanged");
    }

    @Override
    public void onSmartHomeSecurityDeviceOnlineStateChanged(IntercomManager.Intercom intercom, SmartHomeManager.SecurityDevice device, int router, boolean online) {
        JXLogUtil.logW(DoorConfigs.DOOR_LOG_TAG + " onSmartHomeSecurityDeviceOnlineStateChanged");
    }

    /**
     * 安防消息
     */
    @Override
    public void onSmartHomeMessage(IntercomManager.Intercom intercom, SmartHomeManager.SecurityDevice device, SmartHomeMessage message) {
        JXLogUtil.logW(DoorConfigs.DOOR_LOG_TAG + " onSmartHomeMessage");
        DoorSecurityUtil.onSecurityMessage(intercom,device,message);
    }

    /**
     * 安防报警消息
     */
    @Override
    public void onSmartHomeAlarm(IntercomManager.Intercom intercom, SmartHomeManager.SecurityDevice device, SmartHomeMessage smartHomeMessage, SecurityMessage securityMessage) {
        JXLogUtil.logW(DoorConfigs.DOOR_LOG_TAG + " onSmartHomeAlarm");
        DoorSecurityUtil.onSecurityAlarm(intercom,device,smartHomeMessage,securityMessage);
    }
}
