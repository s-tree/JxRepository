package com.intercom.sdk;

import android.os.Bundle;



import java.util.ArrayList;
import java.util.List;

public class IntercomConfigure {

    /**
     * 整个系统初始化配置
     */
    public static class AppConf {
        /**
         * 本机产品的渠道码，如果是定制版本需要协议约定一个新的渠道码
         */
        public String channel;
        /**
         * 底层缓存的目录，最好设置在sdcard上
         * 本机临时配置文件保存在workdir/conf目录下
         */
        public String work_dir;
        /**
         * 保存访客记录得位置
         * 为了兼容旧版本，需要设置在：sdcard/data/doorkeeper/access/record
         * 全新安装无所谓，但也必须保存在sdcard中
         */
        public String media_dir;

        //日志是否保存到文件中，系统启动时，会自动生成新得日志文件名
        public boolean log_to_file;

        //日志得详细程度，debug可以设置为Info，release可以设置为fatal
        public int log_level;

        public boolean enable_memory_monitor;

        public AppConf(String channel,
                       String work_dir,
                       String media_dir,
                       boolean log_to_file,
                       int log_level,
                       boolean enable_memory_monitor) {
            this.channel = channel;
            this.work_dir = work_dir;
            this.media_dir = media_dir;
            this.log_to_file = log_to_file;
            this.log_level = log_level;
            this.enable_memory_monitor = enable_memory_monitor;
        }

        public String toJson() {
            Bundle bundle = new Bundle();
            bundle.putString("channel", this.channel);
            bundle.putString("work_dir", this.work_dir);
            bundle.putString("media_dir", this.media_dir);
            bundle.putBoolean("log_to_file", this.log_to_file);
            bundle.putInt("log_level", this.log_level);
            bundle.putBoolean("enable_memory_monitor", this.enable_memory_monitor);
            return BundleToJSON.toString(bundle);
        }
    }

    /**
     * 设置本机得终端属性
     */
    public static class ClientConf {
        public int type; //NetClientTypeClient
        public int sub_type; //NetClientSubTypePad

        /**
         * client_id:本机客户端得唯一标识
         * 由底层来设置即可
         */
        public String client_id;
        public String family_id;
        public String alias;
        public String button_key;
        public String pushid;

        public ClientConf() {
            this.type = IntercomConstants.NetClientType.NetClientTypeClient;
            this.sub_type = IntercomConstants.NetClientSubType.NetClientSubTypePad;
            this.client_id = "";
            this.family_id = "";
            this.alias = "";
            this.button_key = "";
            this.pushid = "";
        }

        public ClientConf(int type,
                          int sub_type,
                          String client_id,
                          String family_id,
                          String button_key,
                          String alias,
                          String pushid) {
            this.type = type;
            this.sub_type = sub_type;
            this.client_id = client_id;
            this.family_id = family_id;
            this.button_key = button_key;
            this.alias = alias;
            this.pushid = pushid;
        }

        public String toJson() {
            Bundle bundle = new Bundle();
            bundle.putInt("type", this.type);
            bundle.putInt("sub_type", this.sub_type);
            bundle.putString("client_id", this.client_id);
            bundle.putString("family_id", this.family_id);
            bundle.putString("alias", this.alias);
            bundle.putString("button_key", this.button_key);
            bundle.putString("pushid", this.pushid);
            return BundleToJSON.toString(bundle);
        }
    }

    /**
     * 这里配置系统中保留端口
     * 这些端口已经固定分配给指定的单元，我们在通讯的时候，需要动态分配端口，会跳过这些端口
     * 防止影响其他模块的正常功能
     */
    public static class OtherConf {
        /**
         * port range，是本模块分配udp，tcp，以及媒体端口的范围
         */
        public String port_range;
        public String tcp_reserver;
        public String udp_reserver;

        public OtherConf() {
            this.port_range = "30000,34000,35000";
            this.tcp_reserver = "";
            this.udp_reserver = "";
        }

        public OtherConf(String port_range, String tcp_reserver, String udp_reserver) {
            if (port_range == null)
                this.port_range = "30000,34000,35000";
            else
                this.port_range = port_range;
            this.tcp_reserver = tcp_reserver;
            this.udp_reserver = udp_reserver;
        }

        public String toJson() {
            Bundle bundle = new Bundle();
            bundle.putString("port_range", this.port_range);
            bundle.putString("tcp", this.tcp_reserver);
            bundle.putString("udp", this.udp_reserver);
            return BundleToJSON.toString(bundle);
        }
    }

    /**
     * 当平板和无路由但有MCU的底座合在一起，并且本机没有安装server
     * 平板终端需要支持MCU功能时，需要使能MCU模块
     * MCU模块可以相应底座的物理按键以及和其他外设的通讯
     * 对于终端来说，是否开始MCU模块，需要检查当前平板上有没有安装
     * server模块，可以通过包名来检查
     * 如果要支持按键，startMCU还需要配置按键的配置文件
     */
    public static class MCUConf {
        /**
         * 没有不包含路由的底座，应该不需要开启看门狗功能
         * 直接置空即可
         */
        public String watchdog; //"60000:10000:1"
        public String serial; ///dev/ttyS1:115200
        /**
         * 如果本机连接8路防区，需要配置以下总线的名称
         * 以便与server进行通讯
         */
        public String security_bus_name; ///tmp/security

        public MCUConf(String watchdog,
                       String serial,
                       String security_bus_name) {
            this.watchdog = watchdog;
            this.serial = serial;
            this.security_bus_name = security_bus_name;
        }

        public String toJson() {
            Bundle bundle = new Bundle();
            bundle.putString("watchdog", this.watchdog);
            bundle.putString("serial", this.serial);
            bundle.putString("security_bus_name", this.security_bus_name);
            return BundleToJSON.toString(bundle);
        }
    }

    public static class ProxyConf {
        public int     lan_proxy_broadcast_port;
        public String  multicast_address;
        public int     heartbeat_interval;
        public boolean enable_lan_broadcast;
        public boolean lan_discovery_enable;
        public String  proxy_server;
        public String  ssl_cert_path;
        public String  ssl_cert_private_key;
        public int     proxy_retry_interval;
        public int     proxy_keepalive;

        public ProxyConf() {
            this.lan_proxy_broadcast_port = 10000;
            this.multicast_address = "238.18.18.1";
            this.heartbeat_interval = 60;
            this.enable_lan_broadcast = true;
            this.lan_discovery_enable = true;
            this.proxy_server = "";
            this.ssl_cert_path = "";
            this.ssl_cert_private_key = "";
            this.proxy_retry_interval = 5;
            this.proxy_keepalive = 300;
        }

        public ProxyConf(int lan_proxy_broadcast_port,
                         String multicast_address,
                         int heartbeat_interval,
                         boolean enable_lan_broadcast,
                         boolean lan_discovery_enable,
                         String proxy_server,
                         String ssl_cert_path,
                         String ssl_cert_private_key,
                         int proxy_retry_interval,
                         int proxy_keepalive) {
            this.lan_proxy_broadcast_port = lan_proxy_broadcast_port;
            this.multicast_address = multicast_address;
            this.heartbeat_interval = heartbeat_interval;
            this.enable_lan_broadcast = enable_lan_broadcast;
            this.lan_discovery_enable = lan_discovery_enable;
            this.proxy_server = proxy_server;
            this.ssl_cert_path = ssl_cert_path;
            this.ssl_cert_private_key = ssl_cert_private_key;
            this.proxy_retry_interval = proxy_retry_interval;
            this.proxy_keepalive = proxy_keepalive;
        }

        public String toJson() {
            Bundle bundle = new Bundle();
            bundle.putInt("lan_proxy_broadcast_port", this.lan_proxy_broadcast_port);
            bundle.putString("multicast_address", this.multicast_address);
            bundle.putInt("heartbeat_interval", this.heartbeat_interval);
            bundle.putBoolean("enable_lan_broadcast", this.enable_lan_broadcast);
            bundle.putBoolean("lan_discovery_enable", this.lan_discovery_enable);
            bundle.putString("proxy_server", this.proxy_server);
            bundle.putString("ssl_cert_path", this.ssl_cert_path);
            bundle.putString("ssl_cert_private_key", this.ssl_cert_private_key);
            bundle.putInt("proxy_retry_interval", this.proxy_retry_interval);
            bundle.putInt("proxy_keepalive", this.proxy_keepalive);
            return BundleToJSON.toString(bundle);
        }
    }

    public static class ServerConfig {
        public String url;
        public String auth_user;
        public String auth_pwd;
        public String cache_filename;
        public int    retry_interval;

        public ServerConfig(String url,
                            String auth_user,
                            String auth_pwd,
                            String cache_filename,
                            int retry_interval) {
            this.url = url;
            this.auth_user = auth_user;
            this.auth_pwd = auth_pwd;
            if (cache_filename == null || cache_filename.length() < 1) {
                this.cache_filename = "client_sip.json";
            } else {
                this.cache_filename = cache_filename;
            }
            this.retry_interval = retry_interval;
        }

        public String toJson() {
            Bundle bundle = new Bundle();
            bundle.putString("url", this.url);
            bundle.putString("user", this.auth_user);
            bundle.putString("pwd", this.auth_pwd);
            bundle.putString("file", this.cache_filename);
            bundle.putInt("interval", this.retry_interval);
            return BundleToJSON.toString(bundle);
        }
    }

    public static class IntercomConfig {
        public int capture_video_width;
        public int capture_video_height;
        public int capture_video_fps;
        public int capture_video_format;

        public int    camera_type;
        public String camera_name;

        public int    video_encode_profile;
        public int    video_encode_avg_bps;
        public int    video_encode_max_bps;
        public int    video_encode_gotsize;
        public double video_encode_qcompress;
        public double video_encode_qblur;
        public int    video_encode_qmin;
        public int    video_encode_qmax;
        public int    video_encode_crf;
        public int    video_encode_codec;
        public int    video_frame_mtu;
        public String video_encode_preset;
        public String video_encode_tune;

        public int     audio_samplerate;
        public int     audio_channels;
        public int     bits_per_sample;
        public boolean disable_aec;


        public int max_record_time;

        public int video_render_format;


        /**
         * 本机收到远端音频是增益参数,range [1-32768] 0:ignor
         */
        public int audio_play_agc_level;
        /**
         * 发送到对方的音频增益参数
         */
        public int audio_send_agc_level;

        /**
         * 去噪参数:苹果设备都不需要处理，=0即可
         */
        public int denoise;

        /**
         * 底层多久报告一次传输状态，默认30s即可
         */
        public int transport_monitor_time;

        /**
         * 每次发送的音频时间长度，默认:40ms
         */
        public int audio_ptime;

        /**
         * 音频缓冲区长度: 8192即可
         */
        public int audio_buffer_size;

        /**
         * 黑屏的参数(R,G,B,A):"128,128,128,0
         */
        public String blank_color;

        /**
         * 会话初始化最长等待时间，默认为60s即可
         */
        public int max_session_wait_time;

        /**
         * 楼宇对讲会话最长持续时间，默认为200s即可
         */
        public int intercom_max_session_connect_time;

        /**
         * 特殊设备: 目前就是p2p,ext
         */
        public String special_p2p_device;

        public String speical_ext_device;

        public IntercomConfig() {
            this.capture_video_width = 640;
            this.capture_video_height = 480;
            this.capture_video_fps = 15;
            this.capture_video_format = 7; //PIXEL_FORMAT_NV21
            this.camera_type = 1;
            this.camera_name = IntercomConstants.kFrontCameraName;
            this.video_encode_profile = 0;
            this.video_encode_avg_bps = 0;
            this.video_encode_max_bps = 0;
            this.video_encode_gotsize = 1;
            this.video_encode_qcompress = 0.6;
            this.video_encode_qblur = 0.5;
            this.video_encode_crf = 28;
            this.video_encode_qmin = 10;
            this.video_encode_qmax = 51;
            this.video_encode_codec = 1;
            this.video_frame_mtu = 0;
            this.video_encode_preset = "veryfast";
            this.video_encode_tune = "animation+zerolatency";

            this.audio_samplerate = 8000;
            this.audio_channels = 1;
            this.bits_per_sample = 16;

            /**
             * 底层在语音对讲的时候，首先通过WebRtcAudioEffects来判断Framework是否提供AEC能力
             * 如果没有提供，则使用软件AEC能力。
             * 在下一代平板电脑中，硬件上提供AEC功能，但Framework未必能检测到，在这种情况下
             * 我们要明确禁止底层使用软件AEC功能
             */
            this.disable_aec = false;

            this.max_record_time = 60;

            this.video_render_format = 30; //PIXEL_FORMAT_RGBA

            this.audio_play_agc_level = 0;
            this.audio_send_agc_level = 0;
            this.denoise = 0;
            this.transport_monitor_time = 30;
            this.audio_ptime = 40;
            this.audio_buffer_size = 8192;
            this.blank_color = "128.0.0.0";

            //通话等待时长(秒)
            this.max_session_wait_time = 60;

            //门禁设备最长连接时间(秒),一般不会超过200秒
            //全视通室外机并未限制通话时长，我们在代理中设置了最长通话时间
            this.intercom_max_session_connect_time = 200;

            //户户通设备，[名称,LAN最长通话时间(秒),WAN最长通话时间(秒)]
            this.special_p2p_device = "p2p,300,300";
            //室内通设备，[名称,LAN最长通话时间(秒),WAN最长通话时间(秒)]
            //考虑到云端资源的占用，可以对云端通话时长进行不一样的限制
            //LAN通话，最长可以允许24小时
            this.speical_ext_device = "ext,86400,86400";
        }

        public String toJson() {
            Bundle capture = new Bundle();
            capture.putInt("width", capture_video_width);
            capture.putInt("height", capture_video_height);
            capture.putInt("fps", capture_video_fps);
            capture.putInt("format", capture_video_format);

            Bundle camera_name_dict = new Bundle();
            camera_name_dict.putInt("type", 1);
            camera_name_dict.putString("value", camera_name);
            capture.putBundle("camera_name", camera_name_dict);

            Bundle render = new Bundle();
            render.putInt("format", video_render_format);

            Bundle encoder = new Bundle();

            encoder.putInt("profile", video_encode_profile);
            encoder.putInt("avg_bps", video_encode_avg_bps);
            encoder.putInt("max_bps", video_encode_max_bps);
            encoder.putInt("got_size", video_encode_gotsize);
            encoder.putDouble("qcompress", video_encode_qcompress);
            encoder.putDouble("qblur", video_encode_qblur);
            encoder.putInt("qmin", video_encode_qmin);
            encoder.putInt("qmax", video_encode_qmax);
            encoder.putInt("crf", video_encode_crf);
            encoder.putString("preset", video_encode_preset);
            encoder.putString("tune", video_encode_tune);
            encoder.putInt("codec", video_encode_codec);
            encoder.putInt("mtu", video_frame_mtu);

            Bundle device_audio_conf = new Bundle();
            device_audio_conf.putInt("sample_rate", audio_samplerate);
            device_audio_conf.putInt("channels", audio_channels);
            device_audio_conf.putInt("bits_per_sample", bits_per_sample);
            device_audio_conf.putBoolean("disable_aec", disable_aec);

            Bundle record_conf = new Bundle();
            record_conf.putInt("max_record_time", max_record_time);

            Bundle dictionary = new Bundle();
            dictionary.putInt("audio_play_agc_level", audio_play_agc_level);
            dictionary.putInt("audio_send_agc_level", audio_send_agc_level);
            dictionary.putInt("denoise", denoise);
            dictionary.putInt("transport_monitor_time", transport_monitor_time);
            dictionary.putInt("audio_ptime", audio_ptime);
            dictionary.putString("blank_color", blank_color);
            dictionary.putInt("audio_buffer_size", audio_buffer_size);
            dictionary.putInt("max_session_wait_time", max_session_wait_time);
            dictionary.putInt("intercom_max_session_connect_time", intercom_max_session_connect_time);

            dictionary.putString("special_p2p_device", this.special_p2p_device);
            dictionary.putString("speical_ext_device", this.speical_ext_device);

            dictionary.putBundle("capture", capture);
            dictionary.putBundle("video_encode", encoder);
            dictionary.putBundle("device_audio", device_audio_conf);
            dictionary.putBundle("record", record_conf);
            dictionary.putBundle("render", render);
            return BundleToJSON.toString(dictionary);
        }
    }

    public static class SipAuth {
        public String username;
        public String userid;
        public String passwd;

        public SipAuth() {
            this.username = "";
            this.userid = "";
            this.passwd = "";
        }
    }

    public static class SipProxy {
        public String proxy;
        public String identity;
        public String route;
        public String contact_param;
        public int    expires;

        public SipProxy() {
            proxy = "";
            identity = "";
            route = "";
            contact_param = "";
            expires = 300;
        }
    }

    public static class SipConfig {
        public int     session_expires;
        public boolean use_rport;
        public boolean reuse_authorization;
        public boolean expire_old_registration_contacts;
        public int     dscp;
        public boolean use_ipv6;
        public int     sip_port_range;
        public int     sip_listen_port;
        public String  transport;
        public boolean one_matching_codec;
        public boolean use_double_registrations;
        public boolean add_dates;
        public int     keepalive_period;
        public boolean tcp_tls_keepalive;
        public String  user_agent;
        public boolean use_exosip2_version;
        public String  default_contact;
        public int     max_calls;
        public String  answer_options;
        public boolean prevent_colliding_calls;

        /**
         * 支持多个账号
         */
        public List<SipAuth>  auths;
        public List<SipProxy> proxies;

        /**
         * ICE 配置，一般只需要配置 stun_server
         */
        public String  turn_server;
        public String  turn_username;
        public String  turn_pwd;
        public String  turn_auth_type;
        public String  turn_pwd_type;
        public String  turn_conn_type;
        public String  turn_auth_realm;
        public String  stun_server;
        public boolean loopaddr;
        public boolean aggressive;

        public SipConfig() {
            this.session_expires = 0;
            this.use_rport = true;
            this.reuse_authorization = false;
            this.expire_old_registration_contacts = false;
            this.dscp = 0x1a;
            this.use_ipv6 = false;
            this.sip_port_range = 0;
            this.sip_listen_port = 0;
            this.one_matching_codec = false;
            this.use_double_registrations = false;
            this.add_dates = false;
            this.keepalive_period = 300;
            this.tcp_tls_keepalive = false;
            this.user_agent = "jxhousekeeper/1.0";
            this.use_exosip2_version = true;
            this.default_contact = "";
            this.max_calls = 10;
            this.answer_options = "";
            this.prevent_colliding_calls = false;
            this.auths = new ArrayList<>();
            this.proxies = new ArrayList<>();

            this.turn_server = "";
            this.turn_username = "";
            this.turn_pwd = "";
            this.turn_auth_type = "static";
            this.turn_pwd_type = "plain";
            this.turn_conn_type = "udp";
            this.turn_auth_realm = "";
            this.stun_server = "";
            this.loopaddr = true;
            this.aggressive = true;
        }

        public SipConfig(String user_id,
                         String password,
                         String transport,
                         String sip_server,
                         int server_port,
                         int stun_port,
                         boolean use_ice) {
            String proxy_name = "";
            String identity = "";
            String stun_server = "";

            if (sip_server != null) {
                proxy_name = String.format("<sip:%s:%d>", sip_server, server_port);
                identity = String.format("sip:%s@%s:%d", user_id, sip_server, server_port);
                stun_server = String.format("%s:%d", sip_server, stun_port);
            }

            this.session_expires = 0;
            this.use_rport = true;
            this.reuse_authorization = false;
            this.expire_old_registration_contacts = false;
            this.dscp = 0x1a;
            this.use_ipv6 = false;
            this.sip_port_range = 0;
            this.sip_listen_port = 0;
            this.one_matching_codec = false;
            this.use_double_registrations = false;
            this.add_dates = false;
            this.keepalive_period = 300;
            this.tcp_tls_keepalive = false;
            this.user_agent = "jxhousekeeper/1.0";
            this.use_exosip2_version = true;
            this.default_contact = "";
            this.max_calls = 10;
            this.answer_options = "";
            this.prevent_colliding_calls = false;
            this.auths = new ArrayList<>();
            this.proxies = new ArrayList<>();
            if (user_id != null) {
                SipAuth auth = new SipAuth();
                auth.userid = user_id;
                auth.username = user_id;
                auth.passwd = password;
                this.auths.add(auth);
            }

            if (!proxy_name.isEmpty()) {
                SipProxy proxy = new SipProxy();
                proxy.proxy = proxy_name;
                proxy.identity = identity;
                this.proxies.add(proxy);
            }
            if (use_ice) {
                this.turn_server = "";
                this.turn_username = "";
                this.turn_pwd = "";
                this.turn_auth_type = "static";
                this.turn_pwd_type = "plain";
                this.turn_conn_type = "udp";
                this.turn_auth_realm = "";
                this.stun_server = stun_server;
                this.loopaddr = true;
                this.aggressive = true;
            }
        }

        public String toJson() {

            ArrayList<Bundle> auth_array = new ArrayList<>();

            for (SipAuth auth : auths) {
                Bundle dict = new Bundle();
                dict.putString("username", auth.username);
                dict.putString("userid", auth.userid);
                dict.putString("passwd", auth.passwd);
                auth_array.add(dict);
            }

            ArrayList<Bundle> proxy_array = new ArrayList<>();
            for (SipProxy proxy : proxies) {
                Bundle dict = new Bundle();
                dict.putString("proxy", proxy.proxy);
                dict.putString("identity", proxy.identity);
                dict.putString("route", proxy.route);
                dict.putString("contact_param", proxy.contact_param);
                dict.putInt("expires", proxy.expires);
                proxy_array.add(dict);
            }

            Bundle sip = new Bundle();
            sip.putInt("session_expires", this.session_expires);
            sip.putBoolean("use_rport", this.use_rport);
            sip.putBoolean("reuse_authorization", this.reuse_authorization);
            sip.putBoolean("expire_old_registration_contacts", this.expire_old_registration_contacts);
            sip.putInt("dscp", this.dscp);
            sip.putBoolean("use_ipv6", this.use_ipv6);
            sip.putInt("sip_port_range", this.sip_port_range);
            sip.putInt("sip_listen_port", this.sip_listen_port);
            sip.putString("transport", this.transport);
            sip.putBoolean("one_matching_codec", this.one_matching_codec);
            sip.putBoolean("use_double_registrations", this.use_double_registrations);
            sip.putBoolean("add_dates", this.add_dates);
            sip.putInt("keepalive_period", this.keepalive_period);
            sip.putBoolean("tcp_tls_keepalive", this.tcp_tls_keepalive);
            sip.putString("user_agent", this.user_agent);
            sip.putBoolean("use_exosip2_version", this.use_exosip2_version);
            sip.putString("default_contact", this.default_contact);
            sip.putInt("max_calls", this.max_calls);
            sip.putString("answer_options", this.answer_options);
            sip.putBoolean("prevent_colliding_calls", this.prevent_colliding_calls);

            if (auth_array.size() > 0) {
                sip.putSerializable("auth", auth_array);
            }
            if (proxy_array.size() > 0) {
                sip.putSerializable("proxy", proxy_array);
            }

            Bundle conf = new Bundle();
            if (!this.stun_server.isEmpty()) {
                Bundle ice = new Bundle();
                ice.putString("turn_server", this.turn_server);
                ice.putString("turn_username", this.turn_username);
                ice.putString("turn_pwd", this.turn_pwd);
                ice.putString("turn_auth_type", this.turn_auth_type);
                ice.putString("turn_pwd_type", this.turn_pwd_type);
                ice.putString("turn_conn_type", this.turn_conn_type);
                ice.putString("turn_auth_realm", this.turn_auth_realm);
                ice.putString("stun_server", this.stun_server);
                ice.putBoolean("loopaddr", this.loopaddr);
                ice.putBoolean("aggressive", this.aggressive);
                conf.putBundle("ice", ice);
            }

            conf.putBundle("sip", sip);
            return BundleToJSON.toString(conf);
        }
    }
}
