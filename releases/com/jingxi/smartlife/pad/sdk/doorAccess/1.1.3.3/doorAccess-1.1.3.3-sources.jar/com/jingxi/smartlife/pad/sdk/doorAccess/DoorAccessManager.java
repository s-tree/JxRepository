package com.jingxi.smartlife.pad.sdk.doorAccess;

import android.view.SurfaceView;

import com.intercom.sdk.IntercomObserver;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorDeviceManager;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorSecurityUtil;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorDevice;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorRecordBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.ExtDeviceBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.SecurityStateBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.DoorAccessConversationUI;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.DoorAccessListUI;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.DoorAccessListener;

import java.util.List;

public abstract class DoorAccessManager {
    private static DoorAccessManager instance;

    public static DoorAccessManager getInstance(){
        if(instance == null){
            synchronized (DoorAccessManager.class){
                if(instance == null){
                    instance = new DoorAccessManagerImpl();
                }
            }
        }
        return instance;
    }

    /**
     * 监听开锁和呼叫事件
     * @param listener
     */
    public abstract void setDoorAccessListener(DoorAccessListener listener);

    /**
     * 设备列表页面时监听设备变化
     * @param listener
     */
    public abstract void setListUIListener(DoorAccessListUI listener);

    /**
     * 会话页面时监听新事件
     * @param listener
     */
    public abstract void addConversationUIListener(DoorAccessConversationUI listener);

    /**
     * 移除会话监听
     * @param listener
     */
    public abstract void removeConversationUIListener(DoorAccessConversationUI listener);

    /**
     * 在室内通列表页面时监听此回调
     * @param onExtDeviceChanged
     */
    public abstract void setExtDeviceChangedListener(DoorDeviceManager.OnExtDeviceChanged onExtDeviceChanged);

    /**
     * 初始化，第一次时无需调用
     */
    public abstract void init();

    /**
     * 结束门禁服务
     */
    public abstract void unInit();

    /**
     * 代理是否已经离线
     * @return
     */
    public abstract boolean isProxyOffline(String familyID);

    /**
     *
     * @param familyID      初始化对应的门禁
     * @param buttonKey
     */
    public abstract void startFamily(String familyID, String buttonKey);

    /**
     * 反初始化所有familyID的门禁
     */
    public abstract void stopAllFamily();

    /**
     *
     * @param familyID      反初始化对应的门禁
     */
    public abstract void stopFamily(String familyID);

    /**
     * 部分情况下会出现门禁连接断开且未能自动重连，可调用此方法重新连接
     */
    public abstract void resumeDoorAccess();

    /**
     * 获取所有在线的设备
     * @return
     */
    public abstract List<DoorDevice> getDevices(String familyID);

    /**
     * 获取设备在线状态
     */
    public abstract void checkDeviceOnline(String familyID);

    /**
     * 外呼
     * @return sessionId
     */
    public abstract String monitor(String familyID, DoorDevice doorDevice);

    /**
     * 当前是否支持户户通模式
     * @param familyID
     * @return
     */
    public abstract boolean isSupportP2P(String familyID);

    /**
     * 户户通消息外呼
     * @param calledNumber 要外呼的房号
     *                     掩码固定为         2 2 4
     *                     例如               一栋二单元304室
     *                     calledNumber 为    01 02 0304
     * @return
     */
    public abstract String monitorP2P(String familyID,String calledNumber);

    /**
     * 接听呼叫
     */
    public abstract void acceptCall(String sessionId);

    /**
     * 挂断呼叫
     */
    public abstract void hangupCall(String sessionId);

    /**
     * 更新门禁呼叫视图
     * @param surfaceView
     */
    public abstract void updateCallWindow(String sessionId, SurfaceView surfaceView);

    /**
     * 是否启用传输给对方的音频
     */
    public abstract void enableLocalToRemoteAudio(String familyID,String sessionId,boolean isEnable);

    /**
     * 是否启用对方传输过来的音频
     */
    public abstract void enableRemoteToLocalAudio(String familyID,String sessionId,boolean isEnable);

    /**
     * 是否启用传输给对方的视频
     */
    public abstract void enableLocalToRemoteVideo(String familyID,String sessionId,boolean isEnable);

    /**
     * 更新门禁呼叫视图
     * @param surfaceView
     */
    public abstract void updateLocalWindow(SurfaceView surfaceView);

    /**
     *  根据result 获取到挂断的详细原因
     * @param result 挂断时收到的result
     * @return
     */
    public abstract String getHangupMessageByResult(int result);

    /**
     * 获取回放列表
     * @param type {@link DoorRecordBean#RECORD_TYPE_DOOR} or {@link DoorRecordBean#RECORD_TYPE_P2P}
     * @param pageStart     数据的起始下标 0 ...{n}
     * @param pageSize      每次获取到的数据量
     */
    public abstract List<DoorRecordBean> getHistoryListByType(String familyID, @DoorRecordBean.RECORD_TYPE int type, int pageStart, int pageSize);

    /**
     * 获取回放列表
     * @param doorDevice
     * @param pageStart     数据的起始下标 0 ...{n}
     * @param pageSize      每次获取到的数据量
     */
    public abstract List<DoorRecordBean> getHistoryListByDevice(String familyID, DoorDevice doorDevice, int pageStart, int pageSize);

    /**
     * 开始回放
     */
    public abstract void startPlayBack(String sessionId);

    /**
     * 暂停回放
     */
    public abstract void pausePlayBack(String sessionId);

    /**
     * 调整回放进度
     */
    public abstract void seekPlayBack(String sessionId, int seek);

    /**
     * 更新回放视图
     * @param surfaceView
     */
    public abstract void updatePlayBackWindow(String sessionId, SurfaceView surfaceView);

    /**
     * 回放记录的监听
     * @param onPlaybackListener
     */
    public abstract void addPlayBackListener(IntercomObserver.OnPlaybackListener onPlaybackListener);

    /**
     * 删除回放监听
     * @param onPlaybackListener
     */
    public abstract void removePlayBackListener(IntercomObserver.OnPlaybackListener onPlaybackListener);

    /**
     * 开锁（通话过程中）
     * @param sessionID
     */
    public abstract void openDoor(String sessionID);

    /**
     * 注册安防事件监听
     * @param listener
     */
    public abstract void addSecurityListener(DoorSecurityUtil.OnSecurityChangedListener listener);

    /**
     * 移除安防事件监听
     * @param listener
     */
    public abstract void removeSecurityListener(DoorSecurityUtil.OnSecurityChangedListener listener);

    /**
     * 切换安防状态
      * @param familyID
     */
    public abstract void switchSecurityStatus(String familyID);

    /**
     * 查询安防状态
     * @param familyID
     * @return  @link SecurityStateBean#STATE_NODEFENCE} {@link SecurityStateBean#STATE_UNDEFENCE} {@link SecurityStateBean#STATE_DEFENCE}
     */
    public abstract int querySecurityStatus(String familyID);

    /**
     * 关闭安防报警
     * @param familyID
     */
    public abstract void cancelSecurityWarning(String familyID);

    /**
     * 是否支持室内通模式
     * @return
     */
    public abstract boolean isSupportExt(String familyID);

    /**
     * 获取所有的室内通设备
     * 返回的列表中可能会有重复数据，需要手动去重
     * 去重根据 {@link com.intercom.sdk.NetClient#button_key}{@link com.intercom.sdk.NetClient#sub_type} 判断
     * sub_type 参考 {@link com.intercom.sdk.IntercomConstants.NetClientSubType}
     * @return
     */
    public abstract List<ExtDeviceBean> getExtDevices(String familyID,String buttonKey);

    /**
     *
     * @param extDeviceBean
     * @param isMonitor         true        监控模式（对象是底座，有声音，对象是平板，有视频和声音），无需对方接听即可连接，仅为单向通话，对方无任何反馈
     *                           false       呼叫模式 ，双向通话，需要对方接听后才能通话
     * @return
     */
    public abstract String callExt(String familyID,ExtDeviceBean extDeviceBean,boolean isMonitor);
}
