package com.jingxi.smartlife.pad.sdk.doorAccess.base.ui;

import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorEvent;

public interface DoorAccessConversationUI {

    /**
     * 视频流开始传输
     */
    void startTransPort(String sessionID);
    /**
     * 视频流开始传输
     * @param mediaType 1 : Audio
     *                   2 : Video
     */
    void startTransPort(String sessionID,int mediaType);

    /**
     * 新事件
     */
    void refreshEvent(DoorEvent event);
    /**
     *
     */
    int inviteIntercept(DoorEvent inviteEvent);
}
