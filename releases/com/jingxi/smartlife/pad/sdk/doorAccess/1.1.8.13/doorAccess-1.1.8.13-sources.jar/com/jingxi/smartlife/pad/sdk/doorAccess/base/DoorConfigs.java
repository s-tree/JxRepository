package com.jingxi.smartlife.pad.sdk.doorAccess.base;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.text.TextUtils;

import com.intercom.sdk.IntercomConfigure;
import com.intercom.sdk.IntercomConstants;
import com.intercom.sdk.utils;
import com.jingxi.smartlife.pad.sdk.utils.BuildConfig;
import com.jingxi.smartlife.pad.sdk.utils.JXContextWrapper;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class DoorConfigs {
    public static final  String DOOR_LOG_TAG            = "door";
    private static final String NO_VIDEO_JPG            = "novideo.jpg";
    private static final String PROXY_MULTICAST_ADDRESS = "238.18.18.1";

    protected static final String          APP_CHANNEL         = "jx_dr";
    protected static final String          PATH                = "sdcard/data/doorkeeper/access/";//文件保存路径
    protected static final String          SERVER_PATH         = "sdcard/data/doorkeeper/server/";//文件保存路径
    protected static final String          INTERCOM_SERVER_URL = "http://sip.house-keeper.cn/opensip/v2/register";
    protected static final String          PROXY_SERVER_URL    = "http://transit.house-keeper.cn/keepalive";
    protected static final String          sslCertPath         = "/sdcard/tls";
    protected static final String          PORT_CONF = "30000,35000,40000";
    public static final    String          TLS_DIR_NAME        = "tls";
    public static final    String          DEVICE_MONITOR_URL  = "";
    protected static       DoorKit.Options options             = DoorKit.Options.getDefault();

    public static int getMaxRecordCount() {
        return options.maxRecordCount;
    }

    public static String getMediaDir() {
        return new File(options.doorAccessWorkDir, "record").getAbsolutePath();
    }

    public static int getClientType() {
        return options.platform;
    }

    /**
     * 初始化完成后保存的 familyID - clientID 对应表
     */
    protected static Map<String, String> clientIds = new HashMap<>();

    protected static String getAppConf() {
        PackageManager packageManager = JXContextWrapper.context.getPackageManager();
        String version = "";
        try {
            PackageInfo info = packageManager.getPackageInfo(JXContextWrapper.context.getPackageName(),0);
            version = TextUtils.concat(info.versionName,".",String.valueOf(info.versionCode)).toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        IntercomConfigure.AppConf appConf = new IntercomConfigure.AppConf(version,options.channel,options.systemId,
                PATH,
                getMediaDir(), false, BuildConfig.DEBUG ? IntercomConstants.LogLevel.Info : IntercomConstants.LogLevel.Fatal, false
        , options.proxyWorkDir);
        return appConf.toJson();
    }

    protected static String getPortConf(){
        IntercomConfigure.PortConf portConf = new IntercomConfigure.PortConf(options.portConf, null, null);
        return portConf.toJson();
    }

    protected static String getIntercomConfig() {
        return new IntercomConfigure.IntercomConfig().toJson();
    }

    protected static byte[][] getNoVideoImage() {
        /**
         * 图片要在10KB以内
         */
        byte[][] arr = new byte[1][];
        arr[0] = utils.readResourceFromFile(JXContextWrapper.context.getAssets(), NO_VIDEO_JPG);
        return arr;
    }

    protected static String getClientConf(String familyDockSN, String buttonKey) {
        IntercomConfigure.ClientConf clientConf = new IntercomConfigure.ClientConf(
                IntercomConstants.NetClientType.NetClientTypeClient,
                options.platform,
                options.clientID,
                familyDockSN,
                buttonKey,
                options.alias,
                options.publishID);
        return clientConf.toJson();
    }

    protected static String getProxyConfig() {
        return new IntercomConfigure.ProxyConf(10000,
                PROXY_MULTICAST_ADDRESS,
                60,
                true,
                true,
                options.proxyServerUrl,
                options.sslCertPath,
                "",
                options.deviceMonitorUrl,
                false).toJson();
    }

    protected static String getServerConfig() {
        return new IntercomConfigure.ServerConfig(
                options.intercomServerUrl,
                "",
                "",
                "",
                0).toJson();
    }
}
