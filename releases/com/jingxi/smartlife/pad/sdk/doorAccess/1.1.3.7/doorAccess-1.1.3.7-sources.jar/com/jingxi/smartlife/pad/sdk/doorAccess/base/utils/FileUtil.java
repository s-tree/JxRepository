package com.jingxi.smartlife.pad.sdk.doorAccess.base.utils;

import java.io.File;

public class FileUtil {

    public static void deleteFile(File deleteFile){
        if(!deleteFile.exists()){
            return;
        }
        if(deleteFile.isDirectory()){
            File[] listFiles = deleteFile.listFiles();
            for(File file : listFiles){
                deleteFile(deleteFile);
            }
        }
        try {
            deleteFile.deleteOnExit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
