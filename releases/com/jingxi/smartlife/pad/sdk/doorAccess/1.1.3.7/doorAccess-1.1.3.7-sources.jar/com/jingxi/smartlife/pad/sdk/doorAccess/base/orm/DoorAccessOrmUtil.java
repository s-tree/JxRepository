package com.jingxi.smartlife.pad.sdk.doorAccess.base.orm;

import android.text.TextUtils;

import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorConfigs;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorDevice;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorRecordBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.utils.FileUtil;
import com.litesuits.orm.db.assit.QueryBuilder;

import java.io.File;
import java.util.List;

public class DoorAccessOrmUtil extends LiteOrmUtil {

    public static void saveRecord(DoorRecordBean recordBean){
        long count = getLiteOrm().queryCount(DoorRecordBean.class);
        if(count >= DoorConfigs.getMaxRecordCount()){
            List<DoorRecordBean> recordBeans = getLiteOrm().query(DoorRecordBean.class);
            DoorRecordBean willDelete = recordBeans.get(0);
            deleteRecordFile(willDelete);
            getLiteOrm().delete(willDelete);
        }
        getLiteOrm().save(recordBean);
    }

    public static void deleteRecord(DoorRecordBean recordBean){
        deleteRecordFile(recordBean);
        getLiteOrm().delete(recordBean);
    }

    public static void deleteListRecord(List<DoorRecordBean> recordBeans){
        for(DoorRecordBean doorRecordBean : recordBeans){
            deleteRecordFile(doorRecordBean);
        }
        getLiteOrm().delete(recordBeans);
    }

    public static void deleteAllByType(String familyID,@DoorRecordBean.RECORD_TYPE int type){
        QueryBuilder<DoorRecordBean> queryBuilder = QueryBuilder.create(DoorRecordBean.class)
                .whereEquals("familyID",familyID)
                .whereAppendAnd()
                .whereEquals("record_type",type);
        List<DoorRecordBean> recordBeans = getLiteOrm().query(queryBuilder);
        deleteListRecord(recordBeans);
    }

    public static List<DoorRecordBean> queryRecordsByType(String familyID,@DoorRecordBean.RECORD_TYPE int type,int pageStart,int pageSize){
        QueryBuilder<DoorRecordBean> queryBuilder = QueryBuilder.create(DoorRecordBean.class)
                .whereEquals("familyID",familyID)
                .whereAppendAnd()
                .whereEquals("record_type",type)
                .appendOrderDescBy("startTime")
                .limit(pageStart, pageSize);
        return getLiteOrm().query(queryBuilder);
    }

    public static List<DoorRecordBean> queryRecordsByDevice(String familyID, DoorDevice doorDevice, int pageStart, int pageSize){
        QueryBuilder<DoorRecordBean> queryBuilder = QueryBuilder.create(DoorRecordBean.class)
                .whereEquals("familyID",familyID)
                .whereAppendAnd()
                .whereEquals("name",doorDevice.name)
                .appendOrderDescBy("startTime")
                .limit(pageStart, pageSize);
        return getLiteOrm().query(queryBuilder);
    }

    public static List<DoorRecordBean> queryRecordBySession(String sessionId){
        QueryBuilder<DoorRecordBean> queryBuilder = QueryBuilder.create(DoorRecordBean.class)
                .whereEquals("session_id",sessionId);
        return getLiteOrm().query(queryBuilder);
    }


    public static void clearRecord(){
        getLiteOrm().deleteAll(DoorRecordBean.class);
    }

    public static void updateThumb(String sessionId,String thumbPath){
        List<DoorRecordBean> recordBeans = queryRecordBySession(sessionId);
        if(recordBeans == null || recordBeans.isEmpty()){
            return;
        }
        for(DoorRecordBean recordBean : recordBeans){
            recordBean.thumbPath = thumbPath;
        }
        getLiteOrm().update(recordBeans);
    }

    /**
     * 更新通话成功的事件
     * @param sessionId
     */
    public static void updateChatSuccess(String sessionId){
        List<DoorRecordBean> recordBeans = queryRecordBySession(sessionId);
        if(recordBeans == null || recordBeans.isEmpty()){
            return;
        }
        for(DoorRecordBean recordBean : recordBeans){
            if(recordBean.chatEvent == DoorRecordBean.CALL_EVENT_CALLOUT){
                recordBean.chatEvent = DoorRecordBean.CALL_EVENTCALLOUT_CHATTING;
            }
            else if(recordBean.chatEvent == DoorRecordBean.CALL_EVENT_RECEIVER){
                recordBean.chatEvent = DoorRecordBean.CALL_EVENT_RECEIVER_CHATTING;
            }
        }
        getLiteOrm().update(recordBeans);
    }

    /**
     * 更新通话挂断的事件
     * 外呼时有取消和被挂断
     * 收到呼叫时有被取消和自己挂断
     * @param sessionId
     */
    public static void updateChatHangup(String sessionId,boolean fromSelf){
        List<DoorRecordBean> recordBeans = queryRecordBySession(sessionId);
        if(recordBeans == null || recordBeans.isEmpty()){
            return;
        }
        for(DoorRecordBean recordBean : recordBeans){
            if(recordBean.chatEvent == DoorRecordBean.CALL_EVENT_CALLOUT){
                recordBean.chatEvent = fromSelf ? DoorRecordBean.CALL_EVENT_CALLOUT_CANCEL : DoorRecordBean.CALL_EVENT_CALLOUT_REJECT;
            }
            else if(recordBean.chatEvent == DoorRecordBean.CALL_EVENT_RECEIVER){
                recordBean.chatEvent = fromSelf ? DoorRecordBean.CALL_EVENT_RECEIVER_REJECT : DoorRecordBean.CALL_EVENT_RECEIVER_CANCEL;
            }
            recordBean.chat_time = (int) ((System.currentTimeMillis() - recordBean.startTime) / 1000);
        }
        getLiteOrm().update(recordBeans);
    }

    private static void deleteRecordFile(DoorRecordBean recordBean){
        try{
            String sessionDir = TextUtils.concat(DoorConfigs.getMediaDir(),recordBean.session_id).toString();
            FileUtil.deleteFile(new File(sessionDir));
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    /**
     * 获取通话事件
     * @param sessionId
     * @return
     */
    public static int getChatEvent(String sessionId){
        List<DoorRecordBean> recordBeans = queryRecordBySession(sessionId);
        if(recordBeans == null || recordBeans.isEmpty()){
            return -1;
        }
        return recordBeans.get(0).chatEvent;
    }
}
