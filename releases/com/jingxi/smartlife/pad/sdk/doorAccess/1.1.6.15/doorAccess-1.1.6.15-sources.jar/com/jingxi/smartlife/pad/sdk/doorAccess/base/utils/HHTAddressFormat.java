package com.jingxi.smartlife.pad.sdk.doorAccess.base.utils;

/**
 * Created by Administrator on 2017/3/7.
 */

public class HHTAddressFormat {
    private static String[] adds = new String[]{"期","栋","单元","楼","室","路由",""};

    public static String formatAddress(String addressCode,int[] tags){
        int index = 0;
        StringBuilder builder = new StringBuilder();
        for(int i = 0 ; i < tags.length ; i++){
            int number = tags[i];
            if(number == 0){
                continue;
            }
            String text = addressCode.substring(index,index + number);
            index += number;
            builder.append(Integer.parseInt(text) + adds[i]);
        }
        return builder.toString();
    }
}
