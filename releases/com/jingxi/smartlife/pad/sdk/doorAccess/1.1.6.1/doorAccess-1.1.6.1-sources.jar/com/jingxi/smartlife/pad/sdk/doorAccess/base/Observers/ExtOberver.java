package com.jingxi.smartlife.pad.sdk.doorAccess.base.Observers;

import com.intercom.sdk.IntercomManager;
import com.intercom.sdk.IntercomMessage;
import com.intercom.sdk.NetClient;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorManagerUtil;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorMessageFactory;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorSessionManager;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorEvent;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorRecordBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.orm.DoorAccessOrmUtil;

public class ExtOberver extends BaseDoorObserver {

    @Override
    public boolean onRinging(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message) {
        /**
         * 此次monitor 的包，直接接听,且更新DoorSessionManager 中的DoorEvent
         */
        if(DoorSessionManager.getStatus(message.getSession_id()) == DoorSessionManager.MONITOR){
//            DoorManagerUtil.pickUp(intercom,message.getSession_id());
//            DoorEvent event = new DoorEvent();
//            event.netClient = netClient;
//            event.intercom = intercom;
//            event.message = message;
//            event.type = DoorEvent.TYPE_EXT;
//            event.sessionId = message.getSession_id();
//            event.cmd = message.getCmd();
//            event.router = router;
//            DoorSessionManager.setDoorEvent(message.getSession_id(),event);
//            DoorManagerUtil.enableRemoteAudio(intercom.id,message.getSession_id(),true);
            //外呼收到的ring不需要pickup
            super.onRinging(intercom,router,netClient,message);
            return false;
        }else {
            boolean isMonitor = DoorMessageFactory.isExtMonitor(IntercomManager.base64(false,message.getContent()));
//            DoorManagerUtil.enableLocalAudio(intercom.id,message.getSession_id(),true);
//            DoorManagerUtil.enableLocalVideo(intercom.id,message.getSession_id(),true);
            int event = DoorRecordBean.CALL_EVENT_RECEIVER;

            if(isMonitor){
                /**
                 * monitor 模式下自动接听
                 */
                DoorEvent doorEvent = new DoorEvent();
                doorEvent.netClient = netClient;
                doorEvent.intercom = intercom;
                doorEvent.message = message;
                doorEvent.type = DoorEvent.TYPE_EXT;
                doorEvent.sessionId = message.getSession_id();
                doorEvent.cmd = message.getCmd();
                doorEvent.router = router;
                DoorSessionManager.setDoorEvent(message.getSession_id(),doorEvent);
                DoorManagerUtil.pickUp(intercom,message.getSession_id());
                DoorManagerUtil.enableRemoteAudio(intercom.id,message.getSession_id(),false);
                event = DoorRecordBean.CALL_EVENT_EXT_BE_MONITORED;
            }else{
            }

            DoorRecordBean recordBean = DoorRecordBean.parseExtRecord(
                    intercom.id,
                    message.getSession_id(),
                    netClient.getButton_key(),
                    netClient.getSub_type(),
                    event);
            DoorAccessOrmUtil.saveRecord(recordBean);
            boolean isNeedShowUI = super.onRinging(intercom,router,netClient,message);
            return !isMonitor && isNeedShowUI;
        }
    }

    @Override
    public boolean onPickup(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message) {
        boolean isNeedShowUI = super.onPickup(intercom, router, netClient, message);
        return isNeedShowUI;
    }

    @Override
    public boolean onPickupByOther(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message) {
        return super.onPickupByOther(intercom,router,netClient,message);
    }

    @Override
    public boolean onHangup(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message) {
        return super.onHangup(intercom,router,netClient,message);
    }
}
