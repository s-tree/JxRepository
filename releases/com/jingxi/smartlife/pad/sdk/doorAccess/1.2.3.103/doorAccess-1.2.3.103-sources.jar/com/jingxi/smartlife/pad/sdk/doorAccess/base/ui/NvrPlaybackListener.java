package com.jingxi.smartlife.pad.sdk.doorAccess.base.ui;

public interface NvrPlaybackListener {
    /**
     * nvr 回放
     * @param sessionId
     * @param nptTime nptTime:{"npt":"npt=0.000000-86399.000000"}
     */
    void nvrPlayBackTime(String sessionId,String nptTime);
}
