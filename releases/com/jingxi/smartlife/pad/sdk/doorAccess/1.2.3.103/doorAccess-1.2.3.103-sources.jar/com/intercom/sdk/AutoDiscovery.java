package com.intercom.sdk;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import com.intercom.base.annotations.CalledByNative;

import java.lang.ref.WeakReference;

/**
 * 自动发现局域网内其他的设备，只适用于别墅方案
 */

public class AutoDiscovery {
    /**
     * Accessed by native methods: provides access to C++ AutoDiscovery object
     */
    @SuppressWarnings("unused")
    private long mNativeJavaObj;

    private final OnAutoDiscoveryHandler handler;

    private final CallbackHandler callback;

    //当前网络发现其他主机存在
    public static final int AUTO_DETECT_SUCCESS = 0;
    //socket 创建失败？没有网络权限？
    public static final int AUTO_DETECT_SOCK_ERR = -1;
    //当前网络内没有发现其他主机存在
    public static final int AUTO_DETECT_TIMEOUT = -2;

    public interface OnAutoDiscoveryHandler {
        //net_client is NetClient Json Object
        void OnAutoDiscoveryClient(String net_client);
    }

    public AutoDiscovery(OnAutoDiscoveryHandler handler) {
        this.mNativeJavaObj = 0;
        this.handler = handler;
        this.callback = new CallbackHandler(this);
    }

    public boolean start(String conf, String net_client) {
        return nativeStart(new WeakReference<AutoDiscovery>(this), conf, net_client);
    }

    public void stop() {
        nativeStop();
    }

    public void release() {
        nativeRelease();
    }

    @Override
    protected void finalize() {
        nativeFinalize();
    }

    public boolean accept(String net_client) {
        return nativeAccept(net_client);
    }

    public boolean decline(String client_id) {
        return nativeDecline(client_id);
    }

    private static class CallbackHandler extends Handler {
        private final WeakReference<AutoDiscovery> discovery;

        CallbackHandler(AutoDiscovery manager) {
            this.discovery = new WeakReference<>(manager);
        }

        @Override
        public void handleMessage(Message message) {
            AutoDiscovery discovery = this.discovery.get();
            if (discovery != null) {
                if (message.what == 0) {
                    String client_string = message.getData().getString("client");
                    discovery.handler.OnAutoDiscoveryClient(client_string);
                }
            } else {
                super.handleMessage(message);
            }
        }
    }

    /**
     * 探测网络内有没有其他主机存在，放在子线程执行
     *
     * @param multicast_address:组播地址
     * @param ms:超时时间，比如2000毫秒
     * @return : result and address and system_id
     */
    static public Bundle detectHost(String multicast_address, int ms) {
        return nativeDetectHost(multicast_address, ms);
    }

    //---------------------------------------------------------
    // Java methods called from the native side
    //--------------------
    @CalledByNative
    @SuppressWarnings("unused")
    private static void postEventFromNative(Object thiz, String net_client) {
        AutoDiscovery discovery = (AutoDiscovery) ((WeakReference) thiz).get();
        if (discovery == null || discovery.callback == null)
            return;

        Message m = new Message();
        m.what = 0;
        Bundle bundle = new Bundle();
        bundle.putString("client", net_client);
        m.setData(bundle);
        discovery.callback.sendMessage(m);
    }

    private native final boolean nativeStart(Object weak_this, String conf, String net_client);

    private native final void nativeStop();

    private native final void nativeRelease();

    private native final void nativeFinalize();

    private native final boolean nativeAccept(String net_client);

    private native final boolean nativeDecline(String client_id);

    private static final native Bundle nativeDetectHost(String multicast_address, int ms);
}
