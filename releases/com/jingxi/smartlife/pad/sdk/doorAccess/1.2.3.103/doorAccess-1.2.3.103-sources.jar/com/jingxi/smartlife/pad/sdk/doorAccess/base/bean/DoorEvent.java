package com.jingxi.smartlife.pad.sdk.doorAccess.base.bean;

import android.support.annotation.IntDef;
import android.text.TextUtils;

import com.intercom.sdk.IntercomConstants;
import com.intercom.sdk.IntercomManager;
import com.intercom.sdk.IntercomMessage;
import com.intercom.sdk.NetClient;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public class DoorEvent {

    public static final int TYPE_DOOR = 0;
    public static final int TYPE_EXT = 1;
    public static final int TYPE_P2P = 2;

    @IntDef({
            TYPE_DOOR,TYPE_EXT,TYPE_P2P
    })
    @Retention(RetentionPolicy.SOURCE)
    public @interface DoorMessageType{

    }

    public String sessionId;

    public String cmd;

    public @DoorMessageType int type;

    public IntercomManager.Intercom intercom;

    public IntercomMessage message;

    public int router;

    public NetClient netClient;

    public String getCmd(){
        return message.getCmd();
    }

    public boolean canStartUI(){
        return TextUtils.equals(cmd, IntercomConstants.kIntercomCommandRinging);
    }
}
