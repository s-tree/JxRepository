package com.intercom.sdk.peripheral;

import java.io.IOException;
import java.nio.ByteBuffer;

/**
 * 串口读写，如果是android 8.0，可以使用Framework SerialPort
 */

public class JavaSerial {

    public static class SerialAttributes {
        public static final int PARITY_ODD = 0;
        public static final int PARITY_EVEN = 1;
        public static final int PARITY_NONE = 2;

        public static final int CHOICES_RAW = 0;
        public static final int CHOICES_CANONICAL = 1;

        public final String name;
        public final int open_flags;
        public final int parity;
        public final int baud_rate;
        public final int data_bits;
        public final int stop_bits;
        public final int hardware_flow_control;
        public final int software_flow_control;
        public final int input_mode;

        public SerialAttributes(String name,
                                int open_flags,
                                int baud_rate) {
            this.name = name;
            this.open_flags = open_flags;
            this.parity = PARITY_NONE;
            this.data_bits = 8;
            this.stop_bits = 1;
            this.hardware_flow_control = 0;
            this.software_flow_control = 0;
            this.input_mode = CHOICES_RAW;
            this.baud_rate = baud_rate;
        }

        public SerialAttributes(String name,
                                int open_flags,
                                int parity,
                                int baud_rate,
                                int data_bits,
                                int stop_bits,
                                int hardware_flow_control,
                                int software_flow_control,
                                int input_mode) {
            this.name = name;
            this.open_flags = open_flags;
            this.parity = parity;
            this.baud_rate = baud_rate;
            this.data_bits = data_bits;
            this.stop_bits = stop_bits;
            this.hardware_flow_control = hardware_flow_control;
            this.software_flow_control = software_flow_control;
            this.input_mode = input_mode;
        }
    }

    /**
     * Accessed by native methods: provides access to C++ JavaSerial object
     */
    @SuppressWarnings("unused")
    private int mNativeContext;


    public JavaSerial(SerialAttributes attributes) throws IllegalArgumentException, IOException {
        if (attributes == null) {
            throw new IllegalArgumentException("Illegal null serial name");
        }
        native_open(attributes.name,
                attributes.open_flags,
                attributes.parity,
                attributes.baud_rate,
                attributes.data_bits,
                attributes.stop_bits,
                attributes.hardware_flow_control,
                attributes.software_flow_control,
                attributes.input_mode);
    }

    public void close() throws IOException {
        native_close();
    }

    public int read(ByteBuffer buffer) throws IOException {
        if (buffer.isDirect()) {
            return native_read_direct(buffer, buffer.remaining());
        } else if (buffer.hasArray()) {
            return native_read_array(buffer.array(), buffer.remaining());
        } else {
            throw new IllegalArgumentException("buffer is not direct and has no array");
        }
    }

    public void write(ByteBuffer buffer, int length) throws IOException {
        if (buffer.isDirect()) {
            native_write_direct(buffer, length);
        } else if (buffer.hasArray()) {
            native_write_array(buffer.array(), length);
        } else {
            throw new IllegalArgumentException("buffer is not direct and has no array");
        }
    }

    /**
     * Sends a stream of zero valued bits for 0.25 to 0.5 seconds
     */
    public void sendBreak() {
        native_send_break();
    }

    private native final void native_open(String name,
                                          int flags,
                                          int parity,
                                          int baud_rate,
                                          int data_bits,
                                          int stop_bits,
                                          int hardware_flow_control,
                                          int software_flow_control,
                                          int input_mode) throws IOException;

    private native final void native_close();

    private native final int native_read_array(byte[] buffer, int length) throws IOException;

    private native final int native_read_direct(ByteBuffer buffer, int length) throws IOException;

    private native final void native_write_array(byte[] buffer, int length) throws IOException;

    private native final void native_write_direct(ByteBuffer buffer, int length) throws IOException;

    private native final void native_send_break();
}
