package com.intercom.sdk;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import com.intercom.base.annotations.CalledByNative;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.TimeZone;

/**
 * 将慧管家存储的访客记录转码成MP4格式，可以使用通用播放器播放
 * 可以同时混音远端和近端音频，添加时间戳水印
 */

public class MediaConverter {
  public static final int Result_OK = 0;
  //源文件没找到或者打不开
  public static final int Result_ERR_FILE = 1;
  //源文件不包含有效数据
  public static final int Result_ERR_NO_DATA = 2;
  //打开编码器失败
  public static final int Result_ERR_ENCODER = 3;
  //内存不够
  public static final int Result_ERR_MEMORY = 4;
  //目标目录只读，也就是没法写输出文件
  public static final int Result_ERR_DIR_READONLY = 5;

  public static final int Result_ERR_Abort = 6;

  /**
   * Accessed by native methods: provides access to C++ MediaConverter object
   */
  @SuppressWarnings("unused")
  private long mNativeJavaObj;

  private final CallbackHandler callback;

  private final MediaConverterHandler handler;

  private final Rect bounds;

  private final Canvas canvas;

  private final Paint paint;

  private final SimpleDateFormat formatter;

  public interface MediaConverterHandler {
    void onMediaConvertReady(String str /*MediaInfo*/);

    void onMediaConvertCompleted(int result, String outfile);

    void onMediaConvertProgress(int progress);
  }


  public MediaConverter(MediaConverterHandler handler) {
    this.handler = handler;
    this.mNativeJavaObj = 0;
    this.callback = new CallbackHandler(this);
    this.bounds = new Rect();
    formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
    formatter.setTimeZone(TimeZone.getDefault());
    paint = new Paint();
    paint.setTextSize(20);
    paint.setTypeface(Typeface.DEFAULT_BOLD);
    paint.setTextAlign(Paint.Align.LEFT);
    paint.setColor(Color.WHITE);
    paint.setAntiAlias(true);
    paint.setFlags(Paint.ANTI_ALIAS_FLAG);
    canvas = new Canvas();
  }

  private static class CallbackHandler extends Handler {
    private final WeakReference<MediaConverter> manager;

    CallbackHandler(MediaConverter manager) {
      this.manager = new WeakReference<>(manager);
    }

    @Override
    public void handleMessage(Message message) {
      MediaConverter manager = this.manager.get();
      if (manager != null) {
        if (message.what == 0) {
          String str = message.getData().getString("info");
          manager.handler.onMediaConvertReady(str);
        } else if (message.what == 1) {
          int result = message.getData().getInt("result");
          String file = message.getData().getString("file");
          manager.handler.onMediaConvertCompleted(result, file);
        } else if (message.what == 2) {
          int progress = message.getData().getInt("progress");
          manager.handler.onMediaConvertProgress(progress);
        }
      } else {
        super.handleMessage(message);
      }
    }
  }

  /**
   * 开始转码
   *
   * @param infile:源文件全路径，一定是.rec类型的文件
   * @param outfile:目标文件：一定是.mp4类型的文件
   * @param watermark:是否在每一帧视频上打印时间戳水印
   * @return: true /false
   */
  public boolean start(String infile, String outfile, boolean watermark) {
    return nativeStart(new WeakReference<MediaConverter>(this),
            infile, outfile, watermark);
  }

  /**
   * 停止转码，释放资源，没有完成的情况下，会取消转码
   */
  public void stop() {
    nativeStop();
  }

  public void release() {
    nativeRelease();
  }

  @Override
  protected void finalize() {
    nativeFinalize();
  }

  private void addWaterMark(Bitmap bitmap, long timestamp) {
    long ms = (timestamp - 11644473600000000L) / 1000;
    String str = formatter.format(ms);

    canvas.setBitmap(bitmap);
    paint.getTextBounds(str, 0, str.length(), bounds);
    int x = bitmap.getWidth() - (bounds.width()) - 10;
    int y = Math.abs(bounds.top) + 5;
    canvas.drawText(str, x, y, paint);
    canvas.setBitmap(null);
  }


  //---------------------------------------------------------
  // Java methods called from the native side
  //--------------------
  @SuppressWarnings("unused")
  private static void onMediaConvertReady(Object converter_ref, String str) {
    MediaConverter converter = (MediaConverter) ((WeakReference) converter_ref).get();
    if (converter == null || converter.callback == null) {
      return;
    }
    Message m = new Message();
    m.what = 0;
    Bundle bundle = new Bundle();
    bundle.putString("info", str);
    m.setData(bundle);
    converter.callback.sendMessage(m);
  }

  /**
   * 转码结束
   *
   * @param result：各种状态，只有OK表示成功
   * @param outfile:输出文件，与start传输的outfile一样
   */
  @CalledByNative
  @SuppressWarnings("unused")
  private static void onMediaConvertCompleted(Object converter_ref, int result, String outfile) {
    MediaConverter converter = (MediaConverter) ((WeakReference) converter_ref).get();
    if (converter == null || converter.callback == null) {
      return;
    }
    Message m = new Message();
    m.what = 1;
    Bundle bundle = new Bundle();
    bundle.putInt("result", result);
    bundle.putString("file", outfile);
    m.setData(bundle);
    converter.callback.sendMessage(m);
  }

  /**
   * 转码进度
   *
   * @param progress:0-100
   */
  @CalledByNative
  @SuppressWarnings("unused")
  private static void onMediaConvertProgress(Object converter_ref, int progress) {
    MediaConverter converter = (MediaConverter) ((WeakReference) converter_ref).get();
    if (converter == null || converter.callback == null) {
      return;
    }
    Message m = new Message();
    m.what = 2;
    Bundle bundle = new Bundle();
    bundle.putInt("progress", progress);
    m.setData(bundle);
    converter.callback.sendMessage(m);
  }

  /**
   * 添加水印，UI不需要响应此方法
   *
   * @param bitmap:底层生成的位图
   * @param timestamp:微秒级的时间戳
   */
  @CalledByNative
  @SuppressWarnings("unused")
  private static void onMediaConvertAddWaterMark(Object converter_ref, Bitmap bitmap, long timestamp) {
    MediaConverter converter = (MediaConverter) ((WeakReference) converter_ref).get();
    if (converter == null) {
      return;
    }
    if (bitmap == null) {
      return;
    }
    converter.addWaterMark(bitmap, timestamp);
  }

  public static class MediaInfo {
    public long duration; //媒体总时长(微秒)
    public boolean video; //是否包含视频
    public int width; //视频宽度
    public int height; //视频高度
    public int avg_fps; //平均帧率，一般室外机的帧率在25左右，我们的平板在15左右
    public boolean local_audio;//是否包含近端音频
    public boolean remote_audio; //是否包含远端音频
    public long start_time;  //媒体记录保存的起始时间

    public MediaInfo(String json) {
      try {
        JSONObject j = new JSONObject(json);
        this.duration = j.getLong("duration");
        this.video = j.getBoolean("video");
        this.width = j.getInt("width");
        this.height = j.getInt("height");
        this.avg_fps = j.getInt("avg_fps");
        this.local_audio = j.getBoolean("local_audio");
        this.remote_audio = j.getBoolean("remote_audio");
        this.start_time = j.getLong("start_time");
      } catch (JSONException e) {
        e.printStackTrace();
      }
    }
  }

  private native final boolean nativeStart(Object weak_this,
                                           String infile,
                                           String outfile,
                                           boolean watermark);

  private native final void nativeStop();

  private native final void nativeRelease();

  private native final void nativeFinalize();
}
