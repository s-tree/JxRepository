package com.intercom.util;

import android.os.Handler;
import android.os.Message;

import com.intercom.base.annotations.CalledByNative;

import java.lang.ref.WeakReference;

/**
 * 远程协助，室内机平板可以支持，配合MCU一起使用
 * 移动端不支持
 */

public class RemoteService {

    private static RemoteService remoteService;
    public static synchronized RemoteService getInstance(RemoteServiceHandler handler,RemoteSession session){
        if(remoteService == null){
            remoteService = new RemoteService(handler,session);
        }
        if(handler != null && session != null && remoteService.handler != handler){
            remoteService.handler = handler;
            remoteService.session = session;
        }
        return remoteService;
    }

    public static final int STATE_START = 0;
    public static final int STATE_CONNECTED = 1;
    public static final int STATE_DISCONNECTED = 2;
    public static final int STATE_STOP = 3;
    public static final int STATE_FAILED = 4;

    /**
     * Accessed by native methods: provides access to C++ RemoteService object
     */
    @SuppressWarnings("unused")
    private long mNativeJavaObj;

    private RemoteServiceHandler handler;
    private final CallbackHandler callback;
    private RemoteSession session;

    public interface RemoteServiceHandler {
        void onRemoteServiceStateChanged(int state);
    }

    public static abstract class RemoteSession {
        public RemoteSession() {
        }

        public abstract boolean start(String command);

        public abstract void stop();

        public abstract boolean query();
    }


    public RemoteService(RemoteServiceHandler handler, RemoteSession session) {
        this.mNativeJavaObj = 0;
        this.handler = handler;
        this.session = session;
        this.callback = new CallbackHandler(this);
    }

    public boolean start(String net_client,
                         String work_dir,
                         String conf) {
        return nativeStart(new WeakReference<RemoteService>(this), net_client, work_dir, conf);
    }

    public void stop() {
        nativeStop();
    }

    public void release() {
        nativeRelease();
    }

    @Override
    protected void finalize() {
        nativeFinalize();
    }

    public static boolean isSessionExist(String work_dir) {
        return nativeIsSessionExist(work_dir);
    }

    public static boolean isServiceAvailable(String work_dir) {
        return nativeIsServiceAvailable(work_dir);
    }

    private static class CallbackHandler extends Handler {
        private final WeakReference<RemoteService> manager;

        CallbackHandler(RemoteService manager) {
            this.manager = new WeakReference<>(manager);
        }

        @Override
        public void handleMessage(Message message) {
            RemoteService manager = this.manager.get();
            if (manager != null) {
                if (message.what == 0) {
                    manager.handler.onRemoteServiceStateChanged(message.arg1);
                }
            } else {
                super.handleMessage(message);
            }
        }
    }

    //---------------------------------------------------------
    // Java methods called from the native side
    //--------------------
    @CalledByNative
    @SuppressWarnings("unused")
    private static boolean onRemoteServiceStart(Object weak_thiz, String command) {
        RemoteService remoteService = (RemoteService) ((WeakReference) weak_thiz).get();
        if (remoteService == null) {
            return false;
        }
        return remoteService.session.start(command);
    }

    @CalledByNative
    @SuppressWarnings("unused")
    private static void onRemoteServiceStop(Object weak_thiz) {
        RemoteService remoteService = (RemoteService) ((WeakReference) weak_thiz).get();
        if (remoteService == null) {
            return;
        }
        remoteService.session.stop();
    }

    @CalledByNative
    @SuppressWarnings("unused")
    private static boolean onRemoteServiceQuery(Object weak_thiz) {
        RemoteService remoteService = (RemoteService) ((WeakReference) weak_thiz).get();
        if (remoteService == null) {
            return false;
        }
        return remoteService.session.query();
    }

    @CalledByNative
    @SuppressWarnings("unused")
    private static void OnRemoteServiceStateChanged(Object weak_thiz, int state) {
        RemoteService remoteService = (RemoteService) ((WeakReference) weak_thiz).get();
        if (remoteService == null || remoteService.callback == null) {
            return;
        }
        Message m = new Message();
        m.what = 0;
        m.arg1 = state;
        remoteService.callback.sendMessage(m);
    }


    private native final boolean nativeStart(Object weak_this,
                                             String net_client,
                                             String work_dir,
                                             String conf);

    private native final void nativeStop();

    private native final void nativeRelease();

    private native final void nativeFinalize();

    private native static final boolean nativeIsSessionExist(String work_dir);

    private native static final boolean nativeIsServiceAvailable(String work_dir);

}
