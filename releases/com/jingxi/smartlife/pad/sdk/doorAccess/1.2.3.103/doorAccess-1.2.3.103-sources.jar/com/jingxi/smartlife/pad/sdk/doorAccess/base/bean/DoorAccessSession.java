package com.jingxi.smartlife.pad.sdk.doorAccess.base.bean;

import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorSessionManager;

public class DoorAccessSession {

    public DoorAccessSession(String sessionID) {
        this.sessionID = sessionID;
    }

    /**
     * 当前状态
     */
    public @DoorSessionManager.Status int status;

    /**
     * 当前通话的类型
     */
    public @DoorEvent.DoorMessageType int callType;

    /**
     * 当前session
     */
    public String sessionID;
    /**
     * 当前门禁设备
     */
    public DoorDevice currentDevice;

    /**
     *当前室内通设备
     */
    public ExtDeviceBean currentExtDevice;

    /**
     * 当前事件
     */
    public DoorEvent doorEvent;

    /**
     * 保存的记录
     */
    public DoorRecordBean doorRecordBean;
}
