package com.intercom.sdk;

public class IntercomConstants {

  public static class LogLevel {
    public static final int Info = 0;
    public static final int Warning = 1;
    public static final int Error = 2;
    public static final int Fatal = 3;
  }

  public static class Router {
    public static final int LAN = 0;
    public static final int PROXY = 1;
  }

  public static class NetClientType {
    public static final int NetClientTypeUndefined = 0;
    public static final int NetClientTypeProxy = 1;
    public static final int NetClientTypeClient = 2;
  }

  public static class NetClientSubType {
    public static final int NetClientSubTypeUndefined = -1;
    public static final int NetClientSubTypePad = 0;
    public static final int NetClientSubTypeMobile = 1;
    public static final int NetClientSubTypeTV = 2;
    public static final int NetClientSubTypeEmbedded = 3;
  }

  public static class NetProxytSubType {
    public static final int NetProxySubTypeUndefined = -1;
    public static final int NetProxySubTypeIndoor = 0;
    public static final int NetProxySubTypeIntercom = 1;
  }

  public static class NetClientOSPlatformType {
    public static final int NetClientOSPlatformUndefined = 0;
    public static final int NetClientOSPlatformOPENWRT = 1;
    public static final int NetClientOSPlatformLINUX = 2;
    public static final int NetClientOSPlatformANDROID = 3;
    public static final int NetClientOSPlatformIOS = 4;
    public static final int NetClientOSPlatformMAC = 5;
    public static final int NetClientOSPlatformWIN = 6;
  }

  public static class IPCDeviceType {
    public static final int IPCDeviceType_RTSP = 0;
    public static final int IPCDeviceType_ONVIF = 1;
  }

  public static class IntercomProxyEvent {
    public static final int IntercomProxyEventMessage = 0;
    public static final int IntercomProxyEventSendResult = 1;
    public static final int IntercomProxyEventProxyStateChanged = 2;
    public static final int IntercomProxyEventClientStateChanged = 3;
    public static final int IntercomProxyEventInternetProxyStateChanged = 4;
    public static final int IntercomProxyEventProxyDeviceChanged = 5;
  }

  public static class IntercomEvent {
    public static final int IntercomEventMessage = 0;
    public static final int IntercomVideoReady = 1;
    public static final int IntercomSnapshotReady = 2;
    public static final int IntercomVideoDimensionChanged = 3;
    public static final int IntercomSipStateChanged = 4;

    public static final int IntercomDtmfReady = 5;
    public static final int IntercomStreamStateChanged = 6;
    public static final int IntercomStreamTransportStarted = 7;
    public static final int IntercomStreamTransportStatistics = 8;
    public static final int IntercomStreamTransportIceNegotiation = 9;
  }

  public static class AppEvent {
    public static final int Event_App_Initialized = 0;
    public static final int Event_Media_Device_State_Changed = 1;
    public static final int Event_Camera_State_Changed = 2;
    public static final int Event_Camera_Error = 3;
  }

  public static class SipRegistrationState {
    public static final int SipRegistrationNone = 0;
    public static final int SipRegistrationProgress = 1;
    public static final int SipRegistrationOk = 2;
    public static final int SipRegistrationCleared = 3;
    public static final int SipRegistrationFailed = 4;
  }

  public static class TransportMediaType {
    public static final int TransportMediaTypeNone = 0;
    public static final int TransportMediaTypeAudio = 1;
    public static final int TransportMediaTypeVideo = 2;
  }

  public static class TransportMediaDir {
    public static final int TransportMediaDirNone = 0;
    public static final int TransportMediaDirEncoding = 1;
    public static final int TransportMediaDirDecoding = 2;
    public static final int TransportMediaDirEncodingDecoding = 3;
  }

  public static class StreamState {
    public static final int StreamStateStart = 0;
    public static final int StreamStateStop = 1;
  }

  public static class IntercomMessageResult {
    public static final int IntercomMessageResultOK = 0;
    public static final int IntercomMessageResultErr = 1;
    public static final int IntercomMessageResultDeviceName = 2;
    public static final int IntercomMessageResultSessionId = 3;
    public static final int IntercomMessageResultNOAuthority = 4;
    public static final int IntercomMessageResultUnsupportCommand = 5;
    public static final int IntercomMessageResultNotConnected = 6;
    public static final int IntercomMessageResultDeviceBusy = 7;
    public static final int IntercomMessageResultUserName = 8;
    public static final int IntercomMessageResultNet = 9;
    public static final int IntercomMessageResultTransport = 10;

    public static final int IntercomMessageResultSipReasonNoResponse = 100;
    public static final int IntercomMessageResultSipReasonBadCredentials = 101;
    public static final int IntercomMessageResultSipReasonDecline = 102;
    public static final int IntercomMessageResultSipReasonNotFound = 103;
    public static final int IntercomMessageResultSipReasonNotAnswered = 104;
    public static final int IntercomMessageResultSipReasonBusy = 105;
    public static final int IntercomMessageResultSipReasonTimeout = 106;
  }

  public static class SmarthomeMessageResult {
    public static final int SmarthomeMessageResultOK = 0;
    public static final int SmarthomeMessageResultErr = 1;
    public static final int SmarthomeMessageResultDeviceOffline = 2;
    public static final int SmarthomeMessageResultDeviceName = 3;
    public static final int SmarthomeMessageResultNOAuthority = 4;
    public static final int SmarthomeMessageResultUnsupportCommand = 5;
  }

  public static class OSType {
    public static final int CLIENT_OS_UNKNOWN = 0;
    public static final int CLIENT_OS_OPENWRT = 1;
    public static final int CLIENT_OS_LINUX = 2;
    public static final int CLIENT_OS_ANDROID = 3;
    public static final int CLIENT_OS_IOS = 4;
    public static final int CLIENT_OS_WINDOWS = 5;
  }

  public static class AudioEngine {
    public static final int AudioEngine_JAVA = 0;
    public static final int AudioEngine_AAudio = 1;
    public static final int AudioEngine_OpenSLES = 2;
  }

  public static final String kAudioCodecAAC = "AAC";
  public static final String kAudioCodecPCM = "PCM";
  public static final String kAudioCodecPCM_MULAW = "ULAW";
  public static final String kAudioCodecPCM_ALAW = "ALAW";


  static public String GetMediaTypeString(int type) {
    if (type == TransportMediaType.TransportMediaTypeAudio)
      return "audio";
    if (type == TransportMediaType.TransportMediaTypeVideo)
      return "video";
    return "unknow media type";
  }

  static public String GetStreamStateString(int state) {
    if (state == StreamState.StreamStateStart)
      return "connected";
    if (state == StreamState.StreamStateStop)
      return "disconnected";
    return "";
  }

  public static final String kAppScheme = "app";
  public static final String kClientScheme = "client";

  public static final String kProxyScheme = "proxy";

  public static final String kIntercomScheme = "icom";
  public static final String kIntercomCommandInvite = "invite";
  public static final String kIntercomCommandRinging = "ringing";
  public static final String kIntercomCommandCall = "call";
  public static final String kIntercomCommandPickup = "pickup";
  public static final String kIntercomCommandHangup = "hangup";
  public static final String kIntercomCommandUnlock = "unlock";
  public static final String kIntercomCommandPickupByOther = "pickupbyother";
  public static final String kIntercomCommandBeginTalk = "begintalk";
  public static final String kIntercomCommandEndTalk = "endtalk";
  public static final String kIntercomCommandSessionTimeout = "timeout";
  public static final String kIntercomCommandLeaveSession = "leave";
  public static final String kIntercomCommandMessage = "message";
  public static final String kIntercomCommandSnapshot = "snapshot";

  /**
   * 配置或者控制代理中的门禁设备都使用这个命令
   */
  public static final String kIntercomCommandConfigure = "configure";

  /**
   * 门禁事件通知都走这个消息，这个消息只能由代理发出，比如摄像头被遮挡事件通知
   */
  public static final String kIntercomCommandNotify = "notify";

  public static final String kButtonScheme = "button";
  public static final String kButtonSOS = "sos";
  public static final String kButtonUser = "user";
  public static final String kButtonMonitor = "monitor";
  public static final String kButtonUnlock = "unlock";
  public static final String kButtonPickup = "pickup";
  public static final String kButtonPadNear = "pad_near";
  public static final String kButtonPadLeave = "pad_leave";
  public static final String kButtonHumanNear = "human_near";
  public static final String kButtonHumanLeav = "human_leave";


  public static final String kSmarthomeScheme = "gateway";
  public static final String kSmarthomeQuery = "query";
  public static final String kSmarthomeSwitch = "switch";
  public static final String kSmarthomeEvent = "event";
  public static final String kSmarthomeCancel = "cancel";
  public static final String kSmarthomeState = "state";
  public static final String kSmarthomeDevice = "device";
  public static final String kSmarthomeButton = "button";
  public static final String kSmarthomeEmbed = "embed";
  public static final String kSmarthomeMCUDevice = "mcudevice";
  public static final String kSmarthomeMCUClient = "mcuclient";

  public static final String kFrontCameraName = "front";
  public static final String kBackCameraName = "back";

  public static final String kConfigDirName = "conf";
  public static final String kLoadIniFileName = "load.ini";

  public static final String kNotifyScheme = "notify";
  public static final String kNotifyReport = "report";
}
