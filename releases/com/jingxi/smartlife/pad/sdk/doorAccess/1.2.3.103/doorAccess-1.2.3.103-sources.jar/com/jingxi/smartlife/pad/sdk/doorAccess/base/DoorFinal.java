package com.jingxi.smartlife.pad.sdk.doorAccess.base;

public class DoorFinal {

    // EXT START
    public static final String MESSAGE_KEY_CLIENTID = "client_id";
    public static final String MESSAGE_KEY_MESSAGE = "message";
    public static final String MESSAGE_KEY_ISMONITOR = "isMonitor";
    public static final String MESSAGE_KEY_ISHANDHANGUP = "isHandHangup";
    public static final String NAME_EXT = "ext";
    // EXT END

    //P2P START
    public static final String NAME_P2P = "p2p";
    //p2p end

    //Security
    public static final String NAME_SECURITY = "security";
    public static final String SECURITY_REPORT = "report";
    public static final String SECURITY_ALERT = "alert";

    //decode
    public static final String RK_DECODER = "OMX.rk.video_decoder.avc";
    public static final String RK_ENCODER = "OMX.rk.video_encoder.avc";
}
