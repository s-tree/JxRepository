package com.intercom.media;

import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.os.Build;
import android.os.Bundle;

import com.intercom.base.annotations.CalledByNative;

public class MediaCodecUtil {

  @CalledByNative
  public static Bundle getHWCodecInfo(String mime, boolean encode) {
    Bundle bundle = new Bundle();

    boolean found = false;

    int codecCount = MediaCodecList.getCodecCount();
    for (int i = 0; i < codecCount; ++i) {
      MediaCodecInfo info = MediaCodecList.getCodecInfoAt(i);
      if ((encode && !info.isEncoder()) || (!encode && info.isEncoder()))
        continue;

      if (!info.getName().startsWith("OMX.")) {
        // Unfortunately for legacy reasons, "AACEncoder", a
        // non OMX component had to be in this list for the video
        // editor code to work... but it cannot actually be instantiated
        // using MediaCodec.
        continue;
      }
      for (String mimeType : info.getSupportedTypes()) {
        if (mimeType.equalsIgnoreCase(mime)) {
          bundle.putString("name", info.getName());

          MediaCodecInfo.CodecCapabilities cap = info.getCapabilitiesForType(mimeType);
          StringBuilder builder = new StringBuilder();
          for (int fmt : cap.colorFormats) {
            builder.append(String.valueOf(fmt));
            builder.append(";");
          }
          bundle.putString("color_format", builder.toString());
          if (encode) {
            MediaCodecInfo.EncoderCapabilities ec = cap.getEncoderCapabilities();
            if (ec != null) {
              int bitrate_mode = 0;
              if (ec.isBitrateModeSupported(MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CQ)) {
                bitrate_mode |= 1;
              }
              if (ec.isBitrateModeSupported(MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)) {
                bitrate_mode |= 2;
              }
              if (ec.isBitrateModeSupported(MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR)) {
                bitrate_mode |= 4;
              }
              bundle.putInt("bitrate-mode", bitrate_mode);
            }
            for (MediaCodecInfo.CodecProfileLevel level : cap.profileLevels) {
              if (level.profile == MediaCodecInfo.CodecProfileLevel.AVCProfileBaseline) {
                bundle.putInt("profile_basic_level", level.level);
                break;
              }
            }
          } else {
            // All Huawei devices based on this processor will immediately hang during
            // MediaCodec.setOutputSurface().  http://crbug.com/683401
            // Huawei P9 lite will, eventually, get the decoder into a bad state if SetSurface is called
            // enough times (https://crbug.com/792261).

            boolean isSetOutputSurfaceSupported = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                    && !Build.HARDWARE.equalsIgnoreCase("hi6210sft")
                    && !Build.HARDWARE.equalsIgnoreCase("hi6250");
            bundle.putBoolean("setOutputSurface", isSetOutputSurfaceSupported);
          }
          found = true;
          break;
        }
      }
      if (found)
        break;
    }
    return bundle;
  }
}
