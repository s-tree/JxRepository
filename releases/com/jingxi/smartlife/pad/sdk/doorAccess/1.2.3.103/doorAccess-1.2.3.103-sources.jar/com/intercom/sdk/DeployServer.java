package com.intercom.sdk;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import com.intercom.base.annotations.CalledByNative;

import java.lang.ref.WeakReference;

/**
 * 与管理平台的通讯
 * 如果终端可以连接到云端，则可以直接连接到管理平台
 * 如果终端不能连接到云端，则这个类不起作用
 * 终端可以通过向代理发送消息，由代理转发到社区管理平台和云端平台
 */
public class DeployServer {

    /**
     * Accessed by native methods: provides access to C++ DeployServer object
     */
    @SuppressWarnings("unused")
    private long mNativeJavaObj;

    private final CallbackHandler callback;

    private DeployServerHandler handler;

    public interface DeployServerHandler {
        void onNetConnectStateChanged(String url, boolean connected);

        void onNetLoginCompleted(String url, boolean success, int code, String errmsg);

        void onNetMessageArrival(String url, String message);
    }

    public DeployServer(DeployServerHandler handler) {
        this.handler = handler;
        this.mNativeJavaObj = 0;
        this.callback = new CallbackHandler(this);
    }

    private static class CallbackHandler extends Handler {
        private final WeakReference<DeployServer> manager;

        CallbackHandler(DeployServer manager) {
            this.manager = new WeakReference<>(manager);
        }

        @Override
        public void handleMessage(Message message) {
            DeployServer manager = this.manager.get();
            if (manager != null) {
                if (message.what == 0) {
                    String url = message.getData().getString("url");
                    String msg = message.getData().getString("message");
                    manager.handler.onNetMessageArrival(url, msg);
                } else if (message.what == 1) {
                    String url = message.getData().getString("url");
                    boolean connected = message.getData().getBoolean("connected");
                    manager.handler.onNetConnectStateChanged(url, connected);
                } else if (message.what == 2) {
                    String url = message.getData().getString("url");
                    boolean success = message.getData().getBoolean("success");
                    int code = message.getData().getInt("code");
                    String errmsg = message.getData().getString("errmsg");
                    manager.handler.onNetLoginCompleted(url, success, code, errmsg);
                }
            } else {
                super.handleMessage(message);
            }
        }
    }

    /*
        server_conf: json数组，可以支持多个服务器，每个服务器描述有三项
        [{'url':'http://xxxx',
        'name':'xxx',
        'key':'121212xx'}]
     */
    public boolean start(String system_id, String server_conf) {
        return nativeStart(new WeakReference<DeployServer>(this),
                system_id, server_conf);
    }

    public void stop() {
        nativeStop();
    }

    public void release() {
        nativeRelease();
    }

    @Override
    protected void finalize() {
        nativeFinalize();
    }

    public boolean write(String url, String message) {
        return nativeWrite(url, message);
    }

    //---------------------------------------------------------
    // Java methods called from the native side
    //--------------------
    @CalledByNative
    @SuppressWarnings("unused")
    private static void onNetMessageArrival(Object converter_ref, String url, String message) {
        DeployServer server = (DeployServer) ((WeakReference) converter_ref).get();
        if (server == null || server.callback == null) {
            return;
        }
        Message m = new Message();
        m.what = 0;
        Bundle bundle = new Bundle();
        bundle.putString("url", url);
        bundle.putString("message", message);
        m.setData(bundle);
        server.callback.sendMessage(m);
    }


    @CalledByNative
    @SuppressWarnings("unused")
    private static void onNetConnectStateChanged(Object weak_thiz,
                                                 String url,
                                                 boolean connected) {
        DeployServer server = (DeployServer) ((WeakReference) weak_thiz).get();
        if (server == null || server.callback == null) {
            return;
        }
        Message m = new Message();
        m.what = 1;
        Bundle bundle = new Bundle();
        bundle.putString("url", url);
        bundle.putBoolean("connected", connected);
        m.setData(bundle);
        server.callback.sendMessage(m);
    }


    @CalledByNative
    @SuppressWarnings("unused")
    private static void onNetLoginCompleted(Object weak_thiz,
                                            String url,
                                            boolean success,
                                            int code,
                                            String errmsg) {
        DeployServer server = (DeployServer) ((WeakReference) weak_thiz).get();
        if (server == null || server.callback == null) {
            return;
        }
        Message m = new Message();
        m.what = 2;
        Bundle bundle = new Bundle();
        bundle.putString("url", url);
        bundle.putBoolean("success", success);
        bundle.putInt("code", code);
        bundle.putString("errmsg", errmsg);
        m.setData(bundle);
        server.callback.sendMessage(m);
    }

    private native final boolean nativeStart(Object weak_this,
                                             String system_id,
                                             String server_conf);

    private native final void nativeStop();

    private native final void nativeRelease();

    private native final void nativeFinalize();

    private native final boolean nativeWrite(String url, String message);
}
