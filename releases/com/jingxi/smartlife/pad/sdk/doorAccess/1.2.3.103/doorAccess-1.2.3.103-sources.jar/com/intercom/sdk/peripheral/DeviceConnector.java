package com.intercom.sdk.peripheral;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import com.intercom.base.annotations.CalledByNative;

import java.lang.ref.WeakReference;

/**
 * 分体机与底座的串口通讯，只使用与室内机平板
 * 移动端不要使用
 */

public class DeviceConnector {
    public static final int SHELL_OK = 0;
    public static final int SHELL_HASH_ERROR = 1;
    public static final int SHELL_UNSUPPORT_TYPE = 2;
    public static final int SHELL_SCRIPT_ERROR = 3;
    public static final int SHELL_WRITE_FAILED = 4;
    public static final int SHELL_READ_FAILED = 5;
    public static final int SHELL_FILE_NOT_EXIST = 6;

    private static DeviceConnector connector;
    public static DeviceConnector getInstance(DeviceConnectorHandler handler){
        if(connector == null){
            connector = new DeviceConnector(handler);
        }
        if(handler != null && connector.handler != handler){
            connector.handler = handler;
        }
        return connector;
    }
    /**
     * Accessed by native methods: provides access to C++ DeviceConnector object
     */
    @SuppressWarnings("unused")
    private long mNativeJavaObj;

    private DeviceConnectorHandler handler;

    private final CallbackHandler callback;

    public interface DeviceConnectorHandler {
        void onDeviceConnectorHardwareStateChanged(boolean online);

        void onDeviceConnectorPeerStateChanged(boolean online);

        void onDeviceConnectorMessageArrival(int type, boolean ack, int result, String message);
    }

    public DeviceConnector(DeviceConnectorHandler handler) {
        this.mNativeJavaObj = 0;
        this.handler = handler;
        this.callback = new CallbackHandler(this);
    }

    private static class CallbackHandler extends Handler {
        private final WeakReference<DeviceConnector> manager;

        CallbackHandler(DeviceConnector manager) {
            this.manager = new WeakReference<>(manager);
        }

        @Override
        public void handleMessage(Message message) {
            DeviceConnector manager = this.manager.get();
            if (manager != null) {
                if (message.what == 0) {
                    boolean online = message.getData().getBoolean("state");
                    manager.handler.onDeviceConnectorHardwareStateChanged(online);
                }
                if (message.what == 1) {
                    boolean online = message.getData().getBoolean("state");
                    manager.handler.onDeviceConnectorPeerStateChanged(online);
                } else if (message.what == 2) {
                    int type = message.getData().getInt("type");
                    boolean ack = message.getData().getBoolean("ack");
                    int result = message.getData().getInt("result");
                    String msg = message.getData().getString("message");
                    manager.handler.onDeviceConnectorMessageArrival(type, ack, result, msg);
                }
            } else {
                super.handleMessage(message);
            }
        }
    }

    public boolean start(String socket_path) {
        return nativeStart(new WeakReference<DeviceConnector>(this), socket_path);
    }

    public void stop() {
        nativeStop();
    }

    public void release() {
        nativeRelease();
    }

    @Override
    protected void finalize() {
        nativeFinalize();
    }

    public void Write(int type, boolean ack, int result, String message) {
        nativeWrite(type, ack, result, message);
    }

    //---------------------------------------------------------
    // Java methods called from the native side
    //--------------------
    @CalledByNative
    @SuppressWarnings("unused")
    private static void onDeviceConnectorHardwareStateChanged(Object object,
                                                              boolean online) {
        DeviceConnector connector = (DeviceConnector) ((WeakReference) object).get();
        if (connector == null || connector.callback == null) {
            return;
        }
        Message m = new Message();
        m.what = 0;
        Bundle bundle = new Bundle();
        bundle.putBoolean("state", online);
        m.setData(bundle);
        connector.callback.sendMessage(m);
    }

    @CalledByNative
    @SuppressWarnings("unused")
    private static void onDeviceConnectorPeerStateChanged(Object object,
                                                          boolean online) {
        DeviceConnector connector = (DeviceConnector) ((WeakReference) object).get();
        if (connector == null || connector.callback == null) {
            return;
        }
        Message m = new Message();
        m.what = 1;
        Bundle bundle = new Bundle();
        bundle.putBoolean("state", online);
        m.setData(bundle);
        connector.callback.sendMessage(m);
    }

    @CalledByNative
    @SuppressWarnings("unused")
    private static void onDeviceConnectorMessageArrival(Object object,
                                                        int type,
                                                        boolean ack,
                                                        int result,
                                                        String message) {
        DeviceConnector connector = (DeviceConnector) ((WeakReference) object).get();
        if (connector == null || connector.callback == null) {
            return;
        }
        Message m = new Message();
        m.what = 2;
        Bundle bundle = new Bundle();
        bundle.putInt("type", type);
        bundle.putBoolean("ack", ack);
        bundle.putInt("result", result);
        bundle.putString("message", message);
        m.setData(bundle);
        connector.callback.sendMessage(m);
    }

    private native final boolean nativeStart(Object weak_this, String socket_path);

    private native final void nativeStop();

    private native final void nativeRelease();

    private native final void nativeFinalize();

    private native final void nativeWrite(int type, boolean ack, int result, String message);
}
