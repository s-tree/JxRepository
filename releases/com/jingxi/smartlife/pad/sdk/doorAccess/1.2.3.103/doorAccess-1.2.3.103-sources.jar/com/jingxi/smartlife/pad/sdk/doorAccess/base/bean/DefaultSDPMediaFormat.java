package com.jingxi.smartlife.pad.sdk.doorAccess.base.bean;

import android.os.Bundle;

import com.intercom.sdk.BundleToJSON;

public class DefaultSDPMediaFormat {

    public static class SDPAudioFormat {
        public boolean rtp = true;
        public String codec;
        public String format;
        public int ts;
        public int pt;
        public boolean mark;
        public int dir;

        public SDPAudioFormat(int dir) {
            this.codec = "ULAW";
            this.format = "8000:1:16";
            this.ts = 320;
            this.pt = 0;
            this.dir = dir;
        }

        public String toJson() {
            Bundle conf = new Bundle();
            conf.putBoolean("rtp", rtp);
            conf.putString("codec", codec);
            conf.putString("format", format);
            conf.putInt("ts", ts);
            conf.putInt("dir", dir);
            conf.putInt("pt", pt);
            conf.putBoolean("mark", mark);
            return BundleToJSON.toString(conf);
        }
    }

    public static class SDPVideoFormat {
        public boolean rtp = true;
        public String codec;
        public int ts;
        public int video_width;
        public int video_height;
        public String extra_data;
        public int packetizer;
        public int dir;
        public int pt;
        public boolean early_media;

        public SDPVideoFormat(int dir, int pt, int ts, boolean early_media) {
            this.codec = "H264";
            this.ts = ts;
            this.video_width = 640;
            this.video_height = 480;
            this.packetizer = 1;
            this.dir = dir;
            this.pt = pt;
            this.early_media = early_media;
        }

        public String toJson() {
            Bundle conf = new Bundle();
            conf.putBoolean("rtp", rtp);
            conf.putString("codec", codec);
            conf.putInt("ts", ts);
            conf.putInt("dir", dir);
            conf.putInt("pt", pt);
            conf.putInt("w", video_width);
            conf.putInt("h", video_height);
            conf.putString("extra_data", extra_data);
            conf.putInt("packetizer", packetizer);
            conf.putBoolean("early_media", early_media);
            return BundleToJSON.toString(conf);
        }
    }
}
