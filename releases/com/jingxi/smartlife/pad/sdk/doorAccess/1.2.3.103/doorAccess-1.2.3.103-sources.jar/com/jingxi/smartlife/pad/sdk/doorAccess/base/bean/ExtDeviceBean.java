package com.jingxi.smartlife.pad.sdk.doorAccess.base.bean;

import android.support.annotation.IntDef;
import android.text.TextUtils;
import android.util.SparseArray;

import com.intercom.sdk.NetClient;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Created by Administrator on 2018/5/14.
 */

public class ExtDeviceBean {

    public static final int STATUS_NONE = 0;
    public static final int STATUS_CALLOUT = 1;
    public static final int STATUS_RECEIVER = 2;
    public static final int STATUS_CHATTING = 3;
    public static final int STATUS_MONITOR_OUT = 4;
    public static final int STATUS_MONITORING = 5;
    public static final int STATUS_BE_MONITORED = 6;

    @Retention(RetentionPolicy.SOURCE)
    @IntDef({STATUS_NONE,STATUS_CALLOUT,STATUS_RECEIVER,STATUS_CHATTING,STATUS_MONITOR_OUT,STATUS_MONITORING,STATUS_BE_MONITORED})
    public @interface ExtChatStatus{}

    public static final int MODEL_ACCEPT_AUTO = 0;
    public static final int MODEL_ACCEPT_HAND = 1;
    @Retention(RetentionPolicy.SOURCE)
    @IntDef({MODEL_ACCEPT_AUTO,MODEL_ACCEPT_HAND})
    public @interface AcceptModels{}

    private SparseArray<Boolean> statusMap = new SparseArray<>();

    public void setValue(int key, boolean value) {
        statusMap.put(key, value);
    }

    public boolean getValue(int key) {
        if (statusMap.indexOfKey(key) == -1) {
            return false;
        }
        try{
            return statusMap.get(key);
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }

    public void clearValues(){
        statusMap.clear();
    }

    public String getShowName(){
        return TextUtils.isEmpty(clientBean.getAlias()) ? clientBean.getButton_key() : clientBean.getAlias();
    }

    public String clientId;

    public String chatSession;

    public int status;

    public NetClient clientBean;

    public ExtDeviceBean() {
    }

    public ExtDeviceBean(String clientId) {
        this.clientId = clientId;
    }

    public ExtDeviceBean(String proxyId, String clientId) {
        this.clientId = clientId;
    }

    public static ExtDeviceBean obtain(NetClient netClient){
        ExtDeviceBean bean = new ExtDeviceBean();
        bean.clientId = netClient.getClient_id();
        bean.clientBean = netClient;
        return bean;
    }

    @Override
    public boolean equals(Object obj) {
        if(obj == null || !(obj instanceof ExtDeviceBean)){
            return false;
        }
        ExtDeviceBean theBean = (ExtDeviceBean) obj;
        return TextUtils.equals(this.clientId,theBean.clientId);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    public void setStatus(@ExtChatStatus int status){
        this.status = status;
    }

    public @ExtDeviceBean.ExtChatStatus int getStatus(){
        return status;
    }

}
