package com.jingxi.smartlife.pad.sdk.doorAccess.base.bean;

import android.support.annotation.IntDef;
import android.text.TextUtils;

import com.intercom.sdk.IntercomConstants;
import com.intercom.sdk.IntercomManager;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorConfigs;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorDeviceManager;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.orm.DoorAccessOrmUtil;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.utils.HHTAddressFormat;
import com.litesuits.orm.db.annotation.Column;
import com.litesuits.orm.db.annotation.Mapping;
import com.litesuits.orm.db.annotation.PrimaryKey;
import com.litesuits.orm.db.enums.AssignType;
import com.litesuits.orm.db.enums.Relation;

import java.io.File;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.List;

/**
 * 来访纪录
 */
public class DoorRecordBean {
    public static final int CALL_EVENT_CALLOUT = 0;     //主动外呼
    public static final int CALL_EVENT_RECEIVER = 1;    //收到通话
    public static final int CALL_EVENTCALLOUT_CHATTING = 2;    //通话成功
    public static final int CALL_EVENT_RECEIVER_CHATTING = 3;    //通话成功
    /**
     * @deprecated
     */
    public static final int CALL_EVENT_CANCEL = 4;      //发起呼叫取消
    /**
     * @deprecated
     */
    public static final int CALL_EVENT_HANGUP = 5;      //发起呼叫被拒接
    /**
     * @deprecated
     */
    public static final int CALL_EVENT_HANGUP_REMOTE = 6;      //收到呼叫拒接

    public static final int CALL_EVENT_CALLOUT_CANCEL = 7; //外呼取消
    public static final int CALL_EVENT_CALLOUT_REJECT = 8; //外呼被拒接
    public static final int CALL_EVENT_RECEIVER_CANCEL = 9; // 收到呼叫对方取消
    public static final int CALL_EVENT_RECEIVER_REJECT = 10; //收到呼叫自身拒接
    public static final int CALL_EVENT_CALLOUT_TIMEOUT = 11; //外呼未接听超时
    public static final int CALL_EVENT_RECEIVER_TIMEOUT = 12; //收到呼叫未接听超时
    public static final int CALL_EVENT_EXT_MONITOR = 13;    //室内通 发起监控
    public static final int CALL_EVENT_EXT_BE_MONITORED = 14;    //室内通 被监控

    public static final int RECORD_TYPE_DOOR = 0;      //门禁通话纪录
    public static final int RECORD_TYPE_P2P = 1;       //户户通通话纪录
    public static final int RECORD_TYPE_EXT = 2;       //室内通通话纪录


    @IntDef({RECORD_TYPE_DOOR,RECORD_TYPE_P2P,RECORD_TYPE_EXT})
    @Retention(RetentionPolicy.SOURCE)
    public @interface RECORD_TYPE{}

    @IntDef({
            CALL_EVENT_CALLOUT,
            CALL_EVENT_RECEIVER,
            CALL_EVENTCALLOUT_CHATTING,
            CALL_EVENT_RECEIVER_CHATTING,
            CALL_EVENT_CANCEL,
            CALL_EVENT_HANGUP,
            CALL_EVENT_HANGUP_REMOTE,
            CALL_EVENT_CALLOUT_CANCEL,
            CALL_EVENT_CALLOUT_REJECT,
            CALL_EVENT_RECEIVER_CANCEL,
            CALL_EVENT_RECEIVER_REJECT,
            CALL_EVENT_CALLOUT_TIMEOUT,
            CALL_EVENT_RECEIVER_TIMEOUT,
            CALL_EVENT_EXT_MONITOR,
            CALL_EVENT_EXT_BE_MONITORED
    })
    @Retention(RetentionPolicy.SOURCE)
    public @interface ChatEvent{}

    @PrimaryKey(AssignType.AUTO_INCREMENT)
    @Column("_id")
    public int id;

    /**
     * 不同家庭id不同
     */
    @Column("familyID")
    public String familyID;

    /**
     * 暂时无用
     */
    @Column("scheme")
    public String scheme;

    /**
     * 发送过来的username (房号形式)
     */
    @Column("name")
    public String name;

    /**
     * 用于展示的name
     */
    @Column("show_name")
    public String show_name;

    /**
     * 来源
     */
    @Column("from_name")
    public String from_name;

    /**
     * 呼叫过来的userType
     */
    @Column("userType")
    public String userType;

    /**
     * 通话记录的发生时间
     */
    @Column("startTime")
    public long startTime;

    /**
     * 通话时长(单位 秒)
     */
    @Column("chat_time")
    public int chat_time;

    /**
     * 单双工，现在都是 "1"
     * "1"   双工
     * "0"   单工
     */
    @Column("duplex")
    public String duplex;

    /**
     * 通话状态
     */
    @Column("chatEvent")
    public int chatEvent;

    /**
     * 记录的通话类型 （门禁，户户通，室内通）
     */
    @Column("record_type")
    public int record_type;

    /**
     * 通话id
     */
    @Column("session_id")
    public String session_id;

    /**
     * 快照路径
     */
    @Column("thumbPath")
    public String thumbPath;

    /**
     * 来访纪录视频路径
     */
    @Column("videoPath")
    public String videoPath;

    /**
     *
     * 设备类型
     * 1 : 户户通
     * 2 : 梯口
     * 3 : 物业
     * 4 : 户户通
     * 5 : 室外监控器
     * 6 : 监控摄像机
     * 7 : 智能摄像机
     *
     */
    public int deviceType;

    private DoorRecordBean(){

    }

    @Mapping(Relation.OneToMany)
    public ArrayList<RecordVideoBean> recordList = new ArrayList<>();

    /**
     * 新版本记录在recordList中，旧版直接在bean中，需要做兼容
     * @return
     */
    public List<RecordVideoBean> getRecordList() {
        if(recordList == null){
            recordList = new ArrayList<>();
        }
        for(RecordVideoBean videoBean : recordList){
            if(TextUtils.isEmpty(videoBean.chatSession)){
                videoBean.chatSession = session_id;
                DoorAccessOrmUtil.update(videoBean);
            }
        }
        if(!TextUtils.isEmpty(videoPath) && new File(videoPath).exists()){
            RecordVideoBean videoBean = new RecordVideoBean();
            videoBean.startTime = startTime;
            videoBean.videoSession = session_id;
            videoBean.picPath = thumbPath;
            videoBean.videoPath = videoPath;
            videoBean.chatSession = session_id;
            videoBean.showName = show_name;
            videoBean.name = name;
            recordList.add(0,videoBean);
        }
        return recordList;
    }

    /**
     * @return
     */
    public List<RecordVideoBean> getJustRecords() {
        if(recordList == null){
            recordList = new ArrayList<>();
        }
        return recordList;
    }

    public String addNewVideoRecord(String sessionId,long startTime,String showName,String name){
        RecordVideoBean videoBean = new RecordVideoBean();
        videoBean.startTime = startTime;
        videoBean.videoSession = IntercomManager.createSessionId();
        videoBean.picPath = thumbPath;
        videoBean.videoPath = contactVideoPath(sessionId,videoBean.videoSession);
        videoBean.chatSession = sessionId;
        videoBean.showName = showName;
        videoBean.name = name;
        recordList.add(videoBean);
        DoorAccessOrmUtil.saveRecord(this);
        return videoBean.videoSession;
    }

    private void createPicPath(){

    }

    public void setRecordList(ArrayList<RecordVideoBean> recordList) {
        if(recordList == null){
            this.recordList = new ArrayList<>();
        }else{
            this.recordList = recordList;
        }
    }

    private static String contactVideoPath(String session,String fileSession){
        return TextUtils.concat(DoorConfigs.getMediaDir(),"/", session,"/",fileSession,".rec").toString();
    }

    /**
     * 格式化门禁记录
     * @param scheme
     * @param fromName      会话来源
     * @param username      会话的房号表名称
     * @return
     */
    public static DoorRecordBean parseDoorRecord(String familyID,String scheme,String fromName,String username,String sessionID,@ChatEvent int event){
        //[request]\r\nusername=0100101\r\nusertype=0
        DoorRecordBean chatRecordBean = new DoorRecordBean();
        chatRecordBean.familyID = familyID;
        chatRecordBean.name = username;
        chatRecordBean.scheme = scheme;
        chatRecordBean.session_id = sessionID;
        chatRecordBean.from_name = fromName;
        DoorDevice deviceModen = DoorDeviceManager.getDeviceByName(familyID,username);
        if(deviceModen == null){
            deviceModen = new DoorDevice();
        }
        chatRecordBean.userType = "2";
        chatRecordBean.show_name = deviceModen.alias;
        chatRecordBean.duplex = deviceModen.duplex?"0":"1";
        chatRecordBean.deviceType = deviceModen.getMyDeviceType();
        chatRecordBean.record_type = RECORD_TYPE_DOOR;
        chatRecordBean.chatEvent = event;
        chatRecordBean.startTime = System.currentTimeMillis();
        chatRecordBean.videoPath = contactVideoPath(sessionID,sessionID);
        return chatRecordBean;
    }


    public static DoorRecordBean parseP2PRecord(String familyID,String scheme,String fromName,String username,String sessionID,@ChatEvent int event){
        //[request]\r\nusername=0100101\r\nusertype=0
        DoorRecordBean chatRecordBean = new DoorRecordBean();
        chatRecordBean.familyID = familyID;
        chatRecordBean.name = username;
        chatRecordBean.scheme = scheme;
        chatRecordBean.session_id = sessionID;
        chatRecordBean.from_name = fromName;
        chatRecordBean.userType = "1";
        chatRecordBean.duplex = "1";
        chatRecordBean.deviceType = 1;
        chatRecordBean.record_type = RECORD_TYPE_P2P;
        chatRecordBean.chatEvent = event;
        chatRecordBean.show_name = HHTAddressFormat.formatAddress(username,DoorDeviceManager.getHHTAddressFormat(familyID));
        chatRecordBean.startTime = System.currentTimeMillis();
        chatRecordBean.videoPath = contactVideoPath(sessionID,sessionID);
        return chatRecordBean;
    }

    /**
     * 室内通时 deviceType 就是 {@link com.intercom.sdk.IntercomConstants.NetClientSubType}
     * @param familyID
     * @param buttonKey
     * @param sessionID
     * @param event
     * @return
     */
    public static DoorRecordBean parseExtRecord(String familyID,String sessionID,String buttonKey,int subType,@ChatEvent int event){
        //[request]\r\nusername=0100101\r\nusertype=0
        DoorRecordBean chatRecordBean = new DoorRecordBean();
        chatRecordBean.familyID = familyID;
        chatRecordBean.name = buttonKey;
        chatRecordBean.from_name = buttonKey;
        chatRecordBean.session_id = sessionID;
        chatRecordBean.userType = "1";
        chatRecordBean.duplex = "1";
        chatRecordBean.deviceType = subType;
        chatRecordBean.record_type = RECORD_TYPE_EXT;
        chatRecordBean.chatEvent = event;
        String platform = subType == IntercomConstants.NetClientSubType.NetClientSubTypePad ? "平板" :
                subType == IntercomConstants.NetClientSubType.NetClientSubTypeEmbedded ? "底座" :
                        subType == IntercomConstants.NetClientSubType.NetClientSubTypeMobile ? "移动端" : "未知";
        chatRecordBean.show_name = platform + "\t" + buttonKey;
        chatRecordBean.startTime = System.currentTimeMillis();
        chatRecordBean.videoPath = contactVideoPath(sessionID,sessionID);
        return chatRecordBean;
    }

    /**
     * 根据呼叫状态返回字段
     * @return
     */
    public String getStatusByEvent(){
        switch (chatEvent){
            case CALL_EVENT_CALLOUT:{
                return "外呼";
            }
            case CALL_EVENT_RECEIVER:{
                return "收到呼叫";
            }
            case CALL_EVENTCALLOUT_CHATTING:{
                return "外呼 已接听";
            }
            case CALL_EVENT_RECEIVER_CHATTING:{
                return "收到呼叫 已接听";
            }
            case CALL_EVENT_CALLOUT_CANCEL:{
                return "外呼 取消";
            }
            case CALL_EVENT_CALLOUT_REJECT:{
                return "外呼 被拒接";
            }
            case CALL_EVENT_RECEIVER_CANCEL:{
                return "对方取消了呼叫";
            }
            case CALL_EVENT_RECEIVER_REJECT:{
                return "拒接了对方的呼叫";
            }
            case CALL_EVENT_CALLOUT_TIMEOUT:{
                return "外呼 未接听 超时";
            }
            case CALL_EVENT_RECEIVER_TIMEOUT:{
                return "收到呼叫 未接听 超时";
            }
            case CALL_EVENT_EXT_MONITOR:{
                return "发起室内通监控";
            }
            case CALL_EVENT_EXT_BE_MONITORED:{
                return "收到室内通监控";
            }
            default:

        }
        return "";
    }
}
