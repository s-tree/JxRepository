package com.jingxi.smartlife.pad.sdk.doorAccess.base;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.IntDef;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.intercom.sdk.BundleToJSON;
import com.intercom.sdk.IntercomConfigure;
import com.intercom.sdk.IntercomConstants;
import com.intercom.sdk.utils;
import com.jingxi.smartlife.pad.sdk.utils.JXContextWrapper;

import java.io.File;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.HashMap;
import java.util.Map;

public class DoorConfigs {
    public static final  String DOOR_LOG_TAG            = "door";
    private static final String NO_VIDEO_JPG            = "novideo.jpg";
    private static final String PROXY_MULTICAST_ADDRESS = "238.18.18.1";

    protected static final String          APP_CHANNEL         = "jx_dr";
    protected static final String          PATH                = "sdcard/data/doorkeeper/access/";//文件保存路径
    protected static final String          SERVER_PATH         = "sdcard/data/doorkeeper/server/";//文件保存路径
    protected static final String          INTERCOM_SERVER_URL = "http://sip.house-keeper.cn/opensip/v2/register";
    protected static final String          PROXY_SERVER_URL    = "http://transit.house-keeper.cn/keepalive";
    protected static final String          sslCertPath         = "/sdcard/tls";
    protected static final String          PORT_CONF = "30000,35000,40000";
    public static final    String          TLS_DIR_NAME        = "tls";
    public static final    String          DEVICE_MONITOR_URL  = "";
    protected static final int             max_session_wait_time = 60;
    protected static final int             intercom_max_session_connect_time = 200;
    protected static final String          special_p2p_device = "p2p,300,300";
    protected static final String          speical_ext_device = "ext,2592000,86400";
    public static int getMaxRecordCount() {
        return options.maxRecordCount;
    }
    protected static       DoorKit.Options options             = DoorKit.Options.getDefault();

    public static String getMediaDir() {
        return new File(options.doorAccessWorkDir, "record").getAbsolutePath();
    }

    public static int getClientType() {
        return options.platform;
    }

    /**
     * 初始化完成后保存的 familyID - clientID 对应表
     */
    protected static Map<String, String> clientIds = new HashMap<>();

    protected static String getAppConf() {
        PackageManager packageManager = JXContextWrapper.context.getPackageManager();
        String version = "";
        try {
            PackageInfo info = packageManager.getPackageInfo(JXContextWrapper.context.getPackageName(),0);
            version = TextUtils.concat(info.versionName,".",String.valueOf(info.versionCode)).toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        int logLevel = options.logDebug ? IntercomConstants.LogLevel.Info : IntercomConstants.LogLevel.Fatal;
        IntercomConfigure.AppConf appConf = new IntercomConfigure.AppConf(version,options.channel,options.clientConf,
                getMediaDir(), false, logLevel);
        return appConf.toJson();
    }

    protected static String getPortConf(){
        IntercomConfigure.PortConf portConf = new IntercomConfigure.PortConf(options.portConf, null, null);
        return portConf.toJson();
    }

    protected static String getIntercomConfig() {
        IntercomConfigure.VideoCodecConfig videoCodecConfig = new IntercomConfigure.VideoCodecConfig();
        videoCodecConfig.video_encode_engine = options.video_encode_engine;
        videoCodecConfig.video_decode_engine = options.video_decode_engine;

        IntercomConfigure.CaptureConfig captureConfig = new IntercomConfigure.CaptureConfig();
        captureConfig.capture_video_height = options.capture_video_height;
        captureConfig.capture_video_width = options.capture_video_width;

        IntercomConfigure.IntercomConfig configure = new IntercomConfigure.IntercomConfig(captureConfig,
                videoCodecConfig);

        configure.audio_play_agc_level = options.audio_play_agc_level;
        configure.audio_send_agc_level = options.audio_send_agc_level;
        configure.max_session_wait_time = options.max_session_wait_time;
        configure.intercom_max_session_connect_time = options.intercom_max_session_connect_time;
        configure.special_p2p_device = options.special_p2p_device;
        configure.speical_ext_device = options.speical_ext_device;
        configure.disable_aec = options.disable_aec;
        configure.aec_latency = options.aec_latency;
//        configure.denoise = options.denoise;
        configure.max_audio_delay_us = options.max_audio_delay_us;
        configure.audio_low_latency = options.audio_low_latency;
        configure.audio_engine = options.audio_engine;
        configure.audio_samplerate = options.audio_samplerate;
        configure.video_codec_conf.video_decode_engine = options.video_decode_engine;
        configure.video_codec_conf.video_encode_engine = options.video_encode_engine;
//        configure.audio_ptime = 20;
        configure.audio_send_denoise = options.audio_send_denoise;
        configure.audio_play_denoise = options.audio_play_denoise;
        return configure.toJson();
    }

    protected static byte[][] getNoVideoImage() {
        /**
         * 图片要在10KB以内
         */
        byte[][] arr = new byte[1][];
        arr[0] = utils.readResourceFromFile(JXContextWrapper.context.getAssets(), NO_VIDEO_JPG);
        return arr;
    }

    protected static String getClientConf(String familyDockSN, String buttonKey) {
        IntercomConfigure.ClientConf clientConf = new IntercomConfigure.ClientConf(
                IntercomConstants.NetClientType.NetClientTypeClient,
                options.platform,
                familyDockSN,
                buttonKey,
                options.alias,
                options.publishID,
                options.sn);
        return clientConf.toJson();
    }

    protected static String getProxyConfig() {
        IntercomConfigure.ProxyConf proxy = new IntercomConfigure.ProxyConf(10000,
                PROXY_MULTICAST_ADDRESS,
                60,
                true,
                true,
                options.proxyServerUrl,
                options.sslCertPath,
                "");
        proxy.lan_broadcast_exclude_interface = options.lan_broadcast_exclude_interface;
        proxy.master_device = options.master_device;
        return proxy.toJson();
    }

    /**
     * 获取纯云端代理配置
     * @param sipConfig
     * @return
     */
    protected static String getCloudProxyConfig(String sipConfig){
        JSONObject jsonObject = null;
        try {
            jsonObject = JSON.parseObject(sipConfig);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

        Bundle conf = new Bundle();
        conf.putString("number_mask", jsonObject.getString("number_mask"));
        conf.putString("name", jsonObject.getString("name"));
        conf.putString("p2p_number_mask",jsonObject.getString("p2p_number_mask"));
        JSONArray array = jsonObject.getJSONArray("device");
        if(array != null && array.size() > 0){
            conf.putStringArray("device", (String[]) array.toArray());
        }
        return BundleToJSON.toString(conf);
    }

    protected static String getServerConfig() {
        return new IntercomConfigure.ServerConfig(
                options.intercomServerUrl,
                "",
                "",
                "",
                60).toJson();
    }

    protected static String getCloudSipConfig(String sipConfig){
        JSONObject jsonObject = null;
        try {
            jsonObject = JSON.parseObject(sipConfig);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        IntercomConfigure.SipConfig config = new IntercomConfigure.SipConfig();
        config.transport = "tcp";
        IntercomConfigure.SipAuth sipAuth = new IntercomConfigure.SipAuth();
        sipAuth.userid = jsonObject.getString("userid");
        sipAuth.passwd = jsonObject.getString("passwd");
        sipAuth.username = jsonObject.getString("username");
        config.auths.add(sipAuth);
        IntercomConfigure.SipProxy proxy = new IntercomConfigure.SipProxy();
        proxy.proxy = jsonObject.getString("proxy");
        proxy.identity = jsonObject.getString("identity");
        //一般而言，全时通不支持ICE协议，所以，config.stun_server不能设置，保持为空即可
        //除非有特别说明可以支持
        config.stun_server = jsonObject.getString("stun_server");
        config.proxies.add(proxy);
        return config.toJson();
    }

    /**
     * 可视对讲类型
     */
    @Retention(RetentionPolicy.RUNTIME)
    @IntDef({IntercomType.TYPE_LOCAL,IntercomType.TYPE_CLOUD})
    protected @interface IntercomType{
        /**
         * 本地有代理，有室内机
         */
        int TYPE_LOCAL = 0;
        /**
         * 纯全视通云端，无代理
         */
        int TYPE_CLOUD = 1;
    }
}
