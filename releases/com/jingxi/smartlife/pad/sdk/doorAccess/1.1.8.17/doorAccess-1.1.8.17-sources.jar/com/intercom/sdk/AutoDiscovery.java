package com.intercom.sdk;

import android.os.Bundle;

import java.lang.ref.WeakReference;

public class AutoDiscovery {
    //不要操作它，native层使用
    private long mNativeAutoDiscoveryJavaObj;
    private final OnAutoDiscoveryEventListener listener;

    //当前网络发现其他主机存在
    public static final int AUTO_DETECT_SUCCESS = 0;
    //socket 创建失败？没有网络权限？
    public static final int AUTO_DETECT_SOCK_ERR = -1;
    //当前网络内没有发现其他主机存在
    public static final int AUTO_DETECT_TIMEOUT = -2;

    public AutoDiscovery(OnAutoDiscoveryEventListener listener) {
        this.mNativeAutoDiscoveryJavaObj = 0;
        this.listener = listener;
    }

    public boolean start(String conf, String net_client) {
        return nativeStart(new WeakReference<AutoDiscovery>(this), conf, net_client);
    }

    public void stop() {
        nativeStop();
    }

    public void Release() {
        nativeRelease();
    }

    public boolean accept(String net_client) {
        return nativeAccept(net_client);
    }

    public boolean decline(String client_id) {
        return nativeDecline(client_id);
    }

    /**
     * 探测网络内有没有其他主机存在，放在子线程执行
     *
     * @param multicast_address:组播地址
     * @param ms:超时时间，比如2000毫秒
     * @return : result and address and system_id
     */
    static public Bundle detectHost(String multicast_address, int ms) {
        return nativeDetectHost(multicast_address, ms);
    }

    @SuppressWarnings("unused")
    private static void postEventFromNative(Object thiz, String system_id, String net_client) {
        AutoDiscovery discovery = (AutoDiscovery) ((WeakReference) thiz).get();
        if (discovery != null) {
            discovery.listener.OnAutoDiscoveryClient(system_id, net_client);
        }
    }

    public interface OnAutoDiscoveryEventListener {
        void OnAutoDiscoveryClient(String system_id, String net_client);
    }

    private native boolean nativeStart(Object weak_this, String conf, String net_client);

    private native void nativeStop();

    private native void nativeRelease();

    private native boolean nativeAccept(String net_client);

    private native boolean nativeDecline(String client_id);

    private static native Bundle nativeDetectHost(String multicast_address, int ms);
}
