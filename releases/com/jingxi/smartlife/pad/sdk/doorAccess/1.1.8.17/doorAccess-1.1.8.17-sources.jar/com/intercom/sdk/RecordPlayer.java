package com.intercom.sdk;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Surface;

import java.lang.ref.WeakReference;

public class RecordPlayer {

    private static RecordPlayer player;
    public static synchronized RecordPlayer getInstance(RecordPlayerHandler handler){
        if(player == null){
            player = new RecordPlayer(handler);
        }
        if(handler != null && player.handler != handler){
            player.handler = handler;
        }
        return player;
    }

    private long mNativeJavaObj;
    private RecordPlayerHandler handler;
    private final CallbackHandler callback;

    private boolean local_audio_enable;

    private boolean remote_audio_enable;

    public interface RecordPlayerHandler {
        void onMediaDuration(String session_id, long duration);

        void onMediaProgress(String session_id, long progress);

        void onMediaCompleted(String session_id, int reason);

        void onMediaVideoDimensionChanged(String session_id, int width, int height);
    }

    public RecordPlayer(RecordPlayerHandler handler) {
        this.mNativeJavaObj = 0;
        this.handler = handler;
        this.local_audio_enable = true;
        this.remote_audio_enable = true;
        this.callback = new CallbackHandler(this);
    }

    public boolean start(String media_dir, String session_id, String filename) {
        return nativeStart(new WeakReference<RecordPlayer>(this), media_dir, session_id, filename);
    }

    public void removeHandler(RecordPlayerHandler handler){
        if(this.handler == handler){
            handler = null;
        }
    }

    public void stop() {
        nativeStop();
    }

    public void Release() {
        nativeRelease();
    }

    public void seek(int progress) {
        nativeSeek(progress);
    }

    public void switchAudio(boolean local) {
        if (local) {
            this.local_audio_enable = !this.local_audio_enable;
            nativeEnableAudioTracker(true, this.local_audio_enable);

        } else {
            this.remote_audio_enable = !this.remote_audio_enable;
            nativeEnableAudioTracker(false, this.remote_audio_enable);
        }
    }

    public void enableAudioTracker(boolean local, boolean enable) {
        nativeEnableAudioTracker(local, enable);
    }

    public void updateSurface(Surface surface) {
        nativeUpdateSurface(surface);
    }

    private static class CallbackHandler extends Handler {
        private final WeakReference<RecordPlayer> manager;

        CallbackHandler(RecordPlayer manager) {
            this.manager = new WeakReference<>(manager);
        }

        @Override
        public void handleMessage(Message message) {
            RecordPlayer manager = this.manager.get();
            if (manager != null) {
                if (message.what == 0) {
                    String session_id = message.getData().getString("session_id");
                    long duration = message.getData().getLong("duration");
                    manager.handler.onMediaDuration(session_id, duration);
                } else if (message.what == 1) {
                    String session_id = message.getData().getString("session_id");
                    long progress = message.getData().getLong("progress");
                    manager.handler.onMediaProgress(session_id, progress);
                } else if (message.what == 2) {
                    String session_id = message.getData().getString("session_id");
                    int reason = message.getData().getInt("reason");
                    manager.handler.onMediaCompleted(session_id, reason);
                } else if (message.what == 3) {
                    String session_id = message.getData().getString("session_id");
                    int width = message.getData().getInt("width");
                    int height = message.getData().getInt("height");
                    manager.handler.onMediaVideoDimensionChanged(session_id, width, height);
                }
            } else {
                super.handleMessage(message);
            }
        }
    }

    static void onRecordPlayerDuration(Object object, String session_id, long duration) {
        RecordPlayer player = (RecordPlayer) ((WeakReference) object).get();
        if (player == null) {
            return;
        }
        Message m = new Message();
        m.what = 0;
        Bundle bundle = new Bundle();
        bundle.putString("session_id", session_id);
        bundle.putLong("duration", duration);
        m.setData(bundle);
        player.callback.sendMessage(m);
    }

    static void onRecordPlayerProgress(Object object, String session_id, long progress) {
        RecordPlayer player = (RecordPlayer) ((WeakReference) object).get();
        if (player == null) {
            return;
        }
        Message m = new Message();
        m.what = 1;
        Bundle bundle = new Bundle();
        bundle.putString("session_id", session_id);
        bundle.putLong("progress", progress);
        m.setData(bundle);
        player.callback.sendMessage(m);
    }

    static void onRecordPlayerCompleted(Object object, String session_id, int reason) {
        RecordPlayer player = (RecordPlayer) ((WeakReference) object).get();
        if (player == null) {
            return;
        }
        Message m = new Message();
        m.what = 2;
        Bundle bundle = new Bundle();
        bundle.putString("session_id", session_id);
        bundle.putInt("reason", reason);
        m.setData(bundle);
        player.callback.sendMessage(m);
    }

    static void onRecordPlayerVideoDimensionChanged(Object object, String session_id, int width, int height) {
        RecordPlayer player = (RecordPlayer) ((WeakReference) object).get();
        if (player == null) {
            return;
        }
        Message m = new Message();
        m.what = 3;
        Bundle bundle = new Bundle();
        bundle.putString("session_id", session_id);
        bundle.putInt("width", width);
        bundle.putInt("height", height);
        m.setData(bundle);
        player.callback.sendMessage(m);
    }

    private native boolean nativeStart(Object weak_this, String media_dir, String session_id, String filename);

    private native void nativeStop();

    private native void nativeRelease();

    private native void nativeEnableAudioTracker(boolean local, boolean enable);

    private native void nativeSeek(int progress);

    private native void nativeUpdateSurface(Surface surface);
}
