package com.intercom.sdk;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import com.intercom.base.annotations.CalledByNative;

import java.lang.ref.WeakReference;

public class DeployManager {

    //do not modify this parameters
    private long mNativeJavaObj;

    private final CallbackHandler callback;

    private DeployManagerHandler handler;

    public interface DeployManagerHandler {
        void onDeployManagerStateChanged(String url, boolean online);

        void onDeployManagerMessageArrival(String url, String message);
    }


    public DeployManager(DeployManagerHandler handler) {
        this.handler = handler;
        this.mNativeJavaObj = 0;
        this.callback = new CallbackHandler(this);
    }

    private static class CallbackHandler extends Handler {
        private final WeakReference<DeployManager> manager;

        CallbackHandler(DeployManager manager) {
            this.manager = new WeakReference<>(manager);
        }

        @Override
        public void handleMessage(Message message) {
            DeployManager manager = this.manager.get();
            if (manager != null) {
                if (message.what == 0) {
                    String url = message.getData().getString("url");
                    boolean online = message.getData().getBoolean("online");
                    manager.handler.onDeployManagerStateChanged(url, online);
                } else if (message.what == 1) {
                    String url = message.getData().getString("url");
                    String msg = message.getData().getString("message");
                    manager.handler.onDeployManagerMessageArrival(url, msg);
                }
            } else {
                super.handleMessage(message);
            }
        }
    }


    /*
        server_conf: json数组，可以支持多个服务器，每个服务器描述有三项
        [{'url':'http://xxxx',
        'name':'xxx',
        'key':'121212xx'}]
     */
    public boolean start(String system_id, String server_conf) {
        return nativeStart(new WeakReference<DeployManager>(this),
                system_id, server_conf);
    }

    /**
     * 停止转码，释放资源，没有完成的情况下，会取消转码
     */
    public void stop() {
        nativeStop();
    }

    public void Release() {
        nativeRelease();
    }

    public boolean write(String url, String message) {
        return nativeWrite(url, message);
    }


    @CalledByNative
    @SuppressWarnings("unused")
    private static void onDeployManagerStateChanged(Object converter_ref, String url, boolean online) {
        DeployManager manager = (DeployManager) ((WeakReference) converter_ref).get();
        if (manager == null) {
            return;
        }
        Message m = new Message();
        m.what = 0;
        Bundle bundle = new Bundle();
        bundle.putString("url", url);
        bundle.putBoolean("online", online);
        m.setData(bundle);
        manager.callback.sendMessage(m);
    }


    @CalledByNative
    @SuppressWarnings("unused")
    private static void onDeployManagerMessageArrival(Object converter_ref, String url, String message) {
        DeployManager manager = (DeployManager) ((WeakReference) converter_ref).get();
        if (manager == null) {
            return;
        }
        Message m = new Message();
        m.what = 1;
        Bundle bundle = new Bundle();
        bundle.putString("url", url);
        bundle.putString("message", message);
        m.setData(bundle);
        manager.callback.sendMessage(m);
    }

    private native boolean nativeStart(Object weak_this,
                                       String url,
                                       String server_conf);

    private native void nativeStop();

    private native void nativeRelease();

    private native boolean nativeWrite(String url, String message);
}
