package com.intercom.sdk.peripheral;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import java.lang.ref.WeakReference;

public class MCUController {
    private static MCUController controller = null;
    public static synchronized MCUController getInstance(MCUControllerHandler handler){
        if(controller == null){
            controller = new MCUController(handler);
        }
        if(handler != null && controller.handler != handler){
            controller.handler = handler;
        }
        return controller;
    }

    public static class MCUMessageType {
        public static final int MessageTypeUnknown = 0;
        public static final int MessageTypeWatchdog = 1;
        public static final int MessageTypeButton = 2;
        public static final int MessageTypeLight = 3;
        public static final int MessageTypeSoundSwitch = 4;
        public static final int MessageTypeSecurity = 5;
        public static final int MessageTypeStartupNum = 6;
        public static final int MessageTypeMCU = 7;
    }

    public static class ButtonAction {
        public static final int Type_Unknow = 0;
        public static final int Type_Pressed = 1;
        public static final int Type_Released = 2;
        public static final int Type_Long_Pressed = 3;
    }

    private long mNativeJavaObj;

    private final CallbackHandler callback;

    private MCUControllerHandler handler;

    public interface MCUControllerHandler {
        void onMCUStateChanged(boolean online);

        void onMCUButtonEvent(int event, String id, String sound);

        void onMCUButtonClick(String id);

        void onMCUMessageArrival(int type, boolean ack, int result, String message);
    }

    public MCUController(MCUControllerHandler handler) {
        this.mNativeJavaObj = 0;
        this.callback = new CallbackHandler(this);
        this.handler = handler;
    }

    public boolean start(String mcu_conf, String button_conf) {
        return nativeStart(new WeakReference<MCUController>(this), mcu_conf, button_conf);
    }

    public void stop() {
        nativeStop();
    }

    public void Release() {
        nativeRelease();
    }

    public void LightOn(int msec, int freq, boolean force) {
        nativeLightOn(msec, freq, force);
    }

    public void LightOff(boolean force) {
        nativeLightOff(force);
    }

    public void LightLock(boolean enable) {
        nativeLightLock(enable);
    }

    public void WriteMCU(int type, boolean ack, int result, String message) {
        nativeWriteMCU(type, ack, result, message);
    }

    private static class CallbackHandler extends Handler {
        private final WeakReference<MCUController> manager;

        CallbackHandler(MCUController manager) {
            this.manager = new WeakReference<>(manager);
        }

        @Override
        public void handleMessage(Message message) {
            MCUController manager = this.manager.get();
            if (manager != null) {
                if (message.what == 0) {
                    boolean online = message.getData().getBoolean("state");
                    manager.handler.onMCUStateChanged(online);
                } else if (message.what == 1) {
                    int event = message.getData().getInt("event");
                    String id = message.getData().getString("id");
                    String sound = message.getData().getString("sound");
                    manager.handler.onMCUButtonEvent(event, id, sound);
                } else if (message.what == 2) {
                    String id = message.getData().getString("id");
                    manager.handler.onMCUButtonClick(id);
                } else if (message.what == 3) {
                    int type = message.getData().getInt("type");
                    boolean ack = message.getData().getBoolean("ack");
                    int result = message.getData().getInt("result");
                    String msg = message.getData().getString("message");
                    manager.handler.onMCUMessageArrival(type, ack, result, msg);
                }
            } else {
                super.handleMessage(message);
            }
        }
    }

    private static void onMCUStateChanged(Object object, boolean online) {
        MCUController controller = (MCUController) ((WeakReference) object).get();
        if (controller == null) {
            return;
        }
        Message m = new Message();
        m.what = 0;
        Bundle bundle = new Bundle();
        bundle.putBoolean("state", online);
        m.setData(bundle);
        controller.callback.sendMessage(m);
    }

    private static void onMCUButtonEvent(Object object, int event, String id, String sound) {
        MCUController controller = (MCUController) ((WeakReference) object).get();
        if (controller == null) {
            return;
        }
        Message m = new Message();
        m.what = 1;
        Bundle bundle = new Bundle();
        bundle.putInt("event", event);
        bundle.putString("id", id);
        bundle.putString("sound", sound);
        m.setData(bundle);
        controller.callback.sendMessage(m);
    }

    private static void onMCUButtonClick(Object object, String id) {
        MCUController controller = (MCUController) ((WeakReference) object).get();
        if (controller == null) {
            return;
        }
        Message m = new Message();
        m.what = 2;
        Bundle bundle = new Bundle();
        bundle.putString("id", id);
        m.setData(bundle);
        controller.callback.sendMessage(m);
    }

    private static void onMCUMessageArrival(Object object, int type, boolean ack, int result, String message) {
        MCUController controller = (MCUController) ((WeakReference) object).get();
        if (controller == null) {
            return;
        }
        Message m = new Message();
        m.what = 3;
        Bundle bundle = new Bundle();
        bundle.putInt("type", type);
        bundle.putBoolean("ack", ack);
        bundle.putInt("result", result);
        bundle.putString("message", message);
        m.setData(bundle);
        controller.callback.sendMessage(m);
    }

    private native boolean nativeStart(Object weak_this, String mcu_conf, String button_conf);

    private native void nativeStop();

    private native void nativeRelease();

    private native void nativeLightOn(int msec, int freq, boolean force);

    private native void nativeLightOff(boolean force);

    private native void nativeLightLock(boolean enable);

    private native void nativeWriteMCU(int type, boolean ack, int result, String message);
}
