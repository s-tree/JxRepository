package com.intercom.sdk.peripheral;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import java.lang.ref.WeakReference;

public class DeviceConnector {

    private static DeviceConnector connector;
    public static DeviceConnector getInstance(DeviceConnectorHandler handler){
        if(connector == null){
            connector = new DeviceConnector(handler);
        }
        if(handler != null && connector.handler != handler){
            connector.handler = handler;
        }
        return connector;
    }

    private long mNativeJavaObj;
    private DeviceConnectorHandler handler;
    private final CallbackHandler callback;

    public interface DeviceConnectorHandler {
        void onDeviceConnectorStateChanged(boolean online);

        void onDeviceConnectorMessageArrival(int type, boolean ack, int result, String message);
    }

    public DeviceConnector(DeviceConnectorHandler handler) {
        this.mNativeJavaObj = 0;
        this.handler = handler;
        this.callback = new CallbackHandler(this);
    }

    private static class CallbackHandler extends Handler {
        private final WeakReference<DeviceConnector> manager;

        CallbackHandler(DeviceConnector manager) {
            this.manager = new WeakReference<>(manager);
        }

        @Override
        public void handleMessage(Message message) {
            DeviceConnector manager = this.manager.get();
            if (manager != null) {
                if (message.what == 0) {
                    boolean online = message.getData().getBoolean("state");
                    manager.handler.onDeviceConnectorStateChanged(online);
                } else if (message.what == 1) {
                    int type = message.getData().getInt("type");
                    boolean ack = message.getData().getBoolean("ack");
                    int result = message.getData().getInt("result");
                    String msg = message.getData().getString("message");
                    manager.handler.onDeviceConnectorMessageArrival(type, ack, result, msg);
                }
            } else {
                super.handleMessage(message);
            }
        }
    }

    public boolean start(String socket_path) {
        return nativeStart(new WeakReference<DeviceConnector>(this),
                socket_path);
    }

    public void stop() {
        nativeStop();
    }

    public void Release() {
        nativeRelease();
    }

    public void Write(int type, boolean ack, int result, String message) {
        nativeWrite(type, ack, result, message);
    }

    static void onDeviceConnectorStateChanged(Object object, boolean online) {
        DeviceConnector connector = (DeviceConnector) ((WeakReference) object).get();
        if (connector == null) {
            return;
        }
        Message m = new Message();
        m.what = 0;
        Bundle bundle = new Bundle();
        bundle.putBoolean("state", online);
        m.setData(bundle);
        connector.callback.sendMessage(m);
    }

    static void onDeviceConnectorMessageArrival(Object object, int type, boolean ack, int result, String message) {
        DeviceConnector connector = (DeviceConnector) ((WeakReference) object).get();
        if (connector == null) {
            return;
        }
        Message m = new Message();
        m.what = 1;
        Bundle bundle = new Bundle();
        bundle.putInt("type", type);
        bundle.putBoolean("ack", ack);
        bundle.putInt("result", result);
        bundle.putString("message", message);
        m.setData(bundle);
        connector.callback.sendMessage(m);
    }

    private native boolean nativeStart(Object weak_this, String socket_path);

    private native void nativeStop();

    private native void nativeRelease();

    private native void nativeWrite(int type, boolean ack, int result, String message);
}
