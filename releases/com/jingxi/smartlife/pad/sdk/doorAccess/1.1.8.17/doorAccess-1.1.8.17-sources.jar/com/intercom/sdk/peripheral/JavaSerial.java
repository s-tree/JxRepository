package com.intercom.sdk.peripheral;

import android.support.annotation.NonNull;

import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class JavaSerial {

    public static class SerialAttributes {
        public static final int PARITY_ODD = 0;
        public static final int PARITY_EVEN = 1;
        public static final int PARITY_NONE = 2;

        public static final int CHOICES_RAW = 0;
        public static final int CHOICES_CANONICAL = 1;

        public String name;
        public int open_flags;
        public int parity;
        public int baud_rate;
        public int data_bits;
        public int stop_bits;
        public int hardware_flow_control;
        public int software_flow_control;
        public int input_mode;

        public SerialAttributes(String name,
                                int open_flags,
                                int baud_rate) {
            this.name = name;
            this.open_flags = open_flags;
            this.parity = PARITY_NONE;
            this.data_bits = 8;
            this.stop_bits = 1;
            this.hardware_flow_control = 0;
            this.software_flow_control = 0;
            this.input_mode = CHOICES_RAW;
            this.baud_rate = baud_rate;
        }

        public SerialAttributes(String name,
                                int open_flags,
                                int parity,
                                int baud_rate,
                                int data_bits,
                                int stop_bits,
                                int hardware_flow_control,
                                int software_flow_control,
                                int input_mode) {
            this.name = name;
            this.open_flags = open_flags;
            this.parity = parity;
            this.baud_rate = baud_rate;
            this.data_bits = data_bits;
            this.stop_bits = stop_bits;
            this.hardware_flow_control = hardware_flow_control;
            this.software_flow_control = software_flow_control;
            this.input_mode = input_mode;
        }
    }

    private FileDescriptor mFd;

    private FileInputStream mFileInputStream;
    private FileOutputStream mFileOutputStream;


    public JavaSerial(SerialAttributes attributes) throws IllegalArgumentException, IOException {
        if (attributes == null) {
            throw new IllegalArgumentException("Illegal null serial name");
        }
        mFd = native_open(attributes.name,
                attributes.open_flags,
                attributes.parity,
                attributes.baud_rate,
                attributes.data_bits,
                attributes.stop_bits,
                attributes.hardware_flow_control,
                attributes.software_flow_control,
                attributes.input_mode);
        if (mFd == null) {
            throw new IOException();
        }
        mFileInputStream = new FileInputStream(mFd);
        mFileOutputStream = new FileOutputStream(mFd);
    }

    public InputStream getInputStream() {
        return mFileInputStream;
    }

    public OutputStream getOutputStream() {
        return mFileOutputStream;
    }

    public void close() {
        try {
            if (mFileInputStream != null) {
                mFileInputStream.close();
            }
            if (mFileOutputStream != null) {
                mFileOutputStream.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (mFd != null) {
            native_close();
            mFd = null;
        }
    }

    public void write(@NonNull byte[] data, int sizeInBytes) throws IOException {
        mFileOutputStream.write(data, 0, sizeInBytes);
    }

    public int read(@NonNull byte[] data, int sizeInBytes) throws IOException {
        return mFileInputStream.read(data, 0, sizeInBytes);
    }


    private native final FileDescriptor native_open(String name,
                                                    int flags,
                                                    int parity,
                                                    int baud_rate,
                                                    int data_bits,
                                                    int stop_bits,
                                                    int hardware_flow_control,
                                                    int software_flow_control,
                                                    int input_mode);

    private native final void native_close();
}
