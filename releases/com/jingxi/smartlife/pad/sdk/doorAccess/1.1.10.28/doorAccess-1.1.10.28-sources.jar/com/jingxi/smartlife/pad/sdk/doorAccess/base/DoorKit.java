package com.jingxi.smartlife.pad.sdk.doorAccess.base;

import android.os.Build;

import com.intercom.sdk.IntercomConstants;

public class DoorKit {

    /**
     * 初始化一些参数
     *
     * @param options
     */
    public static void init(Options options) {
        if (options == null) {
            return;
        }
        DoorConfigs.options = options;
    }

    public static Options getOptions() {
        return DoorConfigs.options;
    }

    public static class Options {
        protected static Options getDefault() {
            return new Options();
        }

        private Options() {

        }

        /**
         * {@link com.intercom.sdk.IntercomConstants.NetClientSubType}
         * 默认是平板
         * 平板是 NetClientSubTypePad
         * 移动端是 NetClientSubTypeMobile
         */
        public int platform = IntercomConstants.NetClientSubType.NetClientSubTypePad;

        /**
         * 室内通使用
         * 该设备的备注
         */
        public String alias = null;

        /**
         * 设备的sn，移动端可传入accid，最终用于底层生成一个随机数
         */
        public String sn = "";

        /**
         * 一个唯一值，用于此设备的id，如不传，则为程序生成
         */
        public String clientID = null;

        /**
         * 最大可保存的门禁视频记录数量
         */
        public int maxRecordCount = 50;

        /**
         * 离线推送的ali
         */
        public String publishID = "";

        /**
         * 代理服务器地址
         */
        public String proxyServerUrl = DoorConfigs.PROXY_SERVER_URL;

        /**
         * 代理服务器重连
         */
        public int proxyRetryInterval = 5;

        /**
         * 代理服务器心跳间隔
         */
        public int proxykeepalive = 30;

        /**
         * 代理工作目录
         */
        public String portConf = DoorConfigs.PORT_CONF;

        /**
         * 渠道
         */
        public String channel = DoorConfigs.APP_CHANNEL;

        /**
         * 门禁服务工作的存储空间目录
         */
        public String doorAccessWorkDir = DoorConfigs.PATH;
        /**
         * 门禁服务服务端工作的存储空间目录
         */
        public String doorServerWorkDir = DoorConfigs.SERVER_PATH;

        /**
         * 门禁服务的注册服务器
         */
        public String intercomServerUrl = DoorConfigs.INTERCOM_SERVER_URL;
        /**
         * 证书路径
         */
        public String sslCertPath       = DoorConfigs.sslCertPath;

        public String deviceMonitorUrl = DoorConfigs.DEVICE_MONITOR_URL;

        /**
         * 平板使用SERIAL，手机使用accid
         */
        public String systemId = Build.SERIAL;

        /**
         * 代理工作目录
         */
        public String proxyWorkDir = "";

        public String remoteServiceConf = "{\"request_interval\":3600,\"conf\":[{\"url\":\"192.168.150.188:8080/remoteservice/cmd\"}]}";

        /**
         * 音频增益(播放)
         */
        public int audio_play_agc_level = 0;
        /**
         * 麦克风增益
         */
        public int audio_send_agc_level = 0;

        /**
         * 通话等待时间(秒)
         */
        public int max_session_wait_time = DoorConfigs.max_session_wait_time;
        /**
         * 通话过程超时时间(秒)
         */
        public int intercom_max_session_connect_time = DoorConfigs.intercom_max_session_connect_time;
        /**
         * 户户通超时时间
         * "p2p,1800,300"
         * 1800 : LAN模式下30分钟
         * 300  : WAN模式下 5分钟
         */
        public String special_p2p_device = DoorConfigs.special_p2p_device;
        /**
         * 室内通超时时间
         * "ext,2592000,86400"
         * 2592000 : LAN模式下30天
         * 86400   : WAN模式下24小时
         */
        public String speical_ext_device = DoorConfigs.speical_ext_device;

        public boolean disable_aec = false;

        /**
         * 麦克风增益
         */
        public int aec_latency = 80;

        public int denoise = 0;

        /**
         * 一体机连接楼宇对讲的网口名
         */
        public String lan_broadcast_exclude_interface = "eth1";

        /**
         * 是否是主机(捆绑 lan_broadcast_exclude_interface 使用)
         * false 时忽略
         */
        public boolean master_device = false;
    }
}
