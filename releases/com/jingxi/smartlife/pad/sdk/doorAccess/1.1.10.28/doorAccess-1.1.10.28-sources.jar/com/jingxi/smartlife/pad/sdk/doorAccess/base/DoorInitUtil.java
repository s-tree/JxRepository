package com.jingxi.smartlife.pad.sdk.doorAccess.base;

import android.app.Application;
import android.text.TextUtils;

import com.intercom.sdk.IntercomConfigure;
import com.intercom.sdk.IntercomManager;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.utils.FileUtil;
import com.jingxi.smartlife.pad.sdk.utils.JXContextWrapper;
import com.jingxi.smartlife.pad.sdk.utils.JXLogUtil;

import java.io.File;
import java.io.IOException;

public class DoorInitUtil {
    private static DoorInitUtil instance;

    public static DoorInitUtil getInstance() {
        if (instance == null) {
            synchronized (DoorInitUtil.class) {
                if (instance == null) {
                    instance = new DoorInitUtil();
                }
            }
        }
        return instance;
    }

    /**
     * 初始化
     */
    public void initDoorAccess() {
        IntercomManager.globalInitialize(JXContextWrapper.context,DoorConfigs.getAppConf());
        init();
    }

    /**
     *
     */
    public void unInitDoorAccess() {
        unInit();
    }

    private static DoorMessageCallback doorMessageCallback;

    private static boolean init() {
        JXLogUtil.logW(DoorConfigs.DOOR_LOG_TAG + " DoorInitUtil.init instance = " + getInstance());
        return IntercomManager.getInstance().start(
                DoorConfigs.options.systemId,
                DoorConfigs.getPortConf(),
                DoorConfigs.getIntercomConfig(),
                DoorConfigs.getNoVideoImage());
    }

    private static void unInit() {
        DoorSessionManager.hangupAll();
        IntercomManager.getInstance().stop();
    }

    private static void addFamily(String familyDockSn, String buttonKey) {
        IntercomManager.Intercom intercom = IntercomManager.getInstance().addIntercom(
                familyDockSn,
                DoorConfigs.getClientConf(familyDockSn, buttonKey));
        registerCallbacks(intercom);
    }

    public static void startFamily(String dockSn, String buttonKey) {
        if (TextUtils.isEmpty(dockSn)) {
            return;
        }
        while (dockSn.length() < 16) {
            dockSn += "0";
        }

        addFamily(dockSn, buttonKey);
        startProxy(dockSn);
        startIntercom(dockSn);
    }

    public static void stopFamily(String dockSn) {
        stopIntercom(dockSn);
        stopProxy(dockSn);
        IntercomManager.getInstance().removeIntercom(dockSn);
    }

    private static boolean startProxy(String familyDockSn) {
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyDockSn);
        if (intercom == null) {
            return false;
        }
        JXLogUtil.logW("代理已经启动");
        return intercom.startProxy(DoorConfigs.getProxyConfig());
    }

    private static void stopProxy(String familyDockSn) {
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyDockSn);
        if (intercom == null) {
            return;
        }
        intercom.stopProxy();
        JXLogUtil.logW("代理已经停止");
    }

    private static boolean startIntercom(String familyDockSn) {
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyDockSn);
        if (intercom == null) {
            return false;
        }
        return intercom.startIntercom(DoorConfigs.getServerConfig());
    }

    private static void stopIntercom(String familyDockSn) {
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyDockSn);
        if (intercom == null) {
            return;
        }
        intercom.stopIntercom();
        unRegisterCallbacks(intercom);
    }

    private static void registerCallbacks(IntercomManager.Intercom intercom) {
        if (doorMessageCallback == null) {
            doorMessageCallback = new DoorMessageCallback();
        }
        if(intercom == null){
            return;
        }
        IntercomManager.getInstance().app_listener.add(doorMessageCallback);
        intercom.client_listener.add(doorMessageCallback);
        intercom.proxy_listener.add(doorMessageCallback);
        intercom.intercom_listener.add(doorMessageCallback);
        intercom.smarthome_listener.add(doorMessageCallback);
    }

    private static void unRegisterCallbacks(IntercomManager.Intercom intercom){
        if(intercom == null){
            return;
        }
        intercom.client_listener.remove(doorMessageCallback);
        intercom.proxy_listener.remove(doorMessageCallback);
        intercom.intercom_listener.remove(doorMessageCallback);
        intercom.smarthome_listener.remove(doorMessageCallback);
    }

    public void copyCertFiles() {
        try {
            String[] fileNames = JXContextWrapper.context.getAssets().list(DoorConfigs.TLS_DIR_NAME);
            if (fileNames == null) {
                return;
            }
            File dir = new File(FileUtil.TLS_DIR);
            if (!dir.exists() && !dir.mkdirs()) {
                return;
            }
            for (int i = 0; i < fileNames.length; i++) {
                FileUtil.startCopyFile(fileNames[i], DoorConfigs.TLS_DIR_NAME);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
