package com.intercom.sdk;

import com.google.gson.Gson;

import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * 代理和终端的管理，包含LAN/WAN
 * 通过IntercomManager的有关代理上下线的时间更新代理和终端信息
 * 在这里维持一份完整的代理和终端的列表
 */
public class IntercomClientManager {
    /**
     * 代理集合: <proxy_id, 代理对象>
     */
    public final Map<String, IntercomProxy> proxies;

    /**
     * 终端集合，<client_id,终端对象>
     */
    public final Map<String, IntercomClient> clients;

    /**
     * internet是否在线，表示当前是否与internet服务器保持连接
     */
    private boolean internetProxyOnline;

    private final WeakReference<IntercomManager.Intercom> intercom;


    public IntercomClientManager(IntercomManager.Intercom intercom) {
        this.intercom = new WeakReference<>(intercom);
        this.internetProxyOnline = false;
        this.proxies = new HashMap<>();
        this.clients = new HashMap<>();
    }

    /**
     * @param router:LAN/WAN代理.
     * @param online
     * @param proxy:代理的详细信息
     */
    public void updateProxy(int router, boolean online, IntercomProxy proxy) {

        if (online) {
            /*
             * 代理上线了
             */
            IntercomProxy currentProxy = findProxy(proxy.proxy_id);
            if (currentProxy != null) {
                /*
                 * 这个代理以前就存在，我们要比较添加之前和之后的状态变化
                 * 给上层相关的通知
                 */
                boolean pre_lan_online = currentProxy.lanOnline();
                boolean pre_wan_online = currentProxy.wanOnline();

                currentProxy.update(proxy);

                boolean current_lan_online = currentProxy.lanOnline();
                boolean current_wan_online = currentProxy.wanOnline();

                if (current_lan_online != pre_lan_online) {
                    /**
                     * LAN上的代理发生了变化，我们通知上层
                     */
                    IntercomManager.Intercom intercom = this.intercom.get();
                    if (intercom != null) {
                        intercom.proxy_listener.onIntercomProxyOnlineStateChanged(intercom,
                                currentProxy.proxy_id,
                                IntercomConstants.Router.LAN,
                                current_lan_online);
                    }
                }
                if (current_wan_online != pre_wan_online) {
                    /**
                     * WAN上的代理发生了变化，我们通知上层
                     */
                    IntercomManager.Intercom intercom = this.intercom.get();
                    if (intercom != null) {
                        intercom.proxy_listener.onIntercomProxyOnlineStateChanged(intercom,
                                currentProxy.proxy_id,
                                IntercomConstants.Router.PROXY,
                                current_wan_online);
                    }
                }
            } else {
                /**
                 * 这是一个新发现的代理
                 */
                currentProxy = new IntercomProxy(proxy);
                proxies.put(proxy.proxy_id, currentProxy);
                IntercomManager.Intercom intercom = this.intercom.get();
                if (intercom != null) {
                    intercom.proxy_listener.onIntercomProxyStateChanged(intercom, proxy.proxy_id, online);
                }
            }
        } else {
            /**
             * 某个代理下线了
             */
            if (router == IntercomConstants.Router.LAN) {
                /**
                 * 如果是LAN上的代理下线了，我们要把这个代理上所有终端都删除
                 * 因为底层不会有相关的通知
                 */
                lanProxyOffline(proxy.proxy_id);
            }

            IntercomProxy currentProxy = findProxy(proxy.proxy_id);
            if (currentProxy != null) {
                /**
                 * 这个代理之前存在的
                 */
                boolean pre_lan_online = currentProxy.lanOnline();
                boolean pre_wan_online = currentProxy.wanOnline();

                currentProxy.remove(router);

                if (currentProxy.empty()) {
                    /**
                     * 这个代理已经彻底下线了，我们要从集合中删除之
                     */
                    proxies.remove(proxy.proxy_id);
                    IntercomManager.Intercom intercom = this.intercom.get();
                    if (intercom != null) {
                        intercom.proxy_listener.onIntercomProxyStateChanged(intercom,
                                proxy.proxy_id, online);
                    }
                } else {
                    /**
                     * 这个代理LAN或者WAN还在线，我们要对比之前和之后的状态，给上层相应的通知
                     */
                    boolean current_lan_online = currentProxy.lanOnline();
                    boolean current_wan_online = currentProxy.wanOnline();

                    if (current_lan_online != pre_lan_online) {
                        IntercomManager.Intercom intercom = this.intercom.get();
                        if (intercom != null) {
                            intercom.proxy_listener.onIntercomProxyOnlineStateChanged(intercom,
                                    currentProxy.proxy_id,
                                    IntercomConstants.Router.LAN,
                                    current_lan_online);
                        }
                    }
                    if (current_wan_online != pre_wan_online) {
                        IntercomManager.Intercom intercom = this.intercom.get();
                        if (intercom != null) {
                            intercom.proxy_listener.onIntercomProxyOnlineStateChanged(intercom,
                                    currentProxy.proxy_id,
                                    IntercomConstants.Router.PROXY,
                                    current_wan_online);
                        }
                    }
                }
            }
        }
    }

    /**
     * 更新终端信息
     *
     * @param router：路由
     * @param online：是否在线
     * @param proxy_id：终端所在代理的ID(对router=LAN有效)，也就是proxy_id!!!
     * @param client_string:终端的配置信息
     */
    public void updateClient(int router, boolean online, String proxy_id, String client_string) {
        NetClient client = new Gson().fromJson(client_string, NetClient.class);
        if (client == null)
            return;

        if (online) {
            IntercomClient currentClient = findClient(client.getClient_id());
            if (currentClient == null) {
                /**
                 * 这个一个新的终端，不在历史列表中
                 */
                currentClient = new IntercomClient(client.getClient_id());
                currentClient.add(router, proxy_id, client);
                clients.put(client.getClient_id(), currentClient);
                IntercomManager.Intercom intercom = this.intercom.get();
                if (intercom != null) {
                    intercom.proxy_listener.onIntercomClientStateChanged(intercom,
                            client.getClient_id(), online);
                }
            } else {
                /**
                 * 这个终端已经存在，我们更新一下状态
                 */
                boolean pre_lan_online = currentClient.lanOnline();
                boolean pre_wan_online = currentClient.wanOnline();

                currentClient.add(router, proxy_id, client);

                boolean current_lan_online = currentClient.lanOnline();
                boolean current_wan_online = currentClient.wanOnline();

                if (current_lan_online != pre_lan_online) {
                    IntercomManager.Intercom intercom = this.intercom.get();
                    if (intercom != null) {
                        intercom.proxy_listener.onIntercomClientOnlineStateChanged(intercom,
                                client.getClient_id(),
                                proxy_id, IntercomConstants.Router.LAN,
                                current_lan_online);
                    }
                }
                if (current_wan_online != pre_wan_online) {
                    IntercomManager.Intercom intercom = this.intercom.get();
                    if (intercom != null) {
                        intercom.proxy_listener.onIntercomClientOnlineStateChanged(intercom,
                                client.getClient_id(),
                                proxy_id,
                                IntercomConstants.Router.PROXY,
                                current_wan_online);
                    }
                }
            }
        } else {
            /**
             * 终端下线了
             */
            IntercomClient currentClient = findClient(client.getClient_id());
            if (currentClient != null) {
                /**
                 * 这个终端之前存在
                 */
                boolean pre_lan_online = currentClient.lanOnline();
                boolean pre_wan_online = currentClient.wanOnline();

                currentClient.remove(router, proxy_id);

                if (currentClient.empty()) {
                    /**
                     * 这个终端从所有代理上下线了，我们删除之
                     */
                    clients.remove(client.getClient_id());
                    IntercomManager.Intercom intercom = this.intercom.get();
                    if (intercom != null) {
                        intercom.proxy_listener.onIntercomClientStateChanged(intercom,
                                client.getClient_id(), online);
                    }
                } else {
                    /**
                     * 这个终端在某些代理上还活着
                     */
                    boolean current_lan_online = currentClient.lanOnline();
                    boolean current_wan_online = currentClient.wanOnline();

                    if (current_lan_online != pre_lan_online) {
                        IntercomManager.Intercom intercom = this.intercom.get();
                        if (intercom != null) {
                            intercom.proxy_listener.onIntercomClientOnlineStateChanged(intercom,
                                    client.getClient_id(),
                                    proxy_id,
                                    IntercomConstants.Router.LAN,
                                    current_lan_online);
                        }
                    }
                    if (current_wan_online != pre_wan_online) {
                        IntercomManager.Intercom intercom = this.intercom.get();
                        if (intercom != null) {
                            intercom.proxy_listener.onIntercomClientOnlineStateChanged(intercom,
                                    client.getClient_id(),
                                    proxy_id,
                                    IntercomConstants.Router.PROXY,
                                    current_wan_online);
                        }
                    }
                }
            }
        }
    }

    public void changeInternetState(boolean online) {
        internetProxyOnline = online;
        if (!online) {
            internetOffline();
        }
    }

    /**
     * Internet掉线了，我们要删除所有与Internet相关的代理和终端
     */
    public void internetOffline() {
        /**
         * 先删除WAN代理
         */
        {
            Set<String> keySet = proxies.keySet();

            if (!keySet.isEmpty()) {
                Set<String> c = new HashSet<>(keySet);

                for (String key : c) {
                    IntercomProxy proxy = findProxy(key);
                    if (proxy != null) {
                        String proxy_id = proxy.proxy_id;
                        boolean wan_online = proxy.wanOnline();

                        proxy.remove(IntercomConstants.Router.PROXY);

                        if (proxy.empty()) {
                            proxies.remove(key);
                            IntercomManager.Intercom intercom = this.intercom.get();
                            if (intercom != null) {
                                intercom.proxy_listener.onIntercomProxyStateChanged(intercom,
                                        proxy_id, false);
                            }
                        } else if (wan_online) {
                            /**
                             * 如果之前WAN在线，此刻应该属于下线，所以要通知上层
                             */
                            IntercomManager.Intercom intercom = this.intercom.get();
                            if (intercom != null) {
                                intercom.proxy_listener.onIntercomProxyOnlineStateChanged(intercom, proxy_id,
                                        IntercomConstants.Router.PROXY,
                                        false);
                            }
                        }
                    }
                }
            }
        }

        /**
         * 删除WAN client
         */
        {
            Set<String> keySet = clients.keySet();
            if (!keySet.isEmpty()) {
                Set<String> c = new HashSet<>(keySet);
                for (String key : c) {
                    IntercomClient client = findClient(key);
                    if (client != null) {
                        String client_id = client.client_id;
                        boolean wan_online = client.wanOnline();

                        client.remove(IntercomConstants.Router.PROXY, null);

                        if (client.empty()) {
                            clients.remove(key);
                            IntercomManager.Intercom intercom = this.intercom.get();
                            if (intercom != null) {
                                intercom.proxy_listener.onIntercomClientStateChanged(intercom,
                                        client_id, false);
                            }
                        } else if (wan_online) {
                            IntercomManager.Intercom intercom = this.intercom.get();
                            if (intercom != null) {
                                intercom.proxy_listener.onIntercomClientOnlineStateChanged(intercom,
                                        client_id,
                                        null,
                                        IntercomConstants.Router.PROXY,
                                        false);
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * LAN代理下线了，我们处理下这个代理上的终端
     *
     * @param proxy_id
     */
    private void lanProxyOffline(String proxy_id) {
        Set<String> clientKeySet = clients.keySet();
        if (!clientKeySet.isEmpty()) {
            Set<String> c = new HashSet<>(clientKeySet);
            for (String key : c) {
                IntercomClient client = clients.get(key);
                if (client != null) {
                    String client_id = client.client_id;

                    boolean pre_lan_online = client.lanOnline();

                    client.remove(IntercomConstants.Router.LAN, proxy_id);

                    if (client.empty()) {
                        clients.remove(key);
                        IntercomManager.Intercom intercom = this.intercom.get();
                        if (intercom != null) {
                            intercom.proxy_listener.onIntercomClientStateChanged(intercom, client_id, false);
                        }
                    } else {
                        boolean current_lan_online = client.lanOnline();
                        if (current_lan_online != pre_lan_online) {
                            IntercomManager.Intercom intercom = this.intercom.get();
                            if (intercom != null) {
                                intercom.proxy_listener.onIntercomClientOnlineStateChanged(intercom,
                                        client_id,
                                        proxy_id,
                                        IntercomConstants.Router.LAN,
                                        current_lan_online);
                            }
                        }
                    }
                }
            }
        }
    }

    public boolean padOnline(String proxy_id, String button_key) {
        if (clients.isEmpty())
            return false;

        for (Map.Entry<String, IntercomClient> entry : clients.entrySet()) {
            if (entry.getValue().padOnline(proxy_id, button_key)) {
                return true;
            }
        }
        return false;
    }

    public IntercomProxy findProxy(String proxy_id) {
        if (proxies.isEmpty())
            return null;
        return proxies.get(proxy_id);
    }

    public IntercomClient findClient(String client_id) {
        if (clients.isEmpty())
            return null;
        return clients.get(client_id);
    }

    public void cleanup() {
        clients.clear();
        proxies.clear();
    }

    public boolean getInternetProxyOnline() {
        return internetProxyOnline;
    }

    /**
     * 每个代理包含两个部分信息: 代理自身的信息，由 NetClient 描述
     * 代理中包含的设备信息，由 NetDevice 描述
     */
    public static class IntercomProxyDescription {
        public final NetClient netClient;
        public final IntercomNetDevice netDevice;

        public IntercomProxyDescription(NetClient netClient, IntercomNetDevice netDevice) {
            this.netClient = netClient;
            this.netDevice = netDevice;
        }
    }

    /**
     * 代理的描述对象，每个代理可以包含来自LAN发现的代理和Internet发现的代理
     * 它们的proxy_id是一样的，LAN和WAN允许单独上下线
     * 只有当LAN都WAN都下线，这个代理才真正下线，并从队列中删除
     * 我们呼叫的时候，优先使用LAN模式，如果没有LAN，则可以用WAN上的代理
     */
    public static class IntercomProxy {

        /* lAN发现的代理 */
        public IntercomProxyDescription lanProxy;

        /* 通过中转服务器发现的代理 */
        public IntercomProxyDescription wanProxy;

        public final String proxy_id;

        /* constructor from other proxy */
        private IntercomProxy(IntercomProxy proxy) {
            this.lanProxy = null;
            this.wanProxy = null;

            if (proxy.lanProxy != null) {
                this.lanProxy = proxy.lanProxy;
            }
            if (proxy.wanProxy != null) {
                this.wanProxy = proxy.wanProxy;
            }
            proxy_id = proxy.proxy_id;
        }

        /*constructor*/
        private IntercomProxy(int router, NetClient netClient, IntercomNetDevice netDevice) {
            this.lanProxy = null;
            this.wanProxy = null;
            if (router == IntercomConstants.Router.LAN) {
                this.lanProxy = new IntercomProxyDescription(netClient, netDevice);
            } else if (router == IntercomConstants.Router.PROXY) {
                this.wanProxy = new IntercomProxyDescription(netClient, netDevice);
            }
            this.proxy_id = netClient.getClient_id();
        }

        /*static constructor*/
        static public IntercomProxy create(int router, String clientString, String deviceString) {
            NetClient netClient = new Gson().fromJson(clientString, NetClient.class);
            if (netClient == null)
                return null;
            IntercomNetDevice netDevice = IntercomNetDevice.objectFromData(deviceString);
            return new IntercomProxy(router, netClient, netDevice);
        }

        /**
         * 更新代理，LAN或者WAN上的代理发生变化
         *
         * @param proxy
         */
        private void update(IntercomProxy proxy) {
            if (proxy.lanProxy != null) {
                this.lanProxy = proxy.lanProxy;
            }
            if (proxy.wanProxy != null) {
                this.wanProxy = proxy.wanProxy;
            }
        }

        private boolean empty() {
            return this.lanProxy == null && this.wanProxy == null;
        }

        public boolean lanOnline() {
            return this.lanProxy != null;
        }

        public boolean wanOnline() {
            return this.wanProxy != null;
        }

        /**
         * 删除LAN/WAN上的代理
         * 当某个路由上的代理掉线了，我们要更新一下本缓存
         *
         * @param router
         */
        private void remove(int router) {
            if (router == IntercomConstants.Router.LAN) {
                this.lanProxy = null;
            } else if (router == IntercomConstants.Router.PROXY) {
                this.wanProxy = null;
            }
        }
    }

    /**
     * 描述终端的信息
     */
    public static class IntercomClient {
        /**
         * 终端可以在多个代理上被发现，我们全部保存起来
         * lanClients: Map<proxy_id,NetClient>
         */
        public Map<String, NetClient> lanClients;

        /**
         * Internet的终端只有一份，因为不会有多个中转服务器
         */
        public NetClient wanClient;

        public final String client_id;

        private IntercomClient(String client_id) {
            this.lanClients = new HashMap<>();
            this.wanClient = null;
            this.client_id = client_id;
        }

        private boolean empty() {
            return (this.lanClients.isEmpty())
                    && this.wanClient == null;
        }

        /**
         * 添加一个终端到队列中
         *
         * @param router:路由
         * @param proxy_id:代理的id
         * @param netClient:终端信息
         */
        private void add(int router, String proxy_id, NetClient netClient) {
            if (router == IntercomConstants.Router.LAN) {
                /*
                 * 说明这个终端通过LAN的某个代理上线的
                 */
                remove(router, proxy_id);
                this.lanClients.put(proxy_id, netClient);
            } else if (router == IntercomConstants.Router.PROXY) {
                /*
                 * 代理从Internet上上线的
                 */
                this.wanClient = netClient;
            }
        }

        /**
         * 删除某个代理上的终端，或者Internet上的终端
         *
         * @param router
         * @param proxy_id
         */
        private void remove(int router, String proxy_id) {
            if (router == IntercomConstants.Router.LAN) {
                /*
                 * LAN代理上的某个终端掉线了，我们删除之
                 */
                if (this.lanClients.containsKey(proxy_id)) {
                    this.lanClients.remove(proxy_id);
                }
            } else if (router == IntercomConstants.Router.PROXY) {
                this.wanClient = null;
            }
        }

        public boolean padOnline(String proxy_id, String button_key) {
            NetClient client = findLanClientWithProxyId(proxy_id);
            if (client == null) {
                if (this.wanClient == null)
                    return false;

                if (this.wanClient.getSub_type() != IntercomConstants.NetClientSubType.NetClientSubTypePad)
                    return false;

                if (button_key == null)
                    return true;

                String key = this.wanClient.getButton_key();
                if (key == null)
                    return false;

                return key.equalsIgnoreCase(button_key);
            }

            if (client.getSub_type() != IntercomConstants.NetClientSubType.NetClientSubTypePad)
                return false;

            if (button_key == null)
                return true;

            String key = client.getButton_key();
            if (key == null)
                return false;

            return key.equalsIgnoreCase(button_key);
        }

        public boolean lanOnline() {
            return !this.lanClients.isEmpty();
        }

        public boolean wanOnline() {
            return this.wanClient != null;
        }

        public NetClient findLanClientWithProxyId(String proxy_id) {
            if (!this.lanClients.containsKey(proxy_id))
                return null;
            return this.lanClients.get(proxy_id);
        }
    }
}
