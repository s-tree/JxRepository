package com.intercom.sdk;

import android.os.Bundle;

import java.io.File;
import java.util.List;

public class LoadConfigure {
    private final String LOADFILENAME = "load.ini";
    private final File file;
    private INIWriter writer;

    public LoadConfigure(String path) {
        this.file = new File(path, LOADFILENAME);
        this.writer = new INIWriter();
        this.writer.initFromFile(this.file);
    }

    public void commit() {
        this.writer.commit(this.file, true);
    }

    public String getFamilyId(boolean raw) {
        String str = this.writer.getValue("key", "key");
        if (raw) return str;
        return IntercomManager.CryptoFamilyId(false, str);
    }

    public void setFamilyId(String fid, boolean raw) {
        if (raw) {
            String str = IntercomManager.CryptoFamilyId(true, fid);
            this.writer.add("key", "key", str);
        } else {
            this.writer.add("key", "key", fid);
        }
    }

    public String getButtonKey() {
        return this.writer.getValue("key", "button_key");
    }

    public void setButtonKey(String value) {
        this.writer.add("key", "button_key", value);
    }

    public void addKey(String name, String key, String value) {
        this.writer.add(name, key, value);
    }

    public void removeKey(String name, String key) {
        this.writer.remove(name, key);
    }

    public List<String> getDeviceList() {
        return this.writer.getKeySet("load");
    }

    public Bundle getDeviceInfo(String key) {
        String value = this.writer.getValue("load", key);
        if (value == null)
            return null;
        String[] arr = value.split(",", 10);
        if (arr.length < 1)
            return null;
        Bundle bundle = new Bundle();
        bundle.putString("scheme", arr[0]);
        if (arr.length > 1) {
            bundle.putString("class", arr[1]);
        }
        if (arr.length > 2) {
            bundle.putString("alias", arr[2]);
        }
        return bundle;
    }

    public void setDeviceInfo(String key, String scheme, String dclass, String alias) {
        String str = String.format("%s,%s,%s", scheme, dclass, alias);
        this.writer.add("load", key, str);
    }

    public void removeDevice(String key) {
        this.writer.commentKey("load", key);
    }
}
