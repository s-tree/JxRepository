package com.jingxi.smartlife.pad.sdk.doorAccess.base.bean;

import com.litesuits.orm.db.annotation.PrimaryKey;
import com.litesuits.orm.db.annotation.Table;
import com.litesuits.orm.db.enums.AssignType;

@Table("RecordVideoBean")
public class RecordVideoBean {

    @PrimaryKey(AssignType.BY_MYSELF)
    public String videoSession;
    public long startTime;
    public long chatTime;
    public String picPath;
    public String videoPath;
}
