package com.jingxi.smartlife.pad.sdk.doorAccess.base.ui;

import com.intercom.sdk.IntercomManager;
import com.intercom.sdk.NetClient;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorSessionManager;

public interface DoorAccessListener {

    /**
     * 响铃,可从 {@link DoorSessionManager#getCurrentDevice(String session)} 获取到当前的呼叫设备
     */
    void onRinging(String sessionId);

    /**
     * 门锁已开
     */
    void onUnLock(String sessionID);

    /**
     * 设备列表在线状态
     */
    void onDeviceChanged(String familyID,boolean isDoorDeviceOnLine,boolean isUnitDeviceOnline,boolean isPropertyDeviceOnLine);

    /**
     * 底座的按键事件
     * @param buttonKey
     *
     *  @param cmd   对应底座5个按钮事件
     * {@link com.intercom.sdk.IntercomConstants#kButtonSOS}
     * {@link com.intercom.sdk.IntercomConstants#kButtonUser}
     * {@link com.intercom.sdk.IntercomConstants#kButtonMonitor}
     * {@link com.intercom.sdk.IntercomConstants#kButtonUnlock}
     * {@link com.intercom.sdk.IntercomConstants#kButtonPickup}
     *
     *  以下两个对应移动感应
     * {@link com.intercom.sdk.IntercomConstants#kButtonHumanNear}
     * {@link com.intercom.sdk.IntercomConstants#kButtonHumanNear}
     *
     *  @param time, 按键触发的时间
     */
    void onBaseButtonClick(NetClient netClient, String cmd, String time);

    /**
     * 门禁sdk 初始化成功
     * @param result
     */
    void onIntercomAppIntialized(boolean result) ;
    /**
     * 代理在线的状态变更
     * @param familyID
     * @param proxyId
     * @param router
     * @param online
     */
    void onProxyOnlineStateChanged(String familyID,String proxyId, int router, boolean online);

    /**
     * 当前通话的快照
     */
    void onSnapshotReady(String familyID,String sessionID,String filePath);

    void onButtonEvent(int event, String id, String sound);

    void onButtonClick(String id);

    void onRemoteServiceStateChanged(int state);

    void onIntercomClientInitializeResult(IntercomManager.Intercom intercom, boolean result);
}
