package com.jingxi.smartlife.pad.sdk.doorAccess.base.utils;

import android.os.Environment;

import com.jingxi.smartlife.pad.sdk.utils.JXContextWrapper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class FileUtil {
    public static String EXTERNAL_STOREPATH = getExternalStorePath();
    public static final String TLS_DIR = EXTERNAL_STOREPATH + "/tls";
    public static void deleteFile(File deleteFile){
        if(!deleteFile.exists()){
            return;
        }
        if(deleteFile.isDirectory()){
            File[] listFiles = deleteFile.listFiles();
            for(File file : listFiles){
                deleteFile(file);
            }
        }
        try {
            deleteFile.deleteOnExit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 是否有外存卡
     */
    public static boolean isExistExternalStore() {
        return Environment.getExternalStorageState().equals(
                Environment.MEDIA_MOUNTED);
    }

    /**
     * 外置存储卡的路径
     */
    public static String getExternalStorePath() {
        if (isExistExternalStore()) {
            return Environment.getExternalStorageDirectory().getAbsolutePath();
        }
        return null;
    }

    public static void startCopyFile(String fileName, String dir) {
        InputStream reader = null;
        OutputStream writer = null;
        try {
            reader = JXContextWrapper.context.getAssets().open(dir + "/" + fileName);

            File file = new File(TLS_DIR + "/" + fileName);
            file.createNewFile();
            writer = new FileOutputStream(file);
            byte[] bytes = new byte[20480];
            int k;
            while ((k = reader.read(bytes)) != -1) {
                writer.write(bytes, 0, k);
            }
            writer.flush();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (writer != null) {
                    writer.close();
                }
                if (reader != null) {
                    reader.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
