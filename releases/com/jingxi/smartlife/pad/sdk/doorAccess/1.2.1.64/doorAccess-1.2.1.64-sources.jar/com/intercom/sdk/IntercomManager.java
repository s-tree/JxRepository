package com.intercom.sdk;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.Surface;

import com.google.gson.Gson;
import com.intercom.base.annotations.CalledByNative;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 门禁的接口，包含一个或者多个Intercom实例
 * 每个Intercom实例表示一个家庭
 */
public class IntercomManager {

    private static final String TAG = "manager";
    /**
     * Accessed by native methods: provides access to C++ IntercomManager object
     */
    @SuppressWarnings("unused")
    private long mNativeJavaObj;

    private final CallbackHandler callback;

    //一个或者多个家庭终端对象，室内机平板一般只有一个，移动端可能有多个家庭
    private final Map<String, Intercom> intercoms;

    public final IntercomObserver.IntercomAppListener app_listener;

    private static IntercomManager instance;

    public static IntercomManager getInstance() {
        if (instance == null) {
            synchronized (IntercomManager.class) {
                if (instance == null) {
                    instance = new IntercomManager();
                }
            }
        }
        return instance;
    }

    public IntercomManager() {
        this.callback = new CallbackHandler(this);
        this.app_listener = new IntercomObserver.IntercomAppListener();
        this.intercoms = new HashMap<>();
        this.mNativeJavaObj = 0;
    }

    public static void globalInitialize(Context context, String app_conf) {
        nativeGlobalInitialize(context, app_conf);
    }

    /**
     * 初始化门禁系统，需要提供基本的配置参数
     * system_id为何移动到这里呢？主要是考虑到移动端获取不到系统唯一标识，
     * 可能使用慧管家账号作为System_id，而且可能会切换账号
     * 所以，切换账号要重新start整个系统
     */
    public boolean start(String system_id,
                         String port_conf,
                         String intercom_conf,
                         byte[][] arrays) {
        return nativeStart(new WeakReference<IntercomManager>(this),
                system_id, port_conf, intercom_conf, arrays);
    }

    /**
     * 卸载门禁所有资源
     */
    public void stop() {
        List<Intercom> tempList = new ArrayList<>(intercoms.values());
        for (Intercom icom : tempList) {
            icom.unInitialize();
        }
        nativeStop();
    }

    public void release() {
        nativeRelease();
        intercoms.clear();
    }

    @Override
    protected void finalize() {
        nativeFinalize();
    }

    /**
     * 添加一个门禁实例
     */
    public Intercom addIntercom(String id,
                                String client_conf,
                                int type) {

        if (intercoms.containsKey(id)) {
            return getIntercom(id);
        }

        Intercom intercom = new Intercom(this, id, type);

        if (intercom.initialize(client_conf)) {
            intercoms.put(id, intercom);
            return intercom;
        }
        return null;
    }

    public void removeIntercom(String id) {
        Intercom intercom = intercoms.get(id);
        if (intercom != null) {
            intercom.unInitialize();
            intercoms.remove(id);
        }
    }

    public Intercom getIntercom(String id) {
        if (id == null) {
            if (intercoms.isEmpty())
                return null;
            List<Intercom> tempList = new ArrayList<>(intercoms.values());
            for (Intercom value : tempList) {
                return value;
            }
        }
        return intercoms.get(id);
    }

    public Collection<Intercom> getAllIntercom() {
        if (intercoms != null) {
            return intercoms.values();
        }
        return new ArrayList<>();
    }

    //---------------------------------------------------------
    // Java methods called from the native side
    //--------------------
    @CalledByNative
    @SuppressWarnings("unused")
    private static void onNativeAppMessageArrival(Object thiz, Bundle bundle) {
        IntercomManager manager = (IntercomManager) ((WeakReference) thiz).get();
        if (manager != null && manager.callback != null) {
            Message m = new Message();
            m.what = 0;
            m.setData(bundle);
            manager.callback.sendMessage(m);
        }
    }

    private static class CallbackHandler extends Handler {
        private final WeakReference<IntercomManager> manager;

        //package-private
        CallbackHandler(IntercomManager manager) {
            this.manager = new WeakReference<>(manager);
        }

        @Override
        public void handleMessage(Message message) {
            IntercomManager manager = this.manager.get();
            if (manager != null && message.what == 0) {
                manager.onAppMessageEvent(message.getData());
            } else {
                super.handleMessage(message);
            }
        }
    }


    /**
     * java层对底层消息的解析，整个事件的解析和分发都在这里完成
     *
     * @param bundle
     */
    void onAppMessageEvent(Bundle bundle) {

        if (bundle.containsKey("$id$")) {
            //某个家庭的消息
            String id = bundle.getString("$id$");
            Intercom intercom = getIntercom(id);
            if (intercom != null) {
                intercom.onIntercomMessageEvent(bundle);
            }
            return;
        }

        String scheme = bundle.getString("scheme");
        if (scheme == null || !bundle.containsKey("event"))
            return;

        int event = bundle.getInt("event");

        if (scheme.equalsIgnoreCase(IntercomConstants.kAppScheme)) {
            if (event == IntercomConstants.AppEvent.Event_App_Initialized) {
                boolean result = bundle.getBoolean("result");
                this.app_listener.onIntercomAppIntialized(result);

            } else if (event == IntercomConstants.AppEvent.Event_Media_Device_State_Changed) {
                int media_type = bundle.getInt("media_type");
                int state = bundle.getInt("state");
                this.app_listener.onIntercomMediaDeviceStateChanged(media_type, state);

            } else if (event == IntercomConstants.AppEvent.Event_Camera_State_Changed) {
                int state = bundle.getInt("state");
                this.app_listener.onCameraStateChanged(state);

            } else if (event == IntercomConstants.AppEvent.Event_Camera_Error) {
                int err = bundle.getInt("err");
                String from = bundle.getString("from");
                String reason = bundle.getString("reason");
                this.app_listener.onCameraError(err, from, reason);
            }
        }
    }

    public void switchCamera(String name) {
        Bundle bundle = new Bundle();
        bundle.putInt("type", 1);
        bundle.putString("value", name);

        Bundle message = new Bundle();
        message.putString("scheme", "app");
        message.putString("command", "switch_camera");
        message.putString("message", BundleToJSON.toString(bundle));
        nativeAppCommand(message);
    }

    public void sendPushMessage(String message) {
        Bundle bundle = new Bundle();
        bundle.putBoolean("push", true);
        bundle.putString("message", message);
        nativeAppMessage(bundle);
    }

    public void updatePreviewSurface(Surface surface) {
        nativeUpdatePreviewSurface(surface);
    }

    public void enablePreview(boolean enable) {
        nativeEnablePreview(enable);
    }

    public void sendAppCommand(Bundle bundle) {
        nativeAppCommand(bundle);
    }

    public void sendAppMessage(Bundle bundle) {
        nativeAppMessage(bundle);
    }

    public static String[] enumeratorRecord() {
        return nativeEnumeratorRecord();
    }

    public static String getSDKVersion() {
        return nativeGetSDKVersion();
    }

    /**
     * 生成一个会话id，在callout时候使用
     *
     * @return
     */
    public static String createSessionId() {
        return nativeCreateSessionId();
    }

    /**
     * base64编解码，对IntercomManger相关接口中出现的base64编解码，均需要使用这个接口
     * 不能使用第三方提供的库
     *
     * @param encode
     * @param content
     * @return
     */
    public static String base64(boolean encode, String content) {
        if (encode && TextUtils.isEmpty(content)) {
            return content;
        }
        return nativeBase64(encode, content);
    }

    /**
     * 3des加解密
     *
     * @param encode
     * @param key
     * @param content
     * @return
     */
    public static byte[] encode(boolean encode, String key, byte[] content) {
        return nativeEncode(encode, key, content);
    }

    /**
     * 加密或者解密family ID
     */
    public static String encodeFamilyId(boolean encode, String content) {
        return nativeEncodeFamilyId(encode, content);
    }

    /**
     * 解码从云端推送过来的message
     *
     * @param json
     * @return bundle.getString(" scheme "): kIntercomScheme,kSmarthomeScheme,其他的直接抛弃
     * bundle.getString("cmd"): 根据scheme，而不同
     * bundle.getString("to"):目标client_id，应该就是当前设备
     * bundle.getInteger("to_type"):目标设备类型
     * bundle.getBoolean("ack"):是否是回复消息
     * bundle.getInteger("version"):协议版本
     * bundle.getInteger("errcode"):错误代码
     * bundle.getString("net_client"):发送者的client信息，可以从 NetClient net_client = NetClient.objectFromData(str)解析
     * bundle.getString("payload"):消息正文，根据scheme 而不同
     * 如果scheme: kIntercomScheme, IntercomMessage message = IntercomMessage.IntercomMessage(payload);
     * 如果是:kSmarthomeScheme:可以解析成SmartHomeMessage消息
     */
    public static Bundle decodeProxyMessage(String json) {
        return nativeDecodeProxyMessage(json);
    }

    public static class Intercom {

        public final IntercomClientManager clientManager;
        public IntercomSessionManager sessionManager;
        public SmartHomeManager smartHomeManager;
        private final WeakReference<IntercomManager> manager;

        public final String id;
        private NetClient netClient;
        private String last_button_message_time;

        public final IntercomObserver.IntercomClientListener client_listener;
        public final IntercomObserver.IntercomListener intercom_listener;
        public final IntercomObserver.ProxyListener proxy_listener;
        public final IntercomObserver.SmartHomeListener smarthome_listener;

        public int intercom_type = 0;

        private Intercom(IntercomManager manager, String id, int type) {
            this.manager = new WeakReference<>(manager);
            this.id = id;
            this.intercom_type = type;
            this.netClient = null;
            this.clientManager = new IntercomClientManager(this);
            this.sessionManager = null;
            this.smartHomeManager = null;
            this.last_button_message_time = null;
            this.client_listener = new IntercomObserver.IntercomClientListener();
            this.intercom_listener = new IntercomObserver.IntercomListener();
            this.proxy_listener = new IntercomObserver.ProxyListener();
            this.smarthome_listener = new IntercomObserver.SmartHomeListener();
        }

        public boolean initialize(String client_conf) {
            IntercomManager manager = this.manager.get();
            if (manager == null)
                return false;

            String client_string = manager.nativeCreateIntercom(id, client_conf, intercom_type);
            if (client_string == null) {
                return false;
            }
            this.netClient = new Gson().fromJson(client_string, NetClient.class);
            this.sessionManager = new IntercomSessionManager(this, this.netClient.getClient_id());
            this.smartHomeManager = new SmartHomeManager(this, this.netClient);
            return true;
        }

        public void unInitialize() {
            //先挂断所有会话
            if (sessionManager != null) {
                sessionManager.hangUpAll();
            }
            IntercomManager manager = this.manager.get();
            if (manager != null) {
                manager.nativeDestroyIntercom(id);
            }
            clientManager.cleanup();
            sessionManager = null;
            smartHomeManager = null;
            netClient = null;
        }

        public NetClient getNetClient() {
            return this.netClient;
        }

        public boolean startProxy(String proxy_conf) {
            IntercomManager manager = this.manager.get();
            if (manager == null)
                return false;
            manager.nativeProxyStart(this.id, proxy_conf);
            return true;
        }

        public void stopProxy() {
            IntercomManager manager = this.manager.get();
            if (manager != null)
                manager.nativeProxyStop(this.id);

            clientManager.cleanup();
        }

        public boolean startIntercom(String server_conf) {
            IntercomManager manager = this.manager.get();
            if (manager == null)
                return false;
            manager.nativeIntercomStart(this.id, server_conf);
            return true;
        }

        /**
         * 停止对讲系统
         */
        public void stopIntercom() {
            sessionManager.hangUpAll();
            IntercomManager manager = this.manager.get();
            if (manager != null)
                manager.nativeIntercomStop(this.id);
        }

        /**
         * 终端允许远程配置代理，可以配置的项目有：
         * delay_alert_mobile:(int),当有新的呼叫，代理延迟多久通知云端的移动端，代理在部署之后，默认为10s
         * do_not_alert_mobile_if_pickup:(boolean),当延迟通知移动端之前，如果有终端已经接听，是否继续通知移动端，默认为不通知(true)
         * enable_multi_client:(boolean)，是否支持多终端接听，这里只是为了测试，默认是不允许的
         * disable_indoor_client_unlock:(boolean)，是否禁止室内机（平板和底座）开锁，默认不禁止。使用场景是：如果只是针对某些特定人群独自在家，家长
         * 可以通过手机/平板之类的禁止室内机开门，确保安全性
         * disable_indoor_client_unlock:(boolean)：禁止室内机开锁，代理会检查
         * force_delete_session_if_hangup:(boolean)：只要有人挂断，就挂断整个会话
         * disable_indoor_intercom:(boolean)：禁止室内机门禁功能，禁止之后，外呼会失败，访客呼叫收不到
         * disable_mobile_client_unlock:(boolean)：禁止移动端开锁功能，这个应该只能在平板上设置，移动端不能设置
         * <p>
         * 如果禁止了室内机接听，移动端的延迟通知随之失效，变成立即通知
         * 如果无法连接外网，disable_indoor_intercom会失效
         * <p>
         * 除了unlock/disable_indoor_intercom之外，其他的都可以在代理中预先配置好
         * <p>
         * 这些配置在代理重启之后就会恢复默认值，并不会持久化
         * 上述各项可以单独设置，最后打包成json通过下述方法发送即可
         * <p>
         * 如果to == null，则消息发给代理的IntercomProxy，比如配置代理，见以上内容所述
         * 如果to != null，则消息发给具体的设备，比如修改室外机描述，或者onvif摄像头配置和控制
         */

        public boolean sendIntercomConfigure(int router,
                                             NetClient net_client, //代理
                                             String to,
                                             String session_id,
                                             String configure) {
            IntercomMessage message = new IntercomMessage();
            message.setCmd(IntercomConstants.kIntercomCommandConfigure);
            if (this.netClient != null) {
                message.setFrom(this.netClient.getClient_id());
            }
            message.setClient_id(net_client.getClient_id());
            if (to != null) {
                message.setTo(to);
            }
            if (session_id != null) {
                message.setSession_id(session_id);
            }
            message.setContent(configure);

            Bundle bundle = new Bundle();
            bundle.putString("scheme", IntercomConstants.kIntercomScheme);
            bundle.putInt("router", router);
            boolean result = false;
            try {
                Gson g = new Gson();
                String client_string = g.toJson(net_client);
                String message_string = g.toJson(message);
                bundle.putString("client", client_string);
                bundle.putString("message", message_string);
                result = this.sendIntercomMessage(bundle);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        }

        public boolean sendIntercomMessage(Bundle bundle) {
            IntercomManager manager = this.manager.get();
            if (manager == null)
                return false;
            manager.nativeIntercomMessage(this.id, bundle);
            return true;
        }

        public boolean sendIntercomCommand(Bundle bundle) {
            IntercomManager manager = this.manager.get();
            if (manager == null)
                return false;
            manager.nativeIntercomCommand(this.id, bundle);
            return true;
        }

        public boolean updateSurface(String session_id,
                                     Surface surface) {
            IntercomManager manager = this.manager.get();
            if (manager == null)
                return false;
            manager.nativeUpdateSurface(this.id, session_id, surface);
            return true;
        }

        private void onIntercomMessageEvent(Bundle bundle) {
            String scheme = bundle.getString("scheme");
            if (scheme == null || !bundle.containsKey("event"))
                return;

            int event = bundle.getInt("event");

            if (scheme.equalsIgnoreCase("client")) {
                if (event == 0) {
                    boolean result = bundle.getBoolean("result");
                    client_listener.onIntercomClientInitializeResult(this, result);
                }
            } else if (scheme.equalsIgnoreCase(IntercomConstants.kProxyScheme)) {
                /*
                 * 代理消息解析和分发
                 */
                if (event == IntercomConstants.IntercomProxyEvent.IntercomProxyEventProxyStateChanged) {

                    /*
                     * 代理上下线通知
                     */
                    int router = bundle.getInt("router");
                    boolean online = bundle.getBoolean("online");
                    String client_string = bundle.getString("client");
                    String device_string = bundle.getString("device");

                    IntercomClientManager.IntercomProxy proxy = IntercomClientManager.IntercomProxy.create(router,
                            client_string,
                            device_string);
                    if (proxy != null) {
                        this.clientManager.updateProxy(router, online, proxy);
                        if (this.smartHomeManager != null) {
                            this.smartHomeManager.onProxyStateChanged(router, online, proxy);
                        }
                    }

                } else if (event == IntercomConstants.IntercomProxyEvent.IntercomProxyEventClientStateChanged) {
                    /*
                     * 终端上下线通知
                     */
                    int router = bundle.getInt("router");
                    boolean online = bundle.getBoolean("online");
                    String client_string = bundle.getString("client");
                    String client_id = bundle.getString("client_id");//this is proxy id;
                    this.clientManager.updateClient(router, online, client_id, client_string);

                } else if (event == IntercomConstants.IntercomProxyEvent.IntercomProxyEventInternetProxyStateChanged) {
                    /**
                     * internet状态发生变化
                     */
                    boolean online = bundle.getBoolean("connect");
                    this.clientManager.changeInternetState(online);
                    proxy_listener.onIntercomInternetStateChanged(this, online);

                } else if (event == IntercomConstants.IntercomProxyEvent.IntercomProxyEventProxyDeviceChanged) {
                    int router = bundle.getInt("router");
                    String client_string = bundle.getString("client");
                    String device = bundle.getString("device");
                    NetClient netClient = new Gson().fromJson(client_string, NetClient.class);
                    if (netClient != null) {
                        try {
                            JSONObject json = new JSONObject(device);
                            String id = json.getString("device_id");
                            String configure = json.getString("config");
                            String decode_string = base64(false, configure);
                            IntercomClientManager.IntercomProxy proxy = clientManager.findProxy(netClient.getClient_id());
                            if (proxy != null) {
                                if (proxy.wanOnline()) {
                                    proxy.wanProxy.netDevice.UpdateSubDevice(id, decode_string);
                                }
                                if (proxy.lanOnline()) {
                                    proxy.lanProxy.netDevice.UpdateSubDevice(id, decode_string);
                                }
                            }
                            proxy_listener.onIntercomProxyDeviceChanged(this, netClient.getClient_id(), router, id);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
            } else if (scheme.equalsIgnoreCase(IntercomConstants.kIntercomScheme)) {
                /**
                 * 门禁对讲消息解析和分发
                 */
                if (event == IntercomConstants.IntercomEvent.IntercomEventMessage) {
                    /**
                     * 收到门禁会话消息
                     */
                    int router = bundle.getInt("router");
                    String client_string = bundle.getString("client");
                    String message_string = bundle.getString("message");
                    NetClient netClient = new Gson().fromJson(client_string, NetClient.class);
                    IntercomMessage message = new Gson().fromJson(message_string, IntercomMessage.class);
                    intercom_listener.onIntercomMessageArrival(this, router, netClient, message);


                } else if (event == IntercomConstants.IntercomEvent.IntercomVideoReady) {
                    /**
                     * 会话的视频已经到达，可以创建快照了
                     */
                    String session_id = bundle.getString("session_id");
                    intercom_listener.onIntercomVideoReady(this, session_id);

                } else if (event == IntercomConstants.IntercomEvent.IntercomVideoDimensionChanged) {
                    String session_id = bundle.getString("session_id");
                    int width = bundle.getInt("width");
                    int height = bundle.getInt("height");
                    intercom_listener.onIntercomVideoDimensionChanged(this, session_id, width, height);

                } else if (event == IntercomConstants.IntercomEvent.IntercomSnapshotReady) {

                    String session_id = bundle.getString("session_id");
                    String filename = bundle.getString("filename");
                    intercom_listener.onIntercomSnapshotReady(this, session_id, filename);


                } else if (event == IntercomConstants.IntercomEvent.IntercomSipStateChanged) {

                    String proxy = bundle.getString("proxy");
                    int state = bundle.getInt("state");
                    intercom_listener.onIntercomSipStateChanged(this, proxy, state);


                } else if (event == IntercomConstants.IntercomEvent.IntercomDtmfReady) {

                } else if (event == IntercomConstants.IntercomEvent.IntercomStreamStateChanged) {

                    String session_id = bundle.getString("session_id");
                    int media_type = bundle.getInt("media_type");
                    int state = bundle.getInt("state");
                    intercom_listener.onIntercomStreamStateChanged(this, session_id, media_type, state);


                } else if (event == IntercomConstants.IntercomEvent.IntercomStreamTransportStarted) {

                    String session_id = bundle.getString("session_id");
                    int media_type = bundle.getInt("media_type");
                    intercom_listener.onStreamTransportStart(this, session_id, media_type);


                } else if (event == IntercomConstants.IntercomEvent.IntercomStreamTransportStatistics) {
                    String session_id = bundle.getString("session_id");
                    int media_type = bundle.getInt("media_type");
                    int interval = bundle.getInt("interval");
                    long total_recv = bundle.getLong("total_recv");
                    long total_send = bundle.getLong("total_send");
                    intercom_listener.onIntercomTransportStatistics(this, session_id, media_type, interval, total_recv, total_send);

                } else if (event == IntercomConstants.IntercomEvent.IntercomStreamTransportIceNegotiation) {
                    String session_id = bundle.getString("session_id");
                    int media_type = bundle.getInt("media_type");
                    int result = bundle.getInt("result");
                    intercom_listener.onIntercomTransportIceNegotiationResult(this, session_id, media_type, result);

                }
            } else if (scheme.equalsIgnoreCase(IntercomConstants.kButtonScheme)) {
                /*
                 * 按键消息
                 */
                if (event == IntercomConstants.IntercomProxyEvent.IntercomProxyEventMessage) {
                    int router = bundle.getInt("router");
                    String client_string = bundle.getString("client");
                    String message_string = bundle.getString("message");
                    NetClient netClient = new Gson().fromJson(client_string, NetClient.class);
                    ButtonMessage message = new Gson().fromJson(message_string, ButtonMessage.class);
                    String time = message.getTime();
                    if (time != null && last_button_message_time != null && last_button_message_time.equalsIgnoreCase(time)) {
                        return;
                    }
                    last_button_message_time = time;

                    proxy_listener.onIntercomButtonMessageArrival(this, router, netClient, message);

                }
            } else if (scheme.equalsIgnoreCase(IntercomConstants.kSmarthomeScheme)) {
                /*
                 * 智能家居消息
                 */
                if (event == IntercomConstants.IntercomProxyEvent.IntercomProxyEventMessage) {
                    int router = bundle.getInt("router");
                    String client_string = bundle.getString("client");
                    String message_string = bundle.getString("message");
                    NetClient netClient = new Gson().fromJson(client_string, NetClient.class);
                    SmartHomeMessage message = new Gson().fromJson(message_string, SmartHomeMessage.class);
                    if (netClient != null && message != null && this.smartHomeManager != null) {
                        this.smartHomeManager.onMessageArrival(router, netClient, message);
                    }
                }

            } else {
                /*
                 * 未知消息，可以用来扩展，请注意，scheme:notify在这里处理
                 * 我们不另外添加callback了
                 */
                proxy_listener.onIntercomProxyMessageArrival(this, bundle);
            }
        }
    }

    private native static final void nativeGlobalInitialize(Context context, String app_conf);


    private native final boolean nativeStart(Object weak_this,
                                             String system_id,
                                             String port_conf,
                                             String intercom_conf,
                                             Object[] arrays);

    private native final void nativeStop();

    private native final void nativeRelease();

    private native final void nativeFinalize();

    private native final void nativeUpdatePreviewSurface(Surface surface);

    private native final void nativeEnablePreview(boolean enable);

    private native final void nativeAppCommand(Bundle bundle);

    private native final void nativeAppMessage(Bundle bundle);

    private native final String nativeCreateIntercom(String id,
                                                     String client_conf,
                                                     int type);

    private native final void nativeDestroyIntercom(String id);

    private native final void nativeProxyStart(String id,
                                               String proxy_conf);

    private native final void nativeProxyStop(String id);

    private native final void nativeIntercomStart(String id,
                                                  String server_conf);

    private native final void nativeIntercomStop(String id);

    private native final void nativeIntercomMessage(String id,
                                                    Bundle bundle);

    private native final void nativeIntercomCommand(String id,
                                                    Bundle bundle);

    private native final void nativeUpdateSurface(String id,
                                                  String session_id,
                                                  Surface surface);

    private static final native String nativeGetSDKVersion();

    private static final native String nativeCreateSessionId();

    private static final native String nativeBase64(boolean encode, String content);

    private static final native byte[] nativeEncode(boolean encode, String key, byte[] content);

    private static final native String[] nativeEnumeratorRecord();

    private static final native String nativeEncodeFamilyId(boolean encode, String content);

    private static final native Bundle nativeDecodeProxyMessage(String json);

    static {
        System.loadLibrary("intercom");
    }
}
