package com.intercom.sdk;

import android.os.Bundle;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class SmartHomeManager {
    public final NetClient net_client;
    private List<SecurityDevice> devices;
    private final WeakReference<IntercomManager.Intercom> intercom;


    public SmartHomeManager(IntercomManager.Intercom intercom,
                            NetClient netClient) {
        this.intercom = new WeakReference<>(intercom);
        this.net_client = netClient;
        this.devices = new ArrayList<>();
    }

    public void onProxyStateChanged(int router,
                                    boolean online,
                                    IntercomClientManager.IntercomProxy proxy) {
        if (proxy == null)
            return;

        if (online) {
            IntercomClientManager.IntercomProxyDescription description = proxy.lanOnline() ?
                    proxy.lanProxy : proxy.wanProxy;

            if (description != null && description.netDevice != null
                    && description.netDevice.devices != null) {
                for (IntercomNetDevice.NetDeviceItem item : description.netDevice.devices) {
                    if (!item.defenceDevice())
                        continue;

                    SecurityDevice device = findSecurityDevice(proxy.proxy_id, item.name);
                    if (device != null) {
                        //设备已经存在，我们只是简单更新一下在线状态，然后给上层一个通知
                        device.changeOnlineState(router, true);
                        IntercomManager.Intercom intercom = this.intercom.get();
                        if (intercom != null) {
                            intercom.smarthome_listener.onSmartHomeSecurityDeviceOnlineStateChanged(intercom,
                                    device, router, true);
                        }
                    } else {
                        device = new SecurityDevice(item.name, description.netClient);
                        device.changeOnlineState(router, true);
                        devices.add(device);

                        SmartHomeMessage message =
                                createMessage(device, IntercomConstants.kSmarthomeQuery, false);
                        sendMessage(router, device.net_client, message);
                        IntercomManager.Intercom intercom = this.intercom.get();
                        if (intercom != null) {
                            intercom.smarthome_listener.onSmartHomeSecurityDeviceStateChanged(intercom, device, true);
                        }
                    }
                }
            }
        } else {
            Iterator<SecurityDevice> iter = devices.iterator();
            while (iter.hasNext()) {
                SecurityDevice device = iter.next();
                if (device.net_client.getClient_id().equalsIgnoreCase(proxy.proxy_id)) {
                    device.changeOnlineState(router, false);
                    if (device.offline()) {
                        IntercomManager.Intercom intercom = this.intercom.get();
                        if (intercom != null) {
                            intercom.smarthome_listener.onSmartHomeSecurityDeviceStateChanged(intercom, device, false);
                        }
                        iter.remove();
                    } else {
                        IntercomManager.Intercom intercom = this.intercom.get();
                        if (intercom != null) {
                            intercom.smarthome_listener.onSmartHomeSecurityDeviceOnlineStateChanged(intercom,
                                    device, router, false);
                        }
                    }
                }
            }
        }
    }

    private void onSmartHomeMessage(SecurityDevice device,
                                    SmartHomeMessage message) {
        IntercomManager.Intercom intercom = this.intercom.get();
        if (intercom != null) {
            intercom.smarthome_listener.onSmartHomeMessage(intercom, device, message);
        }
    }

    public void onMessageArrival(int router,
                                 NetClient netClient,
                                 SmartHomeMessage message) {
        SecurityDevice device = findSecurityDevice(message.getProxy_id(), message.getFrom());
        if (device == null)
            return;

        if (device.isRepeatMessage(message))
            return;

        device.updateMessageTime(message);

        if (message.getCmd().equalsIgnoreCase(IntercomConstants.kSmarthomeQuery)) {
            if (message.isAck()) {
                DeviceConfig config = parseContent(message.getContent());
                if (config != null) {
                    device.updateConfig(config);
                    onSmartHomeMessage(device, message);
                } else {
                    deleteDevice(message.getProxy_id(), message.getFrom());
                }
            }
        } else if (message.getCmd().equalsIgnoreCase(IntercomConstants.kSmarthomeButton)) {
            if (device.ready()) {
                /*
                 * button消息只发给相同buttonkey的终端，旧版本未必如此
                 * button 命令没有正文，而且这个消息源来自嵌入式/android(如果代理在Android中)设备按下了安防功能键
                 * 具体如何处理要考虑当前的状态，可能解析为布防／撤防，或者取消警报
                 */
                onSmartHomeMessage(device, message);
            }
        } else if (message.getCmd().equalsIgnoreCase(IntercomConstants.kSmarthomeSwitch)) {
            if (device.ready()) {
                /* 其他终端布防或者撤防 */
                /*"content":{"security_state":1} */
                DeviceConfig config = parseContent(message.getContent());
                if (config != null) {
                    device.updateConfig(config);
                    onSmartHomeMessage(device, message);
                }
            }
        } else if (message.getCmd().equalsIgnoreCase(IntercomConstants.kSmarthomeEmbed)) {
            if (device.ready()) {
                /** 打开或者关闭底座的报警功能*/
                DeviceConfig config = parseContent(message.getContent());
                if (config != null) {
                    device.updateConfig(config);
                    onSmartHomeMessage(device, message);
                }
            }
        } else if (message.getCmd().equalsIgnoreCase(IntercomConstants.kSmarthomeCancel)) {
            if (device.ready()) {
                DeviceConfig config = parseContent(message.getContent());
                if (config != null) {
                    device.enableAlarm(false);
                    onSmartHomeMessage(device, message);
                }
            }
        } else if (message.getCmd().equalsIgnoreCase(IntercomConstants.kSmarthomeState)) {
            if (device.ready()) {
                DeviceConfig config = parseContent(message.getContent());
                if (config != null) {
                    device.updateConfig(config);
                    onSmartHomeMessage(device, message);
                }
            }
        } else if (message.getCmd().equalsIgnoreCase(IntercomConstants.kSmarthomeEvent)) {
            if (device.ready()) {
                String str = IntercomManager.base64(false, message.getContent());
                SecurityMessage securityMessage =
                        new Gson().fromJson(str, SecurityMessage.class);
                if (securityMessage != null) {
                    if (securityMessage.getCmd().equalsIgnoreCase("alert")) {
                        device.enableAlarm(true);
                    }
                    IntercomManager.Intercom intercom = this.intercom.get();
                    if (intercom != null) {
                        intercom.smarthome_listener.onSmartHomeAlarm(intercom, device, message, securityMessage);
                    }
                }
            }
        } else if (message.getCmd().equalsIgnoreCase(IntercomConstants.kSmarthomeMCUClient)) {
            IntercomManager.Intercom intercom = this.intercom.get();
            if (intercom != null) {
                intercom.smarthome_listener.onRemoteMCUMessageArrival(intercom, netClient, message);
            }
        } else {
            onSmartHomeMessage(device, message);
        }
    }

    public List<SecurityDevice> devices() {
        return this.devices;
    }

    public boolean isIdle() {
        for (SecurityDevice device : devices) {
            if (device.alarming())
                return false;
        }
        return true;
    }

    public boolean isDeviceEnable(SecurityDevice device) {
        return device.ready();
    }

    public boolean queryState(SecurityDevice device) {
        if (!device.ready())
            return false;

        SmartHomeMessage message = createMessage(device, IntercomConstants.kSmarthomeQuery, false);
        return sendMessage(device.router(), device.net_client, message);
    }


    public boolean turnOffAlarm(SecurityDevice device) {
        if (!device.ready())
            return false;

        device.enableAlarm(false);

        SmartHomeMessage message = createMessage(device, IntercomConstants.kSmarthomeCancel, false);
        return sendMessage(device.router(), device.net_client, message);
    }

    public boolean switchDefence(SecurityDevice device) {
        if (!device.ready())
            return false;

        device.switchDefence();

        SmartHomeMessage message = createMessage(device, IntercomConstants.kSmarthomeSwitch, false);

        Bundle bundle = new Bundle();
        bundle.putInt("security_state", device.config.security_state);
        String str = IntercomManager.base64(true, BundleToJSON.toString(bundle));
        message.setContent(str);
        return sendMessage(device.router(), device.net_client, message);
    }

    public boolean sendMCUMessage(SecurityDevice device, String content) {
        if (!device.ready())
            return false;
        SmartHomeMessage message = createMessage(device, IntercomConstants.kSmarthomeMCUDevice, false);
        message.setContent(content);
        return sendMessage(device.router(), device.net_client, message);
    }

    private SmartHomeMessage createMessage(SecurityDevice device,
                                           String command,
                                           boolean broadcast) {
        SmartHomeMessage message = new SmartHomeMessage();
        message.setFrom(net_client.getClient_id());
        message.setTo(device.device_name);
        message.setCmd(command);
        message.setSn(net_client.getClient_id());
        message.setProxy_id(device.net_client.getClient_id());
        message.setBroadcast(broadcast);
        message.setSource(SmartHomeMessage.MessageSource.MessageSourceClientPad);
        return message;
    }

    public boolean sendMessage(int router,
                               NetClient netClient,
                               SmartHomeMessage message) {
        Bundle bundle = new Bundle();
        bundle.putString("scheme", IntercomConstants.kSmarthomeScheme);
        bundle.putInt("router", router);
        boolean result = false;
        try {
            Gson g = new Gson();
            String client_string = g.toJson(netClient);
            String message_string = g.toJson(message);
            bundle.putString("client", client_string);
            bundle.putString("message", message_string);
            IntercomManager.Intercom intercom = this.intercom.get();
            if (intercom != null) {
                result = intercom.sendIntercomMessage(bundle);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    private DeviceConfig parseContent(String content) {
        if (content == null)
            return null;

        DeviceConfig config = new DeviceConfig();

        String str = IntercomManager.base64(false, content);

        try {
            JSONObject json = new JSONObject(str);
            if (json.has("disallow_emd")) {
                config.bits |= DeviceConfigFlags.FlagDisableEmbeddedFunction;
                config.disable_embedded_function = json.getBoolean("disallow_emd");
            }
            if (json.has("security_state")) {
                config.bits |= DeviceConfigFlags.FlagSecurityState;
                config.security_state = json.getInt("security_state");
            }
            if (json.has("device_state")) {
                config.bits |= DeviceConfigFlags.FlagDeviceState;
                config.device_state = json.getInt("device_state");
            }
            if (json.has("room")) {
                config.bits |= DeviceConfigFlags.FlagRoom;
                config.room = json.getString("room");
            }
            if (json.has("device_alias")) {
                config.bits |= DeviceConfigFlags.FlagDeviceAlias;
                config.device_alias = json.getString("device_alias");
            }

            if (json.has("device_type")) {
                config.bits |= DeviceConfigFlags.FlagDeviceType;
                config.device_type = json.getString("device_type");
            }
        } catch (JSONException e) {
            e.printStackTrace();
            config = null;
        }
        return config;
    }

    public SecurityDevice findSecurityDevice(String proxy_id, String device_name) {
        for (SecurityDevice device : devices) {
            if (device.net_client == null)
                continue;
            if (device.net_client.getClient_id().equalsIgnoreCase(proxy_id)
                    && device.device_name.equalsIgnoreCase(device_name)) {
                return device;
            }
        }
        return null;
    }

    private void deleteDevice(String proxy_id, String device_name) {
        for (SecurityDevice device : devices) {
            if (device.net_client.getClient_id().equalsIgnoreCase(proxy_id)
                    && device.device_name.equalsIgnoreCase(device_name)) {
                IntercomManager.Intercom intercom = this.intercom.get();
                if (intercom != null) {
                    intercom.smarthome_listener.onSmartHomeSecurityDeviceStateChanged(intercom, device, false);
                }
                devices.remove(device);
                break;
            }
        }
    }

    private static class DeviceOnlineState {
        private static final int SecurityOffline = 0;
        private static final int SecurityLanOnline = 1;
        private static final int SecurityWanOnline = 2;
    }

    private static class DeviceConfigFlags {
        private static final int FlagNone = 0;
        private static final int FlagDisableEmbeddedFunction = 1 << 0;
        private static final int FlagSecurityState = 1 << 1;
        private static final int FlagDeviceState = 1 << 2;
        private static final int FlagRoom = 1 << 3;
        private static final int FlagDeviceAlias = 1 << 4;
        private static final int FlagDeviceType = 1 << 5;
    }

    public static class DeviceConfig {
        //是否支持嵌入式设备安防功能
        public boolean disable_embedded_function;
        //布防:1，撤防:0
        public int security_state;
        //安防设备连接状态,1:online, 0:offline
        public int device_state;
        //设备所在的房间号
        public String room;
        //设备别名集合: 烟雾探测器;红外报警器;...
        public String device_alias;
        //设备具体类型编码集合: 1;2;3;...
        public String device_type;

        private int bits;

        private DeviceConfig() {
            this.disable_embedded_function = false;
            this.security_state = 0;
            this.device_state = 0;
            this.device_alias = null;
            this.device_type = null;
            this.room = null;
            this.bits = DeviceConfigFlags.FlagNone;
        }

        private void update(DeviceConfig config) {
            if ((config.bits & DeviceConfigFlags.FlagDisableEmbeddedFunction) > 0) {
                this.disable_embedded_function = config.disable_embedded_function;
            }
            if ((config.bits & DeviceConfigFlags.FlagSecurityState) > 0) {
                this.security_state = config.security_state;
            }
            if ((config.bits & DeviceConfigFlags.FlagDeviceState) > 0) {
                this.device_state = config.device_state;
            }
            if ((config.bits & DeviceConfigFlags.FlagRoom) > 0) {
                this.room = config.room;
            }
            if ((config.bits & DeviceConfigFlags.FlagDeviceAlias) > 0) {
                this.device_alias = config.device_alias;
            }
            if ((config.bits & DeviceConfigFlags.FlagDeviceType) > 0) {
                this.device_type = config.device_type;
            }
            this.bits |= config.bits;
        }

        private void switchDefence() {
            this.security_state = this.security_state > 0 ? 0 : 1;
        }
    }


    public static class SecurityDevice {
        private int online_state;
        private boolean alarm;
        private String last_message_time;
        private boolean ready;

        private final NetClient net_client;
        private DeviceConfig config;

        public final String device_name;

        private SecurityDevice(String device_name,
                               NetClient netClient) {
            this.online_state = DeviceOnlineState.SecurityOffline;
            this.alarm = false;
            this.last_message_time = null;
            this.ready = false;

            this.device_name = device_name;
            this.net_client = netClient;
            this.config = null;
        }

        public NetClient netClient() {
            return this.net_client;
        }

        public DeviceConfig deviceConfig() {
            return this.config;
        }

        public boolean ready() {
            return this.ready;
        }

        public boolean alarming() {
            return this.alarm;
        }

        public boolean isDefenceEnable() {
            if (!ready)
                return false;
            return config.security_state > 0;
        }

        public int router() {
            return (online_state & DeviceOnlineState.SecurityLanOnline) > 0 ?
                    IntercomConstants.Router.LAN : IntercomConstants.Router.PROXY;
        }

        private boolean offline() {
            return this.online_state == DeviceOnlineState.SecurityOffline;
        }

        public void switchDefence() {
            if (!ready)
                return;
            config.switchDefence();
        }

        private void changeOnlineState(int router, boolean online) {
            if (router == IntercomConstants.Router.LAN) {
                if (online)
                    this.online_state |= DeviceOnlineState.SecurityLanOnline;
                else
                    this.online_state &= (~DeviceOnlineState.SecurityLanOnline);
            } else if (router == IntercomConstants.Router.PROXY) {
                if (online)
                    this.online_state |= DeviceOnlineState.SecurityWanOnline;
                else
                    this.online_state &= (~DeviceOnlineState.SecurityWanOnline);
            }
        }

        private boolean isRepeatMessage(SmartHomeMessage message) {
            if (last_message_time == null || message.getTime() == null)
                return false;
            return last_message_time.equalsIgnoreCase(message.getTime());
        }

        private void updateMessageTime(SmartHomeMessage message) {
            last_message_time = message.getTime();
        }

        public void enableAlarm(boolean enable) {
            this.alarm = enable;
        }

        private void updateConfig(DeviceConfig config) {
            if (this.config != null) {
                this.config.update(config);
            } else {
                this.config = config;
                this.ready = true;
            }
        }
    }
}
