package com.intercom.sdk;

import android.os.Bundle;

import java.util.WeakHashMap;

public class IntercomObserver {

    public interface OnAppListener {

        /**
         * App 模块异步初始化callback，在这个callback之后
         * 继续初始化Intercom
         *
         * @param result:成功/失败，失败一般由不正确的参数引起的
         */
        void onIntercomAppIntialized(boolean result);

        //errcode : DeviceActiveResult
        void onIntercomAppActivated(int errcode, String type, String message);

        /**
         * 底层对于媒体资源的使用情况
         *
         * @param media_type:TransportMediaType:TransportMediaTypeAudio/TransportMediaTypeVideo
         * @param state:StreamState:StreamStateStart/StreamStateStop
         */
        void onIntercomMediaDeviceStateChanged(int media_type,
                                               int state);

        /**
         * 摄像头启动失败
         *
         * @param err:错误代码    ANDROID_API_1_CAMERA_ERROR_CALLBACK_RECEIVED = 68,
         *                    ANDROID_API_2_CAMERA_DEVICE_ERROR_RECEIVED = 69,
         *                    ANDROID_API_2_CAPTURE_SESSION_CONFIGURE_FAILED = 70,
         *                    ANDROID_API_2_IMAGE_READER_UNEXPECTED_IMAGE_FORMAT = 71,
         *                    ANDROID_API_2_IMAGE_READER_SIZE_DID_NOT_MATCH_IMAGE_SIZE = 72,
         *                    ANDROID_API_2_ERROR_RESTARTING_PREVIEW = 73,
         *                    ANDROID_API_2_ERROR_CONFIGURING_CAMERA = 114,
         * @param from:错误来源
         * @param reason:错误描述
         */
        void onCameraError(int err, String from, String reason);

        /**
         * 摄像头状态变化，0:停止，1：启动
         * 这个callback不等同： onIntercomMediaDeviceStateChanged,表示视频编码开始和结束
         * 摄像头和音频是共享资源，既可以用于预览也可以用于编码
         * 这里表示摄像头有没有启动
         *
         * @param state
         */
        void onCameraStateChanged(int state);
    }

    /**
     * 初始化门禁实例的callback，可能有多个家庭，会有多个实例
     */
    public interface OnIntercomClientListener {
        void onIntercomClientInitializeResult(IntercomManager.Intercom intercom, boolean result);
    }

    /**
     * 门禁实例的代理callback
     */
    public interface OnProxyListener {
        void onIntercomProxyStateChanged(IntercomManager.Intercom intercom,
                                         String proxy_id,
                                         boolean online);

        void onIntercomProxyOnlineStateChanged(IntercomManager.Intercom intercom,
                                               String proxy_id,
                                               int router,
                                               boolean online);

        void onIntercomClientStateChanged(IntercomManager.Intercom intercom,
                                          String client_id,
                                          boolean online);

        void onIntercomClientOnlineStateChanged(IntercomManager.Intercom intercom,
                                                String client_id,
                                                String proxy_id,
                                                int router,
                                                boolean online);

        void onIntercomInternetStateChanged(IntercomManager.Intercom intercom,
                                            boolean online);

        void onIntercomProxyDeviceChanged(IntercomManager.Intercom intercom,
                                          String proxy_id,
                                          int router,
                                          String device_id);

        /**
         * 收到远端的按键消息
         *
         * @param router
         * @param netClient
         * @param message
         */
        void onIntercomButtonMessageArrival(IntercomManager.Intercom intercom,
                                            int router,
                                            NetClient netClient,
                                            ButtonMessage message);

        /**
         * 其他未知消息
         *
         * @param bundle
         */
        void onIntercomProxyMessageArrival(IntercomManager.Intercom intercom,
                                           Bundle bundle);
    }

    /**
     * 门禁会话的callback，关联到某个家庭
     */
    public interface OnIntercomListener {
        /**
         * 收到门禁消息，具体需要解析IntercomMessage
         *
         * @param router
         * @param netClient
         * @param message
         */
        void onIntercomMessageArrival(IntercomManager.Intercom intercom,
                                      int router,
                                      NetClient netClient,
                                      IntercomMessage message);

        /**
         * 某路会话的对方视频的第一个关键帧已经收到，接下来就可以创建快照了
         * takeSnapshot
         *
         * @param session_id
         */
        void onIntercomVideoReady(IntercomManager.Intercom intercom,
                                  String session_id);

        void onIntercomVideoDimensionChanged(IntercomManager.Intercom intercom,
                                             String session_id,
                                             int width,
                                             int height);

        /**
         * 某路会话的快照创建成功，保存到filename指定的文件中(JPEG)格式
         *
         * @param session_id
         * @param filename
         */
        void onIntercomSnapshotReady(IntercomManager.Intercom intercom,
                                     String session_id,
                                     String filename);

        /**
         * 本机sip登陆状态变化
         * public static class SipRegistrationState {
         * public static final int SipRegistrationNone = 0;
         * public static final int SipRegistrationProgress = 1;
         * public static final int SipRegistrationOk = 2;
         * public static final int SipRegistrationCleared = 3;
         * public static final int SipRegistrationFailed = 4;
         * }
         *
         * @param proxy
         * @param state
         */
        void onIntercomSipStateChanged(IntercomManager.Intercom intercom,
                                       String proxy,
                                       int state);

        /**
         * 某个会话媒体流发生变化
         *
         * @param session_id
         * @param media_type
         * @param state
         */
        void onIntercomStreamStateChanged(IntercomManager.Intercom intercom,
                                          String session_id,
                                          int media_type,
                                          int state);

        /**
         * 某个会话的传输层发生变化
         *
         * @param session_id
         * @param media_type
         */
        void onStreamTransportStart(IntercomManager.Intercom intercom,
                                    String session_id,
                                    int media_type);

        void onIntercomTransportStatistics(IntercomManager.Intercom intercom,
                                           String session_id,
                                           int media_type,
                                           int interval,
                                           long recv_bytes,
                                           long send_bytes);

        void onIntercomTransportIceNegotiationResult(IntercomManager.Intercom intercom,
                                                     String session_id,
                                                     int media_type,
                                                     int result);
    }

    /**
     * 智能家居的callback，关联到某个家庭
     */
    public interface OnSmartHomeListener {
        void onSmartHomeSecurityDeviceStateChanged(IntercomManager.Intercom intercom,
                                                   SmartHomeManager.SecurityDevice device,
                                                   boolean online);

        void onSmartHomeSecurityDeviceOnlineStateChanged(IntercomManager.Intercom intercom,
                                                         SmartHomeManager.SecurityDevice device,
                                                         int router,
                                                         boolean online);

        void onSmartHomeMessage(IntercomManager.Intercom intercom,
                                SmartHomeManager.SecurityDevice device,
                                SmartHomeMessage message);

        void onSmartHomeAlarm(IntercomManager.Intercom intercom,
                              SmartHomeManager.SecurityDevice device,
                              SmartHomeMessage smartHomeMessage,
                              SecurityMessage securityMessage);

        void onRemoteMCUMessageArrival(IntercomManager.Intercom intercom,
                                       NetClient netClient,
                                       SmartHomeMessage smartHomeMessage);
    }

    public static class IntercomAppListener extends EventListener<OnAppListener> {

        public void onIntercomAppIntialized(boolean result) {
            for (OnAppListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onIntercomAppIntialized(result);
                }
            }
        }

        public void onIntercomAppActivated(int errcode, String type, String message) {
            for (OnAppListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onIntercomAppActivated(errcode, type, message);
                }
            }
        }

        public void onIntercomMediaDeviceStateChanged(int media_type,
                                                      int state) {
            for (OnAppListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onIntercomMediaDeviceStateChanged(media_type, state);
                }
            }
        }

        public void onCameraError(int err, String from, String reason) {
            for (OnAppListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onCameraError(err, from, reason);
                }
            }
        }

        public void onCameraStateChanged(int state) {
            for (OnAppListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onCameraStateChanged(state);
                }
            }
        }
    }

    public static class IntercomClientListener extends EventListener<OnIntercomClientListener> {
        public void onIntercomClientInitializeResult(IntercomManager.Intercom intercom, boolean result) {
            for (OnIntercomClientListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onIntercomClientInitializeResult(intercom, result);
                }
            }
        }
    }

    public static class ProxyListener extends EventListener<OnProxyListener> {

        public void onIntercomProxyStateChanged(IntercomManager.Intercom intercom, String proxy_id, boolean online) {
            for (OnProxyListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onIntercomProxyStateChanged(intercom, proxy_id, online);
                }
            }
        }

        public void onIntercomProxyOnlineStateChanged(IntercomManager.Intercom intercom, String proxy_id, int router, boolean online) {
            for (OnProxyListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onIntercomProxyOnlineStateChanged(intercom, proxy_id, router, online);
                }
            }
        }

        public void onIntercomClientStateChanged(IntercomManager.Intercom intercom, String client_id, boolean online) {
            for (OnProxyListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onIntercomClientStateChanged(intercom, client_id, online);
                }
            }
        }

        public void onIntercomClientOnlineStateChanged(IntercomManager.Intercom intercom, String client_id, String proxy_id, int router, boolean online) {
            for (OnProxyListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onIntercomClientOnlineStateChanged(intercom, client_id, proxy_id, router, online);
                }
            }
        }

        public void onIntercomInternetStateChanged(IntercomManager.Intercom intercom, boolean online) {
            for (OnProxyListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onIntercomInternetStateChanged(intercom, online);
                }
            }
        }

        public void onIntercomProxyDeviceChanged(IntercomManager.Intercom intercom,
                                                 String proxy_id,
                                                 int router,
                                                 String device_id) {
            for (OnProxyListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onIntercomProxyDeviceChanged(intercom, proxy_id, router, device_id);
                }
            }
        }

        public void onIntercomButtonMessageArrival(IntercomManager.Intercom intercom, int router, NetClient netClient, ButtonMessage message) {
            for (OnProxyListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onIntercomButtonMessageArrival(intercom, router, netClient, message);
                }
            }
        }

        public void onIntercomProxyMessageArrival(IntercomManager.Intercom intercom, Bundle bundle) {
            for (OnProxyListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onIntercomProxyMessageArrival(intercom, bundle);
                }
            }
        }
    }

    public static class IntercomListener extends EventListener<OnIntercomListener> {
        public void onIntercomMessageArrival(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message) {
            for (OnIntercomListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onIntercomMessageArrival(intercom, router, netClient, message);
                }
            }
        }

        public void onIntercomVideoReady(IntercomManager.Intercom intercom, String session_id) {
            for (OnIntercomListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onIntercomVideoReady(intercom, session_id);
                }
            }
        }

        public void onIntercomVideoDimensionChanged(IntercomManager.Intercom intercom,
                                                    String session_id,
                                                    int width,
                                                    int height) {
            for (OnIntercomListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onIntercomVideoDimensionChanged(intercom, session_id, width, height);
                }
            }
        }

        public void onIntercomSnapshotReady(IntercomManager.Intercom intercom, String session_id, String filename) {
            for (OnIntercomListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onIntercomSnapshotReady(intercom, session_id, filename);
                }
            }
        }

        public void onIntercomSipStateChanged(IntercomManager.Intercom intercom, String proxy, int state) {
            for (OnIntercomListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onIntercomSipStateChanged(intercom, proxy, state);
                }
            }
        }

        public void onIntercomStreamStateChanged(IntercomManager.Intercom intercom, String session_id, int media_type, int state) {
            for (OnIntercomListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onIntercomStreamStateChanged(intercom, session_id, media_type, state);
                }
            }
        }

        public void onStreamTransportStart(IntercomManager.Intercom intercom, String session_id,
                                           int media_type) {
            for (OnIntercomListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onStreamTransportStart(intercom, session_id, media_type);
                }
            }
        }

        public void onIntercomTransportStatistics(IntercomManager.Intercom intercom, String session_id,
                                                  int media_type,
                                                  int interval,
                                                  long recv_bytes,
                                                  long send_bytes) {
            for (OnIntercomListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onIntercomTransportStatistics(intercom, session_id, media_type, interval, recv_bytes, send_bytes);
                }
            }
        }

        public void onIntercomTransportIceNegotiationResult(IntercomManager.Intercom intercom,
                                                            String session_id,
                                                            int media_type,
                                                            int result) {
            for (OnIntercomListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onIntercomTransportIceNegotiationResult(intercom, session_id, media_type, result);
                }
            }
        }
    }

    public static class SmartHomeListener extends EventListener<OnSmartHomeListener> {

        /**
         * 安防设备上下线，注意，上线的时候，设备还没拿到详细的配置
         * 在收到query命令的时候才会收到
         *
         * @param device
         * @param online
         */
        public void onSmartHomeSecurityDeviceStateChanged(IntercomManager.Intercom intercom, SmartHomeManager.SecurityDevice device,
                                                          boolean online) {
            for (OnSmartHomeListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onSmartHomeSecurityDeviceStateChanged(intercom, device, online);
                }
            }
        }

        public void onSmartHomeSecurityDeviceOnlineStateChanged(IntercomManager.Intercom intercom, SmartHomeManager.SecurityDevice device,
                                                                int router,
                                                                boolean online) {
            for (OnSmartHomeListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onSmartHomeSecurityDeviceOnlineStateChanged(intercom, device, router, online);
                }
            }
        }

        public void onSmartHomeMessage(IntercomManager.Intercom intercom, SmartHomeManager.SecurityDevice device,
                                       SmartHomeMessage message) {
            for (OnSmartHomeListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onSmartHomeMessage(intercom, device, message);
                }
            }
        }

        public void onSmartHomeAlarm(IntercomManager.Intercom intercom,
                                     SmartHomeManager.SecurityDevice device,
                                     SmartHomeMessage smartHomeMessage,
                                     SecurityMessage securityMessage) {
            for (OnSmartHomeListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onSmartHomeAlarm(intercom, device, smartHomeMessage, securityMessage);
                }
            }
        }

        public void onRemoteMCUMessageArrival(IntercomManager.Intercom intercom,
                                              NetClient netClient,
                                              SmartHomeMessage smartHomeMessage) {
            for (OnSmartHomeListener listener : listeners.keySet()) {
                if (listener != null) {
                    listener.onRemoteMCUMessageArrival(intercom, netClient, smartHomeMessage);
                }
            }
        }
    }
}
