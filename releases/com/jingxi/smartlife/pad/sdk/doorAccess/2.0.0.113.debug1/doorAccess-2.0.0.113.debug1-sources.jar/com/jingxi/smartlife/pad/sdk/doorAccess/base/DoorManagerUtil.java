package com.jingxi.smartlife.pad.sdk.doorAccess.base;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.SurfaceView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.intercom.sdk.BundleToJSON;
import com.intercom.sdk.IntercomClientManager;
import com.intercom.sdk.IntercomConstants;
import com.intercom.sdk.IntercomManager;
import com.intercom.sdk.IntercomMessage;
import com.intercom.sdk.IntercomNetDevice;
import com.intercom.sdk.JINIParser;
import com.intercom.sdk.NetClient;
import com.intercom.sdk.RecordPlayer;
import com.intercom.sdk.SmartHomeManager;
import com.intercom.sdk.SmartHomeMessage;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.CallOutBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorDevice;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorEvent;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorRecordBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.ExtDeviceBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.RecordVideoBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.orm.DoorAccessOrmUtil;
import com.jingxi.smartlife.pad.sdk.utils.JXLogUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author bjj
 * 门禁3.0 控制封装
 */
public class DoorManagerUtil {

    /**
     * 门禁查看监控
     */
    public static String monitor(String familyDockSn, DoorDevice subDevice,boolean needSaveRecord, String msgContent){
        String sessionId = "";
        CallOutBean callOutBean = DoorMessageFactory.buildMonitorCallOutBean(familyDockSn,subDevice);
        if(callOutBean == null){
            return sessionId;
        }
        sessionId = callOutBean.message.getSession_id();
        if (!TextUtils.isEmpty(msgContent)) {
            callOutBean.message.setContent(IntercomManager.base64(true, msgContent));
        }
        IntercomManager.Intercom intercom = callout(familyDockSn,callOutBean);

        DoorRecordBean recordBean = DoorRecordBean.parseDoorRecord(
                familyDockSn,
                IntercomConstants.kIntercomScheme,
                callOutBean.message.getFrom(),
                callOutBean.message.getUsername(),
                callOutBean.message.getSession_id(),
                DoorRecordBean.CALL_EVENT_CALLOUT);

        if(needSaveRecord){
            DoorAccessOrmUtil.saveRecord(recordBean);
        }

        DoorEvent event = new DoorEvent();
        event.intercom = intercom;
        event.sessionId = sessionId;
        event.message = callOutBean.message;
        event.router = callOutBean.router;

        DoorSessionManager.monitor(subDevice,event,sessionId,recordBean);

        return sessionId;
    }

    /**
     * 室内通消息外呼
     * @param extDeviceBean     室内通对象
     * @param isMonitor         是否是监控模式
     * @return sessionID
     */
    public static String callExtOut(String familyDockSn, ExtDeviceBean extDeviceBean, boolean isMonitor,boolean needSaveRecord){
        CallOutBean callOutBean = DoorMessageFactory.buildExtCallOutBean(familyDockSn,extDeviceBean,isMonitor);
        if(callOutBean == null){
            return "";
        }

        IntercomManager.Intercom intercom = callout(familyDockSn,callOutBean);

        int chatEvent = isMonitor ? DoorRecordBean.CALL_EVENT_EXT_MONITOR : DoorRecordBean.CALL_EVENT_CALLOUT;

        String sessionId = callOutBean.message.getSession_id();

        DoorRecordBean recordBean = DoorRecordBean.parseExtRecord(
                familyDockSn,
                sessionId,
                extDeviceBean.clientBean.getButton_key(),
                extDeviceBean.clientBean.getSub_type(),
                chatEvent);

        if(needSaveRecord){
            DoorAccessOrmUtil.saveRecord(recordBean);
        }

        DoorEvent event = new DoorEvent();
        event.intercom = intercom;
        event.sessionId = sessionId;
        event.message = callOutBean.message;
        event.router = callOutBean.router;

        DoorSessionManager.monitorExt(event,sessionId,recordBean);

        return sessionId;
    }

    /**
     * 户户通消息外呼
     * @param number            communityid+户户通呼出的房号
     * @return sessionID
     */
    public static String callP2POut(String familyDockSn, String number,boolean needSaveRecord){
        CallOutBean callOutBean = DoorMessageFactory.buildP2PCalloutBean(familyDockSn,number);
        if(callOutBean == null){
            return "";
        }
        IntercomManager.Intercom intercom = callout(familyDockSn,callOutBean);
        String sessionId = callOutBean.message.getSession_id();

        DoorRecordBean recordBean = DoorRecordBean.parseP2PRecord(
                familyDockSn,
                IntercomConstants.kIntercomScheme,
                callOutBean.message.getFrom(),
                callOutBean.message.getUsername(),
                sessionId,
                DoorRecordBean.CALL_EVENT_CALLOUT);
        if(needSaveRecord){
            DoorAccessOrmUtil.saveRecord(recordBean);
        }

        DoorEvent event = new DoorEvent();
        event.intercom = intercom;
        event.sessionId = sessionId;
        event.message = callOutBean.message;
        event.router = callOutBean.router;

        DoorSessionManager.monitorP2P(event,sessionId,recordBean);
        return callOutBean.message.getSession_id();
    }

    /**
     * 呼叫指定设备
     */
    private static IntercomManager.Intercom callout(String familyDockSn, CallOutBean callOutBean){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyDockSn);
        if(intercom == null){
            return null;
        }
        intercom.sessionManager.callout(callOutBean.router,callOutBean.netClient,callOutBean.message);
        return intercom;
    }

    /**
     * 接收通话,一般在 onInvite 中调用
     */
    public static void accept(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message){
        if(intercom != null){
            intercom.sessionManager.accept(router,netClient,message);
        }
    }

    public static void decline(IntercomManager.Intercom intercom, int router, NetClient netClient,
                               IntercomMessage message, int result){
        if (intercom != null) {
            intercom.sessionManager.decline(router, netClient, message, result);
        }
    }

    /**
     * 接听通话
     */
    public static void pickUp(IntercomManager.Intercom intercom, String sessionId){
        if(intercom != null){
            intercom.sessionManager.pickUp(sessionId);
            DoorSessionManager.pickUp(sessionId);
        }
    }

    /**
     * 挂断通话
     */
    public static void hangUp(IntercomManager.Intercom intercom, String sessionId, int messageResult){
        if(intercom != null){
            intercom.sessionManager.hangUp(sessionId, messageResult);
            updateRemoteSurface(intercom,sessionId,null);
        }
        DoorSessionManager.hangup(sessionId);
        DoorAccessOrmUtil.updateChatHangup(sessionId,true);
    }

    /**
     * 挂断通话
     */
    public static void truthHangUp(IntercomManager.Intercom intercom, String sessionId, int messageResult){
        if(intercom != null){
            intercom.sessionManager.truthHangUp(sessionId, messageResult);
            updateRemoteSurface(intercom,sessionId,null);
        }
        DoorSessionManager.hangup(sessionId);
        DoorAccessOrmUtil.updateChatHangup(sessionId,true);
    }

    /**
     * 开锁
     */
    public static void openDoor(IntercomManager.Intercom intercom, String sessionId){
        if(intercom == null){
            return;
        }
        if(unlockDTMF(intercom,sessionId)){
            return;
        }
        intercom.sessionManager.unlock(sessionId);
    }

    public static void openDoor(String familyId,String deviceName){
        if(TextUtils.isEmpty(familyId)){
            JXLogUtil.logW("openDoor with empty familyId,so return");
            return;
        }
        if(TextUtils.isEmpty(deviceName)){
            JXLogUtil.logW("openDoor with empty deviceName,so return");
            return;
        }

        Object[] deviceDatas = DoorDeviceManager.getProxyByDevice(familyId,deviceName);
        if(deviceDatas == null){
            return;
        }
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyId);
        if(intercom == null){
            JXLogUtil.logW("openDoor but intercom is null,so return");
            return;
        }
        intercom.sessionManager.unlock(
                (int)deviceDatas[0],
                (NetClient) deviceDatas[1],
                null,
                deviceName,
                ((IntercomNetDevice.NetDeviceItem)deviceDatas[2]).name);
    }

    private static boolean unlockDTMF(IntercomManager.Intercom intercom, String sessionId){
        DoorDevice doorDevice = DoorSessionManager.getCurrentDevice(sessionId);
        if(doorDevice == null){
            return false;
        }
        int router = DoorSessionManager.getCurrentRouter(sessionId);
        String name = DoorDeviceManager.getNetDeviceName(intercom,doorDevice.getProxy_id(),doorDevice.name,router);
        if(TextUtils.isEmpty(name)){
            return false;
        }
        String config = intercom.clientManager.findDeviceConfigure(doorDevice.getProxy_id(),name,"dtmf");
        if(TextUtils.isEmpty(config)){
            return false;
        }
        return intercom.sessionManager.sendDTMF(sessionId,config);
    }

    /**
     * 播放指定session 的历史记录
     * @param hisSessionId          需要回放的历史记录session
     * @param decoder_engine 移动端：0，平板端室内机和室外机都是1
     */
    public static void startPlayBack(RecordPlayer.RecordPlayerHandler onPlaybackListener,String hisSessionId, String videoPath, int decoder_engine){
        File file = new File(videoPath);
        if(!file.exists()){
            return;
        }
        String mediaDir = DoorKit.getOptions().doorAccessWorkDir + "record";
        /**
         * 传入的视频文件是绝对路径，则不需要传递 media_dir
         */
        RecordPlayer.getInstance(onPlaybackListener)
                .start(decoder_engine,mediaDir,hisSessionId,videoPath);
        DoorSessionManager.addPlayBack(hisSessionId);
    }

    public static void switchPlaybackAudio(RecordPlayer.RecordPlayerHandler onPlaybackListener,boolean isEnabled){
        RecordPlayer.getInstance(onPlaybackListener)
                .switchAudio(isEnabled);
    }

    public static void enablePlaybackAudioTrack(RecordPlayer.RecordPlayerHandler onPlaybackListener,boolean isLocal,boolean isEnable){
        RecordPlayer.getInstance(onPlaybackListener)
                .enableAudioTracker(isLocal,isEnable);
    }

    /**
     * 播放指定session 的历史记录
     * @param hisSessionId          需要回放的历史记录session
     */
    public static void stopPlayBack(String hisSessionId){
        RecordPlayer.getInstance(null)
                .stop();
        RecordPlayer.getInstance(null)
                .release();
        DoorSessionManager.hangup(hisSessionId);
    }

    /**
     * 播放指定session 的历史记录
     * @param hisSessionId          需要回放的历史记录session
     */
    public static void seekPlayBack(String hisSessionId,int seek){
        RecordPlayer.getInstance(null)
                .seek(seek);
    }

    public static void removePlayBackListener(RecordPlayer.RecordPlayerHandler handler){
        RecordPlayer.getInstance(null)
                .removeHandler(handler);
    }

    /**
     * 启用/禁用 本地视频
     * @param sessionId         当前的会话id
     * @param isEnabled         启用/禁用
     */
    public static void enableLocalVideo(String familyDockSn, String sessionId, boolean isEnabled){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyDockSn);
        if(intercom != null){
            intercom.sessionManager.enableVideo(sessionId,isEnabled);
        }
    }

    /**
     * 启用/禁用 麦克风
     * @param sessionId         当前的会话id
     * @param isEnabled         启用/禁用
     */
    public static void enableLocalMic(String familyDockSn, String sessionId, boolean isEnabled){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyDockSn);
        if(intercom != null){
            intercom.sessionManager.enableAudio(sessionId,false,isEnabled);
        }
    }

    /**
     * 启用/禁用 本地声音
     * @param sessionId         当前的会话id
     * @param isEnabled         启用/禁用
     */
    public static void enableLocalPlayer(String familyDockSn, String sessionId, boolean isEnabled){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyDockSn);
        if(intercom != null){
            intercom.sessionManager.enableAudio(sessionId,true,isEnabled);
        }
    }

    /**
     * 更新播放历史记录的Surface
     * @param hisSessionId      回放历史记录的session
     */
    public static void updatePlayBackSurface(String hisSessionId, SurfaceView surfaceView){
        RecordPlayer.getInstance(null)
                .updateSurface(surfaceView == null ? null : surfaceView.getHolder().getSurface());
    }

    /**
     * 通话时更新本地Surface
     */
    public static void updateLocalSurface(SurfaceView surfaceView){
        IntercomManager.getInstance().updatePreviewSurface(surfaceView == null ? null : surfaceView.getHolder().getSurface());
    }

    /**
     * 通话时更新对方 Surface
     */
    public static void updateRemoteSurface(IntercomManager.Intercom intercom, String sessionId, SurfaceView surfaceView){
        if(intercom == null){
            return;
        }
        JXLogUtil.logW("updateRemoteSurface session = " + sessionId + " surfaceView = " + surfaceView);
        intercom.updateSurface(sessionId,surfaceView == null ? null : surfaceView.getHolder().getSurface());
    }

    /**
     * 监听到网络变化后重启所有Intercom 的 proxy
     */
    public static void reStartAllProxy(){
        Collection<IntercomManager.Intercom> intercoms = IntercomManager.getInstance().getAllIntercom();
        List<IntercomManager.Intercom> tempList = new ArrayList<>(intercoms);
        for(IntercomManager.Intercom intercom : tempList){
            intercom.stopProxy();
            intercom.startProxy(DoorConfigs.getProxyConfig());
        }
    }

    /**
     * 停止所有Intercom 的 proxy
     */
    public static void stopAllProxy(){
        Collection<IntercomManager.Intercom> intercoms = IntercomManager.getInstance().getAllIntercom();
        List<IntercomManager.Intercom> tempList = new ArrayList<>(intercoms);
        for(IntercomManager.Intercom intercom : tempList){
            intercom.stopProxy();
        }
    }

    public static void takeSnapshot(String familyId, String sessionId){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyId);
        if(intercom != null){
            intercom.sessionManager.takeSnapshot(sessionId);
        }
    }

    public static void enablePreview(boolean enable){
        IntercomManager.getInstance().enablePreview(enable);
    }

    /**
     * 是否支持修改设备名
     * @param familyId
     * @param subDevice
     * @return
     */
    public static boolean isSupportChangeDeviceName(String familyId,DoorDevice subDevice){
        return TextUtils.equals(subDevice.getCalledName(),"auto")
                || TextUtils.equals(subDevice.getCalledName(),"ipc");
    }

    /**
     * 更改设备名
     * @param familyId
     * @param subDevice
     * @param jsonString 要发出去的配置
     * @param sessionId
     * @return
     */
    public static boolean sendConfigure(String familyId, IntercomNetDevice.SubDevice subDevice, String jsonString, String sessionId){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyId);
        if(intercom == null){
            return false;
        }

        IntercomClientManager.IntercomProxy proxy = intercom.clientManager.findProxy(subDevice.getProxy_id());
        if(proxy == null){
            return false;
        }

        IntercomClientManager.IntercomProxyDescription proxyDescription = proxy.lanOnline() ? proxy.lanProxy : proxy.wanProxy;
        if(proxyDescription == null || proxyDescription.netDevice == null
                || proxyDescription.netDevice.devices == null || proxyDescription.netDevice.devices.isEmpty()){
            return false;
        }

        IntercomNetDevice.NetDeviceItem deviceItem = null;
        for(IntercomNetDevice.NetDeviceItem item : proxyDescription.netDevice.devices){
            if(item.subDevices.contains(subDevice)){
                deviceItem = item;
                break;
            }
        }

        if(deviceItem == null){
            return false;
        }

        NetClient netClient = null;
        int router = 0;
        if(proxy.lanOnline()){
            router = IntercomConstants.Router.LAN;
            netClient = proxy.lanProxy.netClient;
        }
        else {
            router = IntercomConstants.Router.PROXY;
            netClient = proxy.wanProxy.netClient;
        }

        return intercom.sendIntercomConfigure(router,netClient,deviceItem.name,sessionId,jsonString);
    }

    /**
     * 更改设备名
     * @param familyId
     * @param subDevice
     * @param newName
     * @return
     */
    public static boolean changeDeviceName(String familyId,IntercomNetDevice.SubDevice subDevice,String newName){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyId);
        if(intercom == null){
            return false;
        }

        IntercomClientManager.IntercomProxy proxy = intercom.clientManager.findProxy(subDevice.getProxy_id());
        if(proxy == null){
            return false;
        }

        IntercomClientManager.IntercomProxyDescription proxyDescription = proxy.lanOnline() ? proxy.lanProxy : proxy.wanProxy;
        if(proxyDescription == null || proxyDescription.netDevice == null
                || proxyDescription.netDevice.devices == null || proxyDescription.netDevice.devices.isEmpty()){
            return false;
        }

        IntercomNetDevice.NetDeviceItem deviceItem = null;
        for(IntercomNetDevice.NetDeviceItem item : proxyDescription.netDevice.devices){
            if(item.subDevices.contains(subDevice)){
                deviceItem = item;
                break;
            }
        }

        if(deviceItem == null){
            return false;
        }

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("cmd","alias");
        jsonObject.put("name", subDevice.name);
        jsonObject.put("alias", newName);

        NetClient netClient = null;
        int router = 0;
        if(proxy.lanOnline()){
            router = IntercomConstants.Router.LAN;
            netClient = proxy.lanProxy.netClient;
        }
        else {
            router = IntercomConstants.Router.PROXY;
            netClient = proxy.wanProxy.netClient;
        }

        return intercom.sendIntercomConfigure(router,netClient,deviceItem.name,null,jsonObject.toJSONString());
    }

    /**
     * 获取一体机的server端 familyId
     * @param serverWorkDir
     * @return
     */
    public static String getLocalFamilyID(String serverWorkDir){
        File loadIni = new File(serverWorkDir,"load.ini");
        if(!loadIni.exists()){
            return "";
        }
        JINIParser parser = JINIParser.loadFromFile(loadIni);
        JINIParser.Section section = parser.get("key");
        if(section == null){
            return "";
        }
        String familyId = section.get("key");
        if(!TextUtils.isEmpty(familyId)){
            familyId = IntercomManager.encodeFamilyId(false,familyId);
        }
        return familyId;
    }

    /**
     * 获取一体机的server端 familyId
     * @param serverWorkDir
     * @return
     */
    public static String getLocalButtonKey(String serverWorkDir){
        File loadIni = new File(serverWorkDir,"load.ini");
        if(!loadIni.exists()){
            return "";
        }
        JINIParser parser = JINIParser.loadFromFile(loadIni);
        JINIParser.Section section = parser.get("key");
        return section.get("button_key");
    }

    public static String startRecord(String familyID,String sessionId) {
        long nowTime = System.currentTimeMillis();
        List<DoorRecordBean> recordBeen = DoorAccessOrmUtil.queryRecordBySession(sessionId);
        DoorRecordBean recordBean = null;
        if(recordBeen == null || recordBeen.size() == 0){
            recordBean = DoorSessionManager.getCurrentRecordBean(sessionId);
            if(recordBean == null){
                return null;
            }
        }else{
            recordBean = recordBeen.get(0);
        }
        String videoSession = recordBean.addNewVideoRecord(sessionId,nowTime,recordBean.show_name,recordBean.name);
        IntercomManager.Intercom  intercom = IntercomManager.getInstance().getIntercom(familyID);
        if(intercom == null){
            return null;
        }
        intercom.sessionManager.startRecord(sessionId,videoSession);
        /**
         * 需要对每次的录像生成一个图片
         */
        takeSnapshot(familyID,sessionId);
        return videoSession;
    }

    public static boolean stopRecord(String familyID,String sessionId, String recordSessionId) {
        List<RecordVideoBean> videoBean = DoorAccessOrmUtil.queryRecordVideoBeanBySession(recordSessionId);
        if(videoBean == null || videoBean.size() == 0){
            return false;
        }
        RecordVideoBean recordVideoBean = videoBean.get(0);
        recordVideoBean.chatTime = System.currentTimeMillis() - recordVideoBean.startTime;
        DoorAccessOrmUtil.update(recordVideoBean);
        IntercomManager.Intercom  intercom = IntercomManager.getInstance().getIntercom(familyID);
        if(intercom == null){
            return false;
        }
        return intercom.sessionManager.stopRecord(sessionId);
    }

    /**
     * 收到云端推送来的全视通室外机呼叫消息
     * @param familyId
     * @return
     */
    public static boolean onCloudCallIn(String familyId,String callMessage){
        JSONObject jsonObject = null;
        try {
            jsonObject = JSON.parseObject(callMessage);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(jsonObject == null){
            return false;
        }
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyId);
        if(intercom == null){
            return false;
        }
        IntercomClientManager.IntercomProxy proxy = intercom.clientManager.findProxy(jsonObject.getString("proxy_id"));
        if (proxy == null) {
            return false;
        }

        String sessionId = IntercomManager.createSessionId();

        IntercomMessage message = new IntercomMessage();
        message.setCmd(IntercomConstants.kIntercomCommandCall);
        message.setTo(jsonObject.getString("device_id"));
        message.setUsername(jsonObject.getString("username"));
        message.setSession_id(sessionId);
        message.setRecord(true);
        message.setVideo(true);
        message.setAudio(true);
        //这里是自定义的SIP消息头参数，具体看全时通接口文档
        message.setContent("X-CallUUID=xxx;X-APPUserName=xxx");

        IntercomMessage.ContactBean bean = new IntercomMessage.ContactBean();
        //这里是门口机的sip号码，应该由推送获知
        bean.setAccount("sip:test001@47.100.203.26:18888");
        message.setContact(bean);


        intercom.sessionManager.callout(
                IntercomConstants.Router.PROXY,
                proxy.wanProxy.netClient,
                message);

        return true;
    }

    public static boolean isSupportElevator(String familyId){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyId);
        if (intercom == null){
            return false;
        }
        boolean found = false;

        Map<String, IntercomClientManager.IntercomProxy> proxies = intercom.clientManager.proxies;
        if (proxies.isEmpty()) {
            return false;
        }
        Collection<IntercomClientManager.IntercomProxy> intercomProxies = proxies.values();
        if (intercomProxies.isEmpty()) {
            return false;
        }
        IntercomClientManager.IntercomProxyDescription proxyBean = null;
        for (IntercomClientManager.IntercomProxy intercomProxy : intercomProxies) {
            if (intercomProxy.lanOnline()) {
                proxyBean = intercomProxy.lanProxy;
            } else if (intercomProxy.wanOnline()) {
                proxyBean = intercomProxy.wanProxy;
            }
            if (proxyBean != null && proxyBean.netDevice != null && proxyBean.netDevice.devices != null) {
                for (IntercomNetDevice.NetDeviceItem netDeviceItem : proxyBean.netDevice.devices) {
                    if (!netDeviceItem.scheme.equalsIgnoreCase(IntercomConstants.kIntercomScheme)){
                        continue;
                    }
                    if (netDeviceItem.name.equalsIgnoreCase(DoorFinal.NAME_EXT)){
                        continue;
                    }
                    if (netDeviceItem.name.equalsIgnoreCase(DoorFinal.NAME_P2P)){
                        continue;
                    }
                    if (netDeviceItem.supportElevator()){
                        found = true;
                        return found;
                    }
                }
            }
        }
        return found;
    }

    /**
     *
     * @param familyID
     * @param type 0: 表示招梯，电梯到达用户所在楼层
     *             1 ，表示电梯授权，场景是允许同一个单元的住户可以到达用户所在的楼层，
     *             比如，你让同一个单元不同楼层的朋友到达你所在的楼层
     *
     * @return
     */
    public static boolean elevatorCall(String familyID, int type){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyID);
        if (intercom == null){
            return false;
        }
        boolean found = false;

        Map<String, IntercomClientManager.IntercomProxy> proxies = intercom.clientManager.proxies;
        if (proxies.isEmpty()) {
            return false;
        }
        Collection<IntercomClientManager.IntercomProxy> intercomProxies = proxies.values();
        if (intercomProxies.isEmpty()) {
            return false;
        }
        IntercomClientManager.IntercomProxyDescription proxyBean = null;
        for (IntercomClientManager.IntercomProxy intercomProxy : intercomProxies) {
            int router = IntercomConstants.Router.LAN;
            if (intercomProxy.lanOnline()) {
                proxyBean = intercomProxy.lanProxy;
            } else if (intercomProxy.wanOnline()) {
                proxyBean = intercomProxy.wanProxy;
            }
            if (proxyBean != null && proxyBean.netDevice != null && proxyBean.netDevice.devices != null) {
                for (IntercomNetDevice.NetDeviceItem netDeviceItem : proxyBean.netDevice.devices) {
                    if (!netDeviceItem.scheme.equalsIgnoreCase(IntercomConstants.kIntercomScheme)){
                        continue;
                    }
                    if (netDeviceItem.name.equalsIgnoreCase(DoorFinal.NAME_EXT)){
                        continue;
                    }
                    if (netDeviceItem.name.equalsIgnoreCase(DoorFinal.NAME_P2P)){
                        continue;
                    }
                    if (netDeviceItem.supportElevator()){
                        Bundle bundle = new Bundle();
                        bundle.putString("cmd", "CallElevator");
                        bundle.putInt("type", type);
                        String str = BundleToJSON.toString(bundle);
                        intercom.sendIntercomConfigure(router, proxyBean.netClient, netDeviceItem.name, null, str);
                        found = true;
                        return found;
                    }
                }
            }
        }
        return found;
    }

    /**
     *
     * @param familyId
     * @param content
     * @param needPackage   是否需要将 content 包到一个 Json 中
     */
    public static void sendMCUDeviceMessage(String familyId,String content,boolean needPackage){
        if(needPackage){
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("data",content);
            content = jsonObject.toJSONString();
        }
        if(DoorMessageCallback.mcuDevice != null){
            sendWithSecurityDevice(DoorMessageCallback.mcuDevice.router(),familyId,content);
        }else{
            sendWithFindPorxy(familyId,content);
        }
    }

    private static void sendWithSecurityDevice(int router,String familyId,String content){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyId);
        if(intercom == null){
            return;
        }

        SmartHomeManager.SecurityDevice device = DoorMessageCallback.mcuDevice;
        SmartHomeMessage message = new SmartHomeMessage();
        message.setFrom(device.netClient().getClient_id());
        message.setTo(device.device_name);
        message.setCmd(IntercomConstants.kSmarthomeMCUClient);
        message.setSn(device.netClient().getClient_id());
        message.setProxy_id(device.netClient().getClient_id());
        message.setBroadcast(false);
        message.setSource(SmartHomeMessage.MessageSource.MessageSourceClientPad);
        message.setContent(content);
        intercom.smartHomeManager.sendMessage(router,device.netClient(),message);
    }

    private static void sendWithFindPorxy(String familyId,String content){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyId);
        int router;
        if(intercom == null){
            return;
        }
        Map<String, IntercomClientManager.IntercomProxy> proxies = intercom.clientManager.proxies;
        if(proxies == null || proxies.isEmpty()){
            return;
        }
        Set<String> keySet = proxies.keySet();
        IntercomClientManager.IntercomProxy proxy = proxies.get(keySet.toArray()[0]);
        if(proxy == null){
            return;
        }
        IntercomClientManager.IntercomProxyDescription description = null;
        if(proxy.lanOnline()){
            description = proxy.lanProxy;
            router = IntercomConstants.Router.LAN;
        }else{
            description = proxy.wanProxy;
            router = IntercomConstants.Router.PROXY;
        }
        if(description == null){
            return;
        }
        SmartHomeMessage message = new SmartHomeMessage();
        message.setFrom(description.netClient.getClient_id());
        message.setTo("");
        message.setCmd(IntercomConstants.kSmarthomeMCUClient);
//        message.setCmd(IntercomConstants.kSmarthomeMCUDevice);
        message.setSn(description.netClient.getClient_id());
        message.setProxy_id(description.netClient.getClient_id());
        message.setBroadcast(false);
        message.setSource(SmartHomeMessage.MessageSource.MessageSourceClientPad);
        message.setContent(content);
        intercom.smartHomeManager.sendMessage(router,description.netClient,message);
    }


}
