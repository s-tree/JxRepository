package com.jingxi.smartlife.pad.sdk.doorAccess;

import android.view.SurfaceView;

import com.intercom.sdk.RecordPlayer;
import com.intercom.sdk.peripheral.MCUController;
import com.intercom.util.RemoteService;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorDeviceManager;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorSecurityUtil;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorDevice;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorRecordBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.ExtDeviceBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.RecordVideoBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.SecurityStateBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.DoorAccessConversationUI;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.DoorAccessListUI;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.DoorAccessListener;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.NvrPlaybackListener;

import java.util.List;

public abstract class DoorAccessManager {
    private static DoorAccessManager instance;

    public static DoorAccessManager getInstance(){
        if(instance == null){
            synchronized (DoorAccessManager.class){
                if(instance == null){
                    instance = new DoorAccessManagerImpl();
                }
            }
        }
        return instance;
    }

    /**
     * 监听开锁和呼叫事件
     * @param listener
     */
    public abstract void setDoorAccessListener(DoorAccessListener listener);

    /**
     * 设备列表页面时监听设备变化
     * @param listener
     */
    public abstract void setListUIListener(DoorAccessListUI listener);

    /**
     * 会话页面时监听新事件
     * @param listener
     */
    public abstract void addConversationUIListener(DoorAccessConversationUI listener);

    /**
     * 移除会话监听
     * @param listener
     */
    public abstract void removeConversationUIListener(DoorAccessConversationUI listener);

    /**
     * 在室内通列表页面时监听此回调
     * @param onExtDeviceChanged
     */
    public abstract void setExtDeviceChangedListener(DoorDeviceManager.OnExtDeviceChanged onExtDeviceChanged);

    public abstract void setNvrPlayBackListener(NvrPlaybackListener listener);

    public abstract void removeNvrPlayBackListener(NvrPlaybackListener listener);

    /**
     * 初始化，第一次时无需调用
     */
    public abstract void init();

    /**
     * 结束门禁服务
     */
    public abstract void unInit();

    /**
     * 代理是否已经离线
     * @return
     */
    public abstract boolean isProxyOffline(String familyID);

    /**
     *
     * @param familyID      初始化对应的门禁
     * @param buttonKey
     */
    public abstract void startFamily(String familyID, String buttonKey);

    /**
     * 初始化纯云端（无室内机环境）时的门禁
     * @param familyID
     * @param buttonKey
     * @param sipConfig
     */
    public abstract void startCloudFamily(String familyID,String buttonKey,String sipConfig);

    /**
     * 反初始化所有familyID的门禁
     */
    public abstract void stopAllFamily();

    /**
     *
     * @param familyID      反初始化对应的门禁
     */
    public abstract void stopFamily(String familyID);

    /**
     * 部分情况下会出现门禁连接断开且未能自动重连，可调用此方法重新连接
     */
    public abstract void resumeDoorAccess();

    /**
     * 获取所有在线的设备
     * @return
     */
    public abstract List<DoorDevice> getDevices(String familyID);

    /**
     * 获取设备在线状态
     */
    public abstract void checkDeviceOnline(String familyID);

    /**
     * 外呼
     * @return sessionId
     */
    public abstract String monitor(String familyID, DoorDevice doorDevice);

    public abstract String monitor(String familyID, DoorDevice doorDevice, String msgContent);

    /**
     * 外呼
     * @param needSaveRecord    是否需要保存此次记录
     * @return sessionId
     */
    public abstract String monitor(String familyID, DoorDevice doorDevice,boolean needSaveRecord);

    /**
     * 当前是否支持户户通模式
     * @param familyID
     * @return
     */
    public abstract boolean isSupportP2P(String familyID);

    public abstract String monitorP2P(String familyID,String calledNumber);
    /**
     * 户户通消息外呼
     * @param calledNumber 要外呼的房号
     *                     掩码固定为         2 2 4
     *                     例如               一栋二单元304室
     *                     calledNumber 为    communityId_01 02 0304
     * @param needSaveRecord    是否需要保存此次记录
     * @return
     */
    public abstract String monitorP2P(String familyID,String calledNumber,boolean needSaveRecord);

    /**
     * 接听呼叫
     */
    public abstract void acceptCall(String sessionId);

    /**
     * 挂断呼叫
     */
    public abstract void hangupCall(String sessionId, int result);

    /**
     * 挂断呼叫
     * 真实挂断， hangupCall 会在挂断时判断有无其他室内机等待接听，如果有的话会发送leave ，而不是hangup
     */
    public abstract void truthHangupCall(String sessionId, int result);

    public abstract void hangupCall(String sessionId);

    /**
     * 纯云端(无室内机环境)收到推送的门禁呼叫消息
     * @param familyId
     * @param callMessage
     */
    public abstract void onCloudCallIn(String familyId,String callMessage);

    /**
     * 更新门禁呼叫视图
     * @param surfaceView
     */
    public abstract void updateCallWindow(String sessionId, SurfaceView surfaceView);

    /**
     * 是否播放声音
     * @deprecated
     */
    public abstract void enableLocalToRemoteAudio(String familyID,String sessionId,boolean isEnable);

    /**
     * 是否启用麦克风
     * @deprecated
     */
    public abstract void enableRemoteToLocalAudio(String familyID,String sessionId,boolean isEnable);

    /**
     * 是否启用麦克风
     */
    public abstract void enableLocalMic(String familyID,String sessionId,boolean isEnable);

    /**
     * 是否播放声音
     */
    public abstract void enableLocalPlayer(String familyID,String sessionId,boolean isEnable);

    /**
     * 是否启用传输给对方的视频
     */
    public abstract void enableLocalToRemoteVideo(String familyID,String sessionId,boolean isEnable);

    /**
     * 更新门禁呼叫视图
     * @param surfaceView
     */
    public abstract void updateLocalWindow(SurfaceView surfaceView);

    /**
     *  根据result 获取到挂断的详细原因
     * @param result 挂断时收到的result
     * @return
     */
    public abstract String getHangupMessageByResult(int result);

    /**
     * 获取回放列表
     *
     * @param type      {@link DoorRecordBean#RECORD_TYPE_DOOR} or {@link DoorRecordBean#RECORD_TYPE_P2P}
     * @param pageStart 数据的起始下标 0 ...{n}
     * @param pageSize  每次获取到的数据量
     * @return 视频文件从 DoorRecordBean.getRecordList() 方法中获取,列表中是按时间顺序的
     */
    public abstract List<DoorRecordBean> getHistoryListByType(String familyID, @DoorRecordBean.RECORD_TYPE int type, int pageStart, int pageSize);

    public abstract List<DoorRecordBean> getHistoryListByType(String familyID, @DoorRecordBean.RECORD_TYPE int type);

    /**
     * 获取回放列表
     * @param doorDevice
     * @param pageStart     数据的起始下标 0 ...{n}
     * @param pageSize      每次获取到的数据量
     * @param needCallOut 是否需要外呼记录
     * @return 视频文件从 DoorRecordBean.getRecordList() 方法中获取,列表中是按时间顺序的
     */
    public abstract List<DoorRecordBean> getHistoryListByDevice(String familyID, DoorDevice doorDevice, boolean needCallOut, int pageStart, int pageSize);

    /**
     * 删除单条通话记录
     * @param recordBean
     */
    public abstract void deleteRecord(DoorRecordBean recordBean);

    /**
     * 删除一个集合的通话记录
     */
    public abstract void deleteListRecord(List<DoorRecordBean> recordBeans);

    /**
     * 删除某一类型的通话记录
     */
    public abstract void deleteAllByType(String familyID,@DoorRecordBean.RECORD_TYPE int type);

    /**
     * 开始回放
     */
    public abstract void startPlayBack(RecordPlayer.RecordPlayerHandler onPlaybackListener,String sessionId,String videoPath, int decoder_engine);

    public abstract void switchPlaybackAudio(RecordPlayer.RecordPlayerHandler onPlaybackListener,boolean enable);

    public abstract void enablePlaybackAudioTrack(RecordPlayer.RecordPlayerHandler onPlaybackListener,boolean isLocal,boolean isEnable);

    /**
     * 暂停回放
     */
    public abstract void pausePlayBack(String sessionId);

    /**
     * 调整回放进度
     */
    public abstract void seekPlayBack(String sessionId, int seek);

    /**
     * 更新回放视图
     * @param surfaceView
     */
    public abstract void updatePlayBackWindow(String sessionId, SurfaceView surfaceView);

    /**
     * 删除回放监听
     */
    public abstract void removePlayBackListener(RecordPlayer.RecordPlayerHandler handler);

    /**
     * 开锁（通话过程中）
     * @param sessionID
     */
    public abstract void openDoor(String sessionID);

    /**
     * 开锁（无通话）
     */
    public abstract void openDoor(String familyId,String deviceName);

    /**
     * 是否支持安防模式
     * @param familyID
     * @return
     */
    public abstract boolean isSupportSecurity(String familyID);

    /**
     * 注册安防事件监听
     * @param listener
     */
    public abstract void addSecurityListener(DoorSecurityUtil.OnSecurityChangedListener listener);

    /**
     * 移除安防事件监听
     * @param listener
     */
    public abstract void removeSecurityListener(DoorSecurityUtil.OnSecurityChangedListener listener);

    /**
     * 切换安防状态
      * @param familyID
     */
    public abstract void switchSecurityStatus(String familyID);

    /**
     * 查询安防状态
     * @param familyID
     * @return  @link SecurityStateBean#STATE_NODEFENCE} {@link SecurityStateBean#STATE_UNDEFENCE} {@link SecurityStateBean#STATE_DEFENCE}
     */
    public abstract int querySecurityStatus(String familyID);

    /**
     * 关闭安防报警
     * @param familyID
     */
    public abstract void cancelSecurityWarning(String familyID);

    /**
     * 是否支持室内通模式
     * @return
     */
    public abstract boolean isSupportExt(String familyID);

    /**
     * 获取所有的室内通设备
     * 返回的列表中可能会有重复数据，需要手动去重
     * 去重根据 {@link com.intercom.sdk.NetClient#button_key}{@link com.intercom.sdk.NetClient#sub_type} 判断
     * sub_type 参考 {@link com.intercom.sdk.IntercomConstants.NetClientSubType}
     * @return
     */
    public abstract List<ExtDeviceBean> getExtDevices(String familyID,String buttonKey);

    public abstract String callExt(String familyID,ExtDeviceBean extDeviceBean,boolean isMonitor);
    /**
     *
     * 室内通的外呼
     * @param extDeviceBean
     * @param isMonitor         true        监控模式（对象是底座，有声音，对象是平板，有视频和声音），无需对方接听即可连接，仅为单向通话，对方无任何反馈
     *                           false       呼叫模式 ，双向通话，需要对方接听后才能通话
     * @param needSaveRecord    是否需要保存此次记录
     * @return
     */
    public abstract String callExt(String familyID,ExtDeviceBean extDeviceBean,boolean isMonitor,boolean needSaveRecord);

    /**
     * 必须在{@link DoorAccessManager#startFamily(String, String)}之前，
     * 且在子线程中，将asset文件拷贝到sd卡中
     */
    public abstract void check();

    public abstract void sendPushMessage(String message);

    public abstract void takeSnapshot(String familyId, String sessionId);

    public abstract void enablePreview(boolean enable);

    public abstract void startRemoteService(RemoteService.RemoteServiceHandler handler, RemoteService.RemoteSession remoteSession, String familyID, String conf);

    public abstract void stopRemoteService();

    public abstract boolean startMCU(MCUController.MCUControllerHandler handler,String mcuConf,String buttonConf,int type);

    public abstract void stopMCU();

    public abstract boolean switchLight(MCUController.MCUControllerHandler handler,int msec, int freq, boolean force);

    /**
     * 是否支持修改设备名
     * @param familyId
     * @param subDevice
     * @return
     */
    public abstract boolean isSupportChangeDeviceName(String familyId,DoorDevice subDevice);

    /**
     * 设置设备的名称
     * @param familyId
     * @param subDevice
     * @param jsonString 要发出去的配置
     * @return
     */
    public abstract boolean sendConfigure(String familyId, DoorDevice subDevice,String jsonString, String sessionId);

    /**
     * 设置设备的名称
     * @param familyId
     * @param subDevice
     * @param newName
     * @return
     */
    public abstract boolean changeDeviceName(String familyId, DoorDevice subDevice, String newName);

    /**
     * 设置设备的名称
     * @return
     */
    public abstract String getLocalFamilyId(String serverWorkDir);

    /**
     * 设置设备的名称
     * @return
     */
    public abstract String getLocalButtonKey(String serverWorkDir);

    /**
     * 开始录制
     * @return recordSessionId
     */
    public abstract String startRecord(String familyID,String sessionId);

    /**
     * 停止录制
     *
     * @param sessionId
     */
    public abstract boolean stopRecord(String familyID, String sessionId, String recordSessionId);

    public abstract void deleteVideoRecord(RecordVideoBean recordVideoBean);

    public abstract void deleteVideoRecordList(List<RecordVideoBean> recordVideoBeans);

    public abstract boolean elevatorCall(String familyId, int type);

    public abstract boolean isSupportElevator(String familyId);

    /**
     * 是否使用立体声
     * @param isEnable
     * @return
     */
    public abstract void setStereoEnable(boolean isEnable);

    public abstract void sendMCUDeviceMessage(String familyId,String content);
}
