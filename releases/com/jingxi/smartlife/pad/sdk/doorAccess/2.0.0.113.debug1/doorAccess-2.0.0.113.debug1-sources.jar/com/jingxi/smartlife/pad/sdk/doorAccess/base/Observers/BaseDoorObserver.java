package com.jingxi.smartlife.pad.sdk.doorAccess.base.Observers;

import com.intercom.sdk.IntercomConstants;
import com.intercom.sdk.IntercomManager;
import com.intercom.sdk.IntercomMessage;
import com.intercom.sdk.IntercomSessionManager;
import com.intercom.sdk.NetClient;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorManagerUtil;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorSessionManager;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorEvent;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.orm.DoorAccessOrmUtil;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.DoorAccessConversationUI;

import java.util.ArrayList;
import java.util.List;

/**
 * @author bjj
 * the return of all method is means need to updateUI
 * IntercomMessage 需要判断 ack
 * ack   true  : 自己发送的消息的回包
 *       false : 对方发送的消息
 */
public class BaseDoorObserver {

    /**
     * 收到呼叫请求，此时还未正式响铃，只是发起请求，未呼叫
     *
     * @param intercom
     * @param router
     * @param netClient
     * @param message
     * @return
     */
    boolean onInvite(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message, int from) {
        DoorEvent event = new DoorEvent();
        event.netClient = netClient;
        event.intercom = intercom;
        event.message = message;
        event.type = from;
        event.sessionId = message.getSession_id();
        event.cmd = message.getCmd();
        event.router = router;
        List<DoorAccessConversationUI> tempUI = new ArrayList<>(DoorSessionManager.getConversationUI());
        int result = IntercomConstants.IntercomMessageResult.IntercomMessageResultOK;
        for (DoorAccessConversationUI ui : tempUI) {
            result = ui.inviteIntercept(event);
        }
        if (result == IntercomConstants.IntercomMessageResult.IntercomMessageResultOK) {
            message.setResult(IntercomConstants.IntercomMessageResult.IntercomMessageResultOK);
            DoorManagerUtil.accept(intercom, router, netClient, message);
        } else {
            DoorManagerUtil.decline(intercom, router, netClient, message, result);
        }
        return false;
    }

    /**
     * 仅有室内通会收到call 消息,SDK 中不需要处理
     * @param intercom
     * @param router
     * @param netClient
     * @param message
     * @return
     */
    boolean onCall(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message, int from){
        if(message.isAck()){
            if (message.getResult() != 0) {
                //对方decline的需要处理
                intercom.sessionManager.removeSession(message.getSession_id());
                return true;
            }
            return false;
        }
        DoorEvent event = new DoorEvent();
        event.netClient = netClient;
        event.intercom = intercom;
        event.message = message;
        event.type = from;
        event.sessionId = message.getSession_id();
        event.cmd = message.getCmd();
        event.router = router;
        List<DoorAccessConversationUI> tempUI = new ArrayList<>(DoorSessionManager.getConversationUI());
        int result = IntercomConstants.IntercomMessageResult.IntercomMessageResultOK;
        for(DoorAccessConversationUI ui : tempUI){
            result = ui.inviteIntercept(event);
        }
        if (result == IntercomConstants.IntercomMessageResult.IntercomMessageResultOK) {
            message.setResult(IntercomConstants.IntercomMessageResult.IntercomMessageResultOK);
            DoorManagerUtil.accept(intercom, router, netClient, message);
        }else {
            DoorManagerUtil.decline(intercom, router, netClient, message, result);
        }
        return false;
    }

    /**
     * 呼叫进入
     * @param intercom
     * @param router
     * @param netClient
     * @param message
     * @return
     */
    boolean onRinging(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message){
        IntercomSessionManager.IntercomSession session = intercom.sessionManager.findSession(message.getSession_id());
        if(session != null){
            session.ringing();
        }
        return true;
    }

    /**
     * 呼叫接听
     * @param intercom
     * @param router
     * @param netClient
     * @param message
     * @return
     */
    boolean onPickup(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message){
        if(!message.isAck()){
            // 对方接听
            IntercomSessionManager.IntercomSession session = intercom.sessionManager.findSession(message.getSession_id());
            if(session != null){
                session.connected();
            }
        }
        DoorSessionManager.pickUp(message.getSession_id());
        return true;
    }

    /**
     * 呼叫被其他用户接听
     * @param intercom
     * @param router
     * @param netClient
     * @param message
     * @return
     */
    boolean onPickupByOther(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message){
        return true;
    }

    /**
     * 通话挂断
     * @param intercom
     * @param router
     * @param netClient
     * @param message
     * @return
     */
    boolean onHangup(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message){
        DoorAccessOrmUtil.updateChatHangup(message.getSession_id(),message.isAck());
        DoorSessionManager.hangup(message.getSession_id());
        return true;
    }

    /**
     * 门禁开锁
     * @param intercom
     * @param router
     * @param netClient
     * @param message
     * @return
     */
    boolean onUnLock(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message){
        return true;
    }

    /**
     * 通话/呼叫超时
     * @param intercom
     * @param router
     * @param netClient
     * @param message
     * @return
     */
    boolean onTimeOut(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message){
        return true;
    }

    /**
     * 对方未接通就挂断，会发送leave消息
     * @param intercom
     * @param router
     * @param netClient
     * @param message
     * @return
     */
    boolean onLeave(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message){
        return true;
    }
}
