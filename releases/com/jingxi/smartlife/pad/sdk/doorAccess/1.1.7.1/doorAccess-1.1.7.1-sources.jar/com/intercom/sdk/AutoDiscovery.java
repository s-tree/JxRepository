package com.intercom.sdk;

public class AutoDiscovery {
    private long mNativeAutoDiscoveryJavaObj;
    private final OnAutoDiscoveryEventListener listener;

    public AutoDiscovery(OnAutoDiscoveryEventListener listener) {
        this.mNativeAutoDiscoveryJavaObj = 0;
        this.listener = listener;
    }

    public boolean start(String conf, String net_client) {
        return nativeStart(conf, net_client);
    }

    public void stop() {
        nativeStop();
    }

    public boolean accept(String net_client) {
        return nativeAccept(net_client);
    }

    public boolean decline(String client_id) {
        return nativeDecline(client_id);
    }

    private void postEventFromNative(String net_client) {
        listener.OnAutoDiscoveryClient(net_client);
    }

    public interface OnAutoDiscoveryEventListener {
        void OnAutoDiscoveryClient(String net_client);
    }

    private native boolean nativeStart(String conf, String net_client);

    private native void nativeStop();

    private native boolean nativeAccept(String net_client);

    private native boolean nativeDecline(String client_id);
}
