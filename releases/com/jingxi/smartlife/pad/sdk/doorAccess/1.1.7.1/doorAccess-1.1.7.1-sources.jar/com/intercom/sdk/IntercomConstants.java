package com.intercom.sdk;

public class IntercomConstants {

    public static class LogLevel {
        public static final int Info = 0;
        public static final int Warning = 1;
        public static final int Error = 2;
        public static final int Fatal = 3;
    }

    public static class Router {
        public static final int LAN = 0;
        public static final int PROXY = 1;
    }

    public static class NetClientType {
        public static final int NetClientTypeUndefined = 0;
        public static final int NetClientTypeProxy = 1;
        public static final int NetClientTypeClient = 2;
    }

    public static class NetClientSubType {
        public static final int NetClientSubTypeUndefined = -1;
        public static final int NetClientSubTypePad = 0;
        public static final int NetClientSubTypeMobile = 1;
        public static final int NetClientSubTypeTV = 2;
        public static final int NetClientSubTypeEmbedded = 3;
    }

    public static class NetProxytSubType {
        public static final int NetProxySubTypeUndefined = -1;
        public static final int NetProxySubTypeIndoor = 0;
        public static final int NetProxySubTypeIntercom = 1;
    }

    public static class NetClientOSPlatformType {
        public static final int NetClientOSPlatformUndefined = 0;
        public static final int NetClientOSPlatformOPENWRT = 1;
        public static final int NetClientOSPlatformLINUX = 2;
        public static final int NetClientOSPlatformANDROID = 3;
        public static final int NetClientOSPlatformIOS = 4;
        public static final int NetClientOSPlatformMAC = 5;
        public static final int NetClientOSPlatformWIN = 6;
    }

    public static class IntercomProxyEvent {
        public static final int IntercomProxyEventMessage = 0;
        public static final int IntercomProxyEventSendResult = 1;
        public static final int IntercomProxyEventProxyStateChanged = 2;
        public static final int IntercomProxyEventClientStateChanged = 3;
        public static final int IntercomProxyEventInternetProxyStateChanged = 4;
        public static final int IntercomProxyEventProxyDeviceChanged = 5;
    }

    public static class IntercomEvent {
        public static final int IntercomEventMessage = 0;
        public static final int IntercomVideoReady = 1;
        public static final int IntercomSnapshotReady = 2;
        public static final int IntercomVideoDimensionChanged = 3;
        public static final int IntercomSipStateChanged = 4;

        public static final int IntercomDtmfReady = 5;
        public static final int IntercomStreamStateChanged = 6;
        public static final int IntercomStreamTransportStarted = 7;
        public static final int IntercomStreamTransportStatistics = 8;
        public static final int IntercomStreamTransportIceNegotiation = 9;
    }

    public static class AppEvent {
        public static final int Event_App_Initialized = 0;
        public static final int Event_Media_Device_State_Changed = 1;
        public static final int Event_Remote_Service_State_Changed = 2;
    }

    public static class MCUEvent {
        /**
         * 收到MCU发来的消息
         */
        public static final int Event_MCU_Message = 0;
        //MCU 连接状态变化
        public static final int Event_MCU_State_Changed = 1;
        //按键事件，按下，松开等等
        public static final int Event_MCU_Button_Event = 2;
        //触发了某个具体的按键事件
        public static final int Event_MCU_Button_Click = 3;
    }

    public static class MCUMessageType {
        public static final int MessageTypeUnknown = 0;
        public static final int MessageTypeWatchdog = 1;
        public static final int MessageTypeButton = 2;
        public static final int MessageTypeLight = 3;
        public static final int MessageTypeSoundSwitch = 4;
        public static final int MessageTypeSecurity = 5;
        public static final int MessageTypeStartupNum = 6;
        public static final int MessageTypeMCU = 7;
    }

    public static class MediaPlayEvent {
        public static final int MediaPlayEventDuration = 0;
        public static final int MediaPlayEventProgress = 1;
        public static final int MediaPlayEventCompleted = 2;
        public static final int MediaPlayEventDimensionChanged = 3;
    }

    public static class SipRegistrationState {
        public static final int SipRegistrationNone = 0;
        public static final int SipRegistrationProgress = 1;
        public static final int SipRegistrationOk = 2;
        public static final int SipRegistrationCleared = 3;
        public static final int SipRegistrationFailed = 4;
    }

    public static class TransportMediaType {
        public static final int TransportMediaTypeNone = 0;
        public static final int TransportMediaTypeAudio = 1;
        public static final int TransportMediaTypeVideo = 2;
    }

    public static class TransportMediaDir {
        public static final int TransportMediaDirNone = 0;
        public static final int TransportMediaDirEncoding = 1;
        public static final int TransportMediaDirDecoding = 2;
        public static final int TransportMediaDirEncodingDecoding = 3;
    }

    public static class StreamState {
        public static final int StreamStateStart = 0;
        public static final int StreamStateStop = 1;
    }

    public static class IntercomMessageResult {
        public static final int IntercomMessageResultOK = 0;
        public static final int IntercomMessageResultErr = 1;
        public static final int IntercomMessageResultDeviceName = 2;
        public static final int IntercomMessageResultSessionId = 3;
        public static final int IntercomMessageResultNOAuthority = 4;
        public static final int IntercomMessageResultUnsupportCommand = 5;
        public static final int IntercomMessageResultNotConnected = 6;
        public static final int IntercomMessageResultDeviceBusy = 7;
        public static final int IntercomMessageResultUserName = 8;
        public static final int IntercomMessageResultNet = 9;
        public static final int IntercomMessageResultTransport = 10;
    }

    public static class SmarthomeMessageResult {
        public static final int SmarthomeMessageResultOK = 0;
        public static final int SmarthomeMessageResultErr = 1;
        public static final int SmarthomeMessageResultDeviceOffline = 2;
        public static final int SmarthomeMessageResultDeviceName = 3;
        public static final int SmarthomeMessageResultNOAuthority = 4;
        public static final int SmarthomeMessageResultUnsupportCommand = 5;
    }

    public static class OSType {
        public static final int CLIENT_OS_UNKNOWN = 0;
        public static final int CLIENT_OS_OPENWRT = 1;
        public static final int CLIENT_OS_LINUX = 2;
        public static final int CLIENT_OS_ANDROID = 3;
        public static final int CLIENT_OS_IOS = 4;
        public static final int CLIENT_OS_WINDOWS = 5;
    }

    public static class ButtonAction {
        public static final int Type_Unknow = 0;
        public static final int Type_Pressed = 1;
        public static final int Type_Released = 2;
        public static final int Type_Long_Pressed = 3;
    }

    public static class RemoteServiceState {
        public static final int RemoteServiceStateStart = 0;
        public static final int RemoteServiceStateConnected = 1;
        public static final int RemoteServiceStateDisconnected = 2;
        public static final int RemoteServiceStateStop = 3;
        public static final int RemoteServiceStateFailed = 4;
    }

    public static String kAudioCodecAAC = "AAC";
    public static String kAudioCodecPCM = "PCM";
    public static String kAudioCodecPCM_MULAW = "ULAW";
    public static String kAudioCodecPCM_ALAW = "ALAW";


    static public String GetMediaTypeString(int type) {
        if (type == TransportMediaType.TransportMediaTypeAudio)
            return "audio";
        if (type == TransportMediaType.TransportMediaTypeVideo)
            return "video";
        return "unknow media type";
    }

    static public String GetStreamStateString(int state) {
        if (state == StreamState.StreamStateStart)
            return "connected";
        if (state == StreamState.StreamStateStop)
            return "disconnected";
        return "";
    }

    public static String kAppScheme = "app";
    public static String kClientScheme = "client";
    public static String kMCUScheme = "mcu";

    public static String kProxyScheme = "proxy";
    public static String kMediaPlayScheme = "player";

    public static String kIntercomScheme = "icom";
    public static String kIntercomCommandInvite = "invite";
    public static String kIntercomCommandRinging = "ringing";
    public static String kIntercomCommandCall = "call";
    public static String kIntercomCommandPickup = "pickup";
    public static String kIntercomCommandHangup = "hangup";
    public static String kIntercomCommandUnlock = "unlock";
    public static String kIntercomCommandPickupByOther = "pickupbyother";
    public static String kIntercomCommandBeginTalk = "begintalk";
    public static String kIntercomCommandEndTalk = "endtalk";
    public static String kIntercomCommandSessionTimeout = "timeout";
    public static String kIntercomCommandLeaveSession = "leave";
    public static String kIntercomCommandMessage = "message";
    public static String kIntercomCommandSnapshot = "snapshot";

    /**
     * 配置或者控制代理中的门禁设备都使用这个命令
     */
    public static String kIntercomCommandConfigure = "configure";

    /**
     * 门禁事件通知都走这个消息，这个消息只能由代理发出，比如摄像头被遮挡事件通知
     */
    public static String kIntercomCommandNotify = "notify";

    public static String kButtonScheme = "button";
    public static String kButtonSOS = "sos";
    public static String kButtonUser = "user";
    public static String kButtonMonitor = "monitor";
    public static String kButtonUnlock = "unlock";
    public static String kButtonPickup = "pickup";
    public static String kButtonPadNear = "pad_near";
    public static String kButtonPadLeave = "pad_leave";
    public static String kButtonHumanNear = "human_near";
    public static String kButtonHumanLeav = "human_leave";


    public static String kSmarthomeScheme = "gateway";
    public static String kSmarthomeQuery = "query";
    public static String kSmarthomeSwitch = "switch";
    public static String kSmarthomeEvent = "event";
    public static String kSmarthomeCancel = "cancel";
    public static String kSmarthomeState = "state";
    public static String kSmarthomeDevice = "device";
    public static String kSmarthomeButton = "button";
    public static String kSmarthomeEmbed = "embed";
    public static String kSmarthomeMCUDevice = "mcudevice";
    public static String kSmarthomeMCUClient = "mcuclient";

    public static String kFrontCameraName = "front";
    public static String kBackCameraName = "back";

    public static String kConfigDirName = "conf";
    public static String kLoadIniFileName = "load.ini";
}
