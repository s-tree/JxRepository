package com.intercom.sdk;

import java.util.List;

public class SecurityMessage {

    /**
     * cmd : report
     * state : [{"area":0,"value":0},{"area":1,"value":1},{"area":2,"value":2},{"area":3,"value":3},{"area":4,"value":4},{"area":5,"value":5},{"area":6,"value":6},{"area":7,"value":7}]
     */

    private String cmd;
    private String room;
    private String time;

    private List<StateBean> state;

    public String getCmd() {
        return cmd;
    }

    public void setCmd(String cmd) {
        this.cmd = cmd;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public List<StateBean> getState() {
        return state;
    }

    public void setState(List<StateBean> state) {
        this.state = state;
    }

    public static class StateBean {
        /**
         * area : 0
         * value : 0
         */

        private int    area;
        private int    value;
        private String alias;
        private String type;

        public int getArea() {
            return area;
        }

        public void setArea(int area) {
            this.area = area;
        }

        public int getValue() {
            return value;
        }

        public void setValue(int value) {
            this.value = value;
        }

        public String getAlias() {
            return alias;
        }

        public void setAlias(String alias) {
            this.alias = alias;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }
    }
}
