package com.jingxi.smartlife.pad.sdk.doorAccess.base.orm;

import android.text.TextUtils;

import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorConfigs;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorSessionManager;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorDevice;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorRecordBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.RecordVideoBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.utils.FileUtil;
import com.litesuits.orm.db.assit.QueryBuilder;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class DoorAccessOrmUtil extends LiteOrmUtil {

    public static void update(RecordVideoBean videoBean){
        getLiteOrm().update(videoBean);
    }

    public static List<RecordVideoBean> queryRecordVideoBeanBySession(String recordSession){
        QueryBuilder<RecordVideoBean> queryBuilder = QueryBuilder.create(RecordVideoBean.class)
                .whereEquals("videoSession",recordSession);
        return getLiteOrm().query(queryBuilder);
    }

    public static void saveRecord(DoorRecordBean recordBean){
        long count = queryDoorRecordCount();
        if(count >= DoorConfigs.getMaxRecordCount()){
            List<DoorRecordBean> recordBeans = getLiteOrm().query(DoorRecordBean.class);
            DoorRecordBean willDelete = recordBeans.get(0);
            deleteRecordFile(willDelete);
            getLiteOrm().delete(willDelete);
        }
        getLiteOrm().save(recordBean);
    }

    /**
     * 门禁的历史记录中有视频保存，需要处理
     * @return
     */
    private static long queryDoorRecordCount(){
        QueryBuilder queryBuilder = QueryBuilder.create(DoorRecordBean.class)
                .whereEquals("record_type",DoorRecordBean.RECORD_TYPE_DOOR);
        return getLiteOrm().queryCount(queryBuilder);
    }

    public static void deleteRecord(DoorRecordBean recordBean){
        deleteRecordFile(recordBean);
        getLiteOrm().delete(recordBean);
    }

    public static void deleteListRecord(List<DoorRecordBean> recordBeans){
        for(DoorRecordBean doorRecordBean : recordBeans){
            deleteRecordFile(doorRecordBean);
        }
        getLiteOrm().delete(recordBeans);
    }

    public static void deleteAllByType(String familyID,@DoorRecordBean.RECORD_TYPE int type){
        QueryBuilder<DoorRecordBean> queryBuilder = QueryBuilder.create(DoorRecordBean.class)
                .whereEquals("familyID",familyID)
                .whereAppendAnd()
                .whereEquals("record_type",type);
        List<DoorRecordBean> recordBeans = getLiteOrm().query(queryBuilder);
        deleteListRecord(recordBeans);
    }

    public static List<DoorRecordBean> queryRecordsByType(String familyID,@DoorRecordBean.RECORD_TYPE int type,int pageStart,int pageSize){
        QueryBuilder<DoorRecordBean> queryBuilder = QueryBuilder.create(DoorRecordBean.class)
                .whereEquals("familyID",familyID)
                .whereAppendAnd()
                .whereEquals("record_type",type)
                .appendOrderDescBy("startTime")
                .limit(pageStart, pageSize);
        return getLiteOrm().query(queryBuilder);
    }

    public static List<DoorRecordBean> queryRecordsByDevice(String familyID, DoorDevice doorDevice, boolean needCallOut, int pageStart, int pageSize){
        QueryBuilder<DoorRecordBean> queryBuilder = QueryBuilder.create(DoorRecordBean.class)
                .whereEquals("familyID",familyID)
                .whereAppendAnd()
                .whereEquals("name",doorDevice.name)
                .appendOrderDescBy("startTime")
                .limit(pageStart, pageSize);
        if (!needCallOut) {
            queryBuilder.whereAppendAnd()
                    .whereNoEquals("chatEvent", DoorRecordBean.CALL_EVENT_CALLOUT)
                    .whereAppendAnd()
                    .whereNoEquals("chatEvent", DoorRecordBean.CALL_EVENT_CALLOUT_REJECT)
                    .whereAppendAnd()
                    .whereNoEquals("chatEvent", DoorRecordBean.CALL_EVENT_CALLOUT_CANCEL)
                    .whereAppendAnd()
                    .whereNoEquals("chatEvent", DoorRecordBean.CALL_EVENT_CALLOUT_TIMEOUT)
                    .whereAppendAnd()
                    .whereNoEquals("chatEvent", DoorRecordBean.CALL_EVENTCALLOUT_CHATTING);
        }
        return getLiteOrm().query(queryBuilder);
    }

    public static List<DoorRecordBean> queryRecordBySession(String sessionId){
        QueryBuilder<DoorRecordBean> queryBuilder = QueryBuilder.create(DoorRecordBean.class)
                .whereEquals("session_id",sessionId);
        return getLiteOrm().query(queryBuilder);
    }


    public static void clearRecord(){
        getLiteOrm().deleteAll(DoorRecordBean.class);
    }

    public static void updateThumb(String sessionId,String thumbPath){
        boolean isFromDB = true;
        List<DoorRecordBean> recordBeans = queryRecordBySession(sessionId);
        if(recordBeans == null || recordBeans.isEmpty()){
            DoorRecordBean recordBean = DoorSessionManager.getCurrentRecordBean(sessionId);
            if(recordBean == null){
                return;
            }
            isFromDB = false;
            recordBeans = new ArrayList<>();
            recordBeans.add(recordBean);
        }
        for(DoorRecordBean recordBean : recordBeans){
            List<RecordVideoBean> recordVideoBeans = recordBean.getJustRecords();
            if(recordVideoBeans.size() == 0){
                recordBean.thumbPath = thumbPath;
            }
            else{
                RecordVideoBean recordVideoBean = recordVideoBeans.get(recordVideoBeans.size() - 1);
                recordVideoBean.picPath = thumbPath;
                if(isFromDB){
                    DoorAccessOrmUtil.update(recordVideoBean);
                }
            }
        }
        if(isFromDB){
            getLiteOrm().update(recordBeans);
        }
    }

    /**
     * 更新通话成功的事件
     * @param sessionId
     */
    public static void updateChatSuccess(String sessionId){
        boolean isFromDB = true;
        List<DoorRecordBean> recordBeans = queryRecordBySession(sessionId);
        if(recordBeans == null || recordBeans.isEmpty()){
            DoorRecordBean recordBean = DoorSessionManager.getCurrentRecordBean(sessionId);
            if(recordBean == null){
                return;
            }else{
                isFromDB = false;
                recordBeans = new ArrayList<>();
                recordBeans.add(recordBean);
            }
        }
        for(DoorRecordBean recordBean : recordBeans){
            if(recordBean.chatEvent == DoorRecordBean.CALL_EVENT_CALLOUT){
                recordBean.chatEvent = DoorRecordBean.CALL_EVENTCALLOUT_CHATTING;
            }
            else if(recordBean.chatEvent == DoorRecordBean.CALL_EVENT_RECEIVER){
                recordBean.chatEvent = DoorRecordBean.CALL_EVENT_RECEIVER_CHATTING;
            }
        }
        if(isFromDB){
            getLiteOrm().update(recordBeans);
        }
    }

    /**
     * 更新通话挂断的事件
     * 外呼时有取消和被挂断
     * 收到呼叫时有被取消和自己挂断
     * @param sessionId
     */
    public static void updateChatHangup(String sessionId,boolean fromSelf){
        boolean isFromDB = true;
        List<DoorRecordBean> recordBeans = queryRecordBySession(sessionId);
        if(recordBeans == null || recordBeans.isEmpty()){
            DoorRecordBean recordBean = DoorSessionManager.getCurrentRecordBean(sessionId);
            if(recordBean == null){
                return;
            }else{
                isFromDB = false;
                recordBeans = new ArrayList<>();
                recordBeans.add(recordBean);
            }
        }
        for(DoorRecordBean recordBean : recordBeans){
            if(recordBean.chatEvent == DoorRecordBean.CALL_EVENT_CALLOUT){
                recordBean.chatEvent = fromSelf ? DoorRecordBean.CALL_EVENT_CALLOUT_CANCEL : DoorRecordBean.CALL_EVENT_CALLOUT_REJECT;
            }
            else if(recordBean.chatEvent == DoorRecordBean.CALL_EVENT_RECEIVER){
                recordBean.chatEvent = fromSelf ? DoorRecordBean.CALL_EVENT_RECEIVER_REJECT : DoorRecordBean.CALL_EVENT_RECEIVER_CANCEL;
            }
            recordBean.chat_time = (int) (System.currentTimeMillis() - recordBean.startTime);
        }
        if(isFromDB){
            getLiteOrm().update(recordBeans);
        }
    }

    private static void deleteRecordFile(DoorRecordBean recordBean){
        try{
            String sessionDir = TextUtils.concat(DoorConfigs.getMediaDir(),"/",recordBean.session_id).toString();
            FileUtil.deleteFile(new File(sessionDir));
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    /**
     * 获取通话事件
     * @param sessionId
     * @return
     */
    public static int getChatEvent(String sessionId){
        List<DoorRecordBean> recordBeans = queryRecordBySession(sessionId);
        if(recordBeans == null || recordBeans.isEmpty()){
            return -1;
        }
        return recordBeans.get(0).chatEvent;
    }

    public static void deleteVideoRecord(RecordVideoBean recordVideoBean) {
        if (!TextUtils.isEmpty(recordVideoBean.chatSession)) {
            List<DoorRecordBean> doorRecordBeans = queryRecordBySession(recordVideoBean.chatSession);
            if (doorRecordBeans != null && doorRecordBeans.size() > 0) {
                DoorRecordBean doorRecordBean = doorRecordBeans.get(0);
                if (doorRecordBean.getRecordList().size() == 0) {
                    //应该不会有这种情况
                    deleteVideoRecordFile(recordVideoBean);
                    getLiteOrm().delete(recordVideoBean);
                    deleteRecord(doorRecordBean);
                } else if (doorRecordBean.getRecordList().size() == 1) {
                    if (TextUtils.equals(doorRecordBean.session_id, recordVideoBean.videoSession)) {
                        //老版本直接删除
                        deleteRecord(doorRecordBean);
                    } else {
                        deleteVideoRecordFile(recordVideoBean);
                        getLiteOrm().delete(recordVideoBean);
                        deleteRecord(doorRecordBean);
                    }
                } else {
                    deleteVideoRecordFile(recordVideoBean);
                    getLiteOrm().delete(recordVideoBean);
                }
            }
        }
    }

    private static void deleteVideoRecordFile(RecordVideoBean recordVideoBean) {
        try{
            FileUtil.deleteFile(new File(recordVideoBean.videoPath));
            FileUtil.deleteFile(new File(recordVideoBean.picPath));
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static void deleteVideoRecordList(List<RecordVideoBean> recordVideoBeans) {
        for (RecordVideoBean recordVideoBean : recordVideoBeans) {
            deleteVideoRecord(recordVideoBean);
        }
    }
}
