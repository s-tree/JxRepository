package com.jingxi.smartlife.pad.sdk.doorAccess.base;

import android.text.TextUtils;
import android.view.SurfaceView;

import com.alibaba.fastjson.JSONObject;
import com.intercom.sdk.IntercomClientManager;
import com.intercom.sdk.IntercomConstants;
import com.intercom.sdk.IntercomManager;
import com.intercom.sdk.IntercomMessage;
import com.intercom.sdk.IntercomNetDevice;
import com.intercom.sdk.JINIParser;
import com.intercom.sdk.NetClient;
import com.intercom.sdk.RecordPlayer;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.CallOutBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorDevice;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorEvent;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorRecordBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.ExtDeviceBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.RecordVideoBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.orm.DoorAccessOrmUtil;
import com.jingxi.smartlife.pad.sdk.utils.JXLogUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * @author bjj
 * 门禁3.0 控制封装
 */
public class DoorManagerUtil {

    /**
     * 门禁查看监控
     */
    public static String monitor(String familyDockSn, DoorDevice subDevice,boolean needSaveRecord){
        String sessionId = "";
        CallOutBean callOutBean = DoorMessageFactory.buildMonitorCallOutBean(familyDockSn,subDevice);
        if(callOutBean == null){
            return sessionId;
        }
        sessionId = callOutBean.message.getSession_id();
        IntercomManager.Intercom intercom = callout(familyDockSn,callOutBean);

        DoorRecordBean recordBean = DoorRecordBean.parseDoorRecord(
                familyDockSn,
                IntercomConstants.kIntercomScheme,
                callOutBean.message.getFrom(),
                callOutBean.message.getUsername(),
                callOutBean.message.getSession_id(),
                DoorRecordBean.CALL_EVENT_CALLOUT);

        if(needSaveRecord){
            DoorAccessOrmUtil.saveRecord(recordBean);
        }

        DoorEvent event = new DoorEvent();
        event.intercom = intercom;
        event.sessionId = sessionId;
        event.message = callOutBean.message;
        event.router = callOutBean.router;

        DoorSessionManager.monitor(subDevice,event,sessionId,recordBean);

        return sessionId;
    }

    /**
     * 室内通消息外呼
     * @param extDeviceBean     室内通对象
     * @param isMonitor         是否是监控模式
     * @return sessionID
     */
    public static String callExtOut(String familyDockSn, ExtDeviceBean extDeviceBean, boolean isMonitor,boolean needSaveRecord){
        CallOutBean callOutBean = DoorMessageFactory.buildExtCallOutBean(familyDockSn,extDeviceBean,isMonitor);
        if(callOutBean == null){
            return "";
        }

        IntercomManager.Intercom intercom = callout(familyDockSn,callOutBean);

        int chatEvent = isMonitor ? DoorRecordBean.CALL_EVENT_EXT_MONITOR : DoorRecordBean.CALL_EVENT_CALLOUT;

        String sessionId = callOutBean.message.getSession_id();

        DoorRecordBean recordBean = DoorRecordBean.parseExtRecord(
                familyDockSn,
                sessionId,
                extDeviceBean.clientBean.getButton_key(),
                extDeviceBean.clientBean.getSub_type(),
                chatEvent);

        if(needSaveRecord){
            DoorAccessOrmUtil.saveRecord(recordBean);
        }

        DoorEvent event = new DoorEvent();
        event.intercom = intercom;
        event.sessionId = sessionId;
        event.message = callOutBean.message;
        event.router = callOutBean.router;

        DoorSessionManager.monitorExt(event,sessionId,recordBean);

        return sessionId;
    }

    /**
     * 户户通消息外呼
     * @param number            communityid+户户通呼出的房号
     * @return sessionID
     */
    public static String callP2POut(String familyDockSn, String number,boolean needSaveRecord){
        CallOutBean callOutBean = DoorMessageFactory.buildP2PCalloutBean(familyDockSn,number);
        if(callOutBean == null){
            return "";
        }
        IntercomManager.Intercom intercom = callout(familyDockSn,callOutBean);
        String sessionId = callOutBean.message.getSession_id();

        DoorRecordBean recordBean = DoorRecordBean.parseP2PRecord(
                familyDockSn,
                IntercomConstants.kIntercomScheme,
                callOutBean.message.getFrom(),
                callOutBean.message.getUsername(),
                sessionId,
                DoorRecordBean.CALL_EVENT_CALLOUT);
        if(needSaveRecord){
            DoorAccessOrmUtil.saveRecord(recordBean);
        }

        DoorEvent event = new DoorEvent();
        event.intercom = intercom;
        event.sessionId = sessionId;
        event.message = callOutBean.message;
        event.router = callOutBean.router;

        DoorSessionManager.monitorP2P(event,sessionId,recordBean);
        return callOutBean.message.getSession_id();
    }

    /**
     * 呼叫指定设备
     */
    private static IntercomManager.Intercom callout(String familyDockSn, CallOutBean callOutBean){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyDockSn);
        if(intercom == null){
            return null;
        }
        intercom.sessionManager.callout(callOutBean.router,callOutBean.netClient,callOutBean.message);
        return intercom;
    }

    /**
     * 接收通话,一般在 onInvite 中调用
     */
    public static void accept(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message){
        if(intercom != null){
            intercom.sessionManager.accept(router,netClient,message);
        }
    }

    public static void decline(IntercomManager.Intercom intercom, int router, NetClient netClient,
                               IntercomMessage message, int result){
        if (intercom != null) {
            intercom.sessionManager.decline(router, netClient, message, result);
        }
    }

    /**
     * 接听通话
     */
    public static void pickUp(IntercomManager.Intercom intercom, String sessionId){
        if(intercom != null){
            intercom.sessionManager.pickUp(sessionId);
            DoorSessionManager.pickUp(sessionId);
        }
    }

    /**
     * 挂断通话
     */
    public static void hangUp(IntercomManager.Intercom intercom, String sessionId, int messageResult){
        if(intercom != null){
            intercom.sessionManager.hangUp(sessionId, messageResult);
            updateRemoteSurface(intercom,sessionId,null);
        }
        DoorSessionManager.hangup(sessionId);
        DoorAccessOrmUtil.updateChatHangup(sessionId,true);
    }

    /**
     * 开锁
     */
    public static void openDoor(IntercomManager.Intercom intercom, String sessionId){
        if(intercom != null){
            intercom.sessionManager.unlock(sessionId);
        }
    }

    /**
     * 播放指定session 的历史记录
     * @param hisSessionId          需要回放的历史记录session
     */
    public static void startPlayBack(RecordPlayer.RecordPlayerHandler onPlaybackListener,String hisSessionId, String videoPath){
        File file = new File(videoPath);
        if(!file.exists()){
            return;
        }
        String mediaDir = DoorKit.getOptions().doorAccessWorkDir;
        /**
         * 传入的视频文件是绝对路径，则不需要传递 media_dir
         */
        RecordPlayer.getInstance(onPlaybackListener)
                .start(mediaDir,hisSessionId,videoPath);
        DoorSessionManager.addPlayBack(hisSessionId);
    }

    /**
     * 播放指定session 的历史记录
     * @param hisSessionId          需要回放的历史记录session
     */
    public static void stopPlayBack(String hisSessionId){
        RecordPlayer.getInstance(null)
                .stop();
        RecordPlayer.getInstance(null)
                .release();
        DoorSessionManager.hangup(hisSessionId);
    }

    /**
     * 播放指定session 的历史记录
     * @param hisSessionId          需要回放的历史记录session
     */
    public static void seekPlayBack(String hisSessionId,int seek){
        RecordPlayer.getInstance(null)
                .seek(seek);
    }

    public static void removePlayBackListener(RecordPlayer.RecordPlayerHandler handler){
        RecordPlayer.getInstance(null)
                .removeHandler(handler);
    }

    /**
     * 启用/禁用 本地音频
     * @param sessionId         当前的会话id
     * @param isEnabled         启用/禁用
     */
    public static void enableLocalAudio(String familyDockSn, String sessionId, boolean isEnabled){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyDockSn);
        if(intercom != null){
            intercom.sessionManager.enableAudio(sessionId,true,isEnabled);
        }
    }

    /**
     * 启用/禁用 本地视频
     * @param sessionId         当前的会话id
     * @param isEnabled         启用/禁用
     */
    public static void enableLocalVideo(String familyDockSn, String sessionId, boolean isEnabled){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyDockSn);
        if(intercom != null){
            intercom.sessionManager.enableVideo(sessionId,isEnabled);
        }
    }

    /**
     * 启用/禁用 对方音频
     * @param sessionId         当前的会话id
     * @param isEnabled         启用/禁用
     */
    public static void enableRemoteAudio(String familyDockSn, String sessionId, boolean isEnabled){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyDockSn);
        if(intercom != null){
            intercom.sessionManager.enableAudio(sessionId,false,isEnabled);
        }
    }

    /**
     * 更新播放历史记录的Surface
     * @param hisSessionId      回放历史记录的session
     */
    public static void updatePlayBackSurface(String hisSessionId, SurfaceView surfaceView){
        RecordPlayer.getInstance(null)
                .updateSurface(surfaceView == null ? null : surfaceView.getHolder().getSurface());
    }

    /**
     * 通话时更新本地Surface
     */
    public static void updateLocalSurface(SurfaceView surfaceView){
        IntercomManager.getInstance().updatePreviewSurface(surfaceView == null ? null : surfaceView.getHolder().getSurface());
    }

    /**
     * 通话时更新对方 Surface
     */
    public static void updateRemoteSurface(IntercomManager.Intercom intercom, String sessionId, SurfaceView surfaceView){
        if(intercom == null){
            return;
        }
        JXLogUtil.logW("updateRemoteSurface session = " + sessionId + " surfaceView = " + surfaceView);
        intercom.updateSurface(sessionId,surfaceView == null ? null : surfaceView.getHolder().getSurface());
    }

    /**
     * 监听到网络变化后重启所有Intercom 的 proxy
     */
    public static void reStartAllProxy(){
        Collection<IntercomManager.Intercom> intercoms = IntercomManager.getInstance().getAllIntercom();
        List<IntercomManager.Intercom> tempList = new ArrayList<>(intercoms);
        for(IntercomManager.Intercom intercom : tempList){
            intercom.stopProxy();
            intercom.startProxy(DoorConfigs.getProxyConfig());
        }
    }

    /**
     * 停止所有Intercom 的 proxy
     */
    public static void stopAllProxy(){
        Collection<IntercomManager.Intercom> intercoms = IntercomManager.getInstance().getAllIntercom();
        List<IntercomManager.Intercom> tempList = new ArrayList<>(intercoms);
        for(IntercomManager.Intercom intercom : tempList){
            intercom.stopProxy();
        }
    }

    public static void takeSnapshot(String familyId, String sessionId){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyId);
        if(intercom != null){
            intercom.sessionManager.takeSnapshot(sessionId);
        }
    }

    public static void enablePreview(boolean enable){
        IntercomManager.getInstance().enablePreview(enable);
    }

    /**
     * 是否支持修改设备名
     * @param familyId
     * @param subDevice
     * @return
     */
    public static boolean isSupportChangeDeviceName(String familyId,DoorDevice subDevice){
        return TextUtils.equals(subDevice.getCalledName(),"auto");
    }

    /**
     * 更改设备名
     * @param familyId
     * @param subDevice
     * @param jsonString 要发出去的配置
     * @return
     */
    public static boolean sendConfigure(String familyId,IntercomNetDevice.SubDevice subDevice,String jsonString){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyId);
        if(intercom == null){
            return false;
        }

        IntercomClientManager.IntercomProxy proxy = intercom.clientManager.findProxy(subDevice.getProxy_id());
        if(proxy == null){
            return false;
        }

        IntercomClientManager.IntercomProxyDescription proxyDescription = proxy.lanOnline() ? proxy.lanProxy : proxy.wanProxy;
        if(proxyDescription == null || proxyDescription.netDevice == null
                || proxyDescription.netDevice.devices == null || proxyDescription.netDevice.devices.isEmpty()){
            return false;
        }

        IntercomNetDevice.NetDeviceItem deviceItem = null;
        for(IntercomNetDevice.NetDeviceItem item : proxyDescription.netDevice.devices){
            if(item.subDevices.contains(subDevice)){
                deviceItem = item;
                break;
            }
        }

        if(deviceItem == null){
            return false;
        }

        NetClient netClient = null;
        int router = 0;
        if(proxy.lanOnline()){
            router = IntercomConstants.Router.LAN;
            netClient = proxy.lanProxy.netClient;
        }
        else {
            router = IntercomConstants.Router.PROXY;
            netClient = proxy.wanProxy.netClient;
        }

        return intercom.sendIntercomConfigure(router,netClient,deviceItem.name,null,jsonString);
    }

    /**
     * 更改设备名
     * @param familyId
     * @param subDevice
     * @param newName
     * @return
     */
    public static boolean changeDeviceName(String familyId,IntercomNetDevice.SubDevice subDevice,String newName){
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyId);
        if(intercom == null){
            return false;
        }

        IntercomClientManager.IntercomProxy proxy = intercom.clientManager.findProxy(subDevice.getProxy_id());
        if(proxy == null){
            return false;
        }

        IntercomClientManager.IntercomProxyDescription proxyDescription = proxy.lanOnline() ? proxy.lanProxy : proxy.wanProxy;
        if(proxyDescription == null || proxyDescription.netDevice == null
                || proxyDescription.netDevice.devices == null || proxyDescription.netDevice.devices.isEmpty()){
            return false;
        }

        IntercomNetDevice.NetDeviceItem deviceItem = null;
        for(IntercomNetDevice.NetDeviceItem item : proxyDescription.netDevice.devices){
            if(item.subDevices.contains(subDevice)){
                deviceItem = item;
                break;
            }
        }

        if(deviceItem == null){
            return false;
        }

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("cmd","alias");
        jsonObject.put("name", subDevice.name);
        jsonObject.put("alias", newName);

        NetClient netClient = null;
        int router = 0;
        if(proxy.lanOnline()){
            router = IntercomConstants.Router.LAN;
            netClient = proxy.lanProxy.netClient;
        }
        else {
            router = IntercomConstants.Router.PROXY;
            netClient = proxy.wanProxy.netClient;
        }

        return intercom.sendIntercomConfigure(router,netClient,deviceItem.name,null,jsonObject.toJSONString());
    }

    /**
     * 获取一体机的server端 familyId
     * @param serverWorkDir
     * @return
     */
    public static String getLocalFamilyID(String serverWorkDir){
        File loadIni = new File(serverWorkDir,"load.ini");
        if(!loadIni.exists()){
            return "";
        }
        JINIParser parser = JINIParser.loadFromFile(loadIni);
        JINIParser.Section section = parser.get("key");
        if(section == null){
            return "";
        }
        String familyId = section.get("key");
        if(!TextUtils.isEmpty(familyId)){
            familyId = IntercomManager.encodeFamilyId(false,familyId);
        }
        return familyId;
    }

    /**
     * 获取一体机的server端 familyId
     * @param serverWorkDir
     * @return
     */
    public static String getLocalButtonKey(String serverWorkDir){
        File loadIni = new File(serverWorkDir,"load.ini");
        if(!loadIni.exists()){
            return "";
        }
        JINIParser parser = JINIParser.loadFromFile(loadIni);
        JINIParser.Section section = parser.get("key");
        return section.get("button_key");
    }

    public static String startRecord(String familyID,String sessionId) {
        long nowTime = System.currentTimeMillis();
        List<DoorRecordBean> recordBeen = DoorAccessOrmUtil.queryRecordBySession(sessionId);
        DoorRecordBean recordBean = null;
        if(recordBeen == null || recordBeen.size() == 0){
            recordBean = DoorSessionManager.getCurrentRecordBean(sessionId);
            if(recordBean == null){
                return null;
            }
        }else{
            recordBean = recordBeen.get(0);
        }
        String videoSession = recordBean.addNewVideoRecord(sessionId,nowTime,recordBean.show_name,recordBean.name);
        IntercomManager.Intercom  intercom = IntercomManager.getInstance().getIntercom(familyID);
        if(intercom == null){
            return null;
        }
        intercom.sessionManager.startRecord(sessionId,videoSession);
        /**
         * 需要对每次的录像生成一个图片
         */
        takeSnapshot(familyID,sessionId);
        return videoSession;
    }

    public static boolean stopRecord(String familyID,String sessionId, String recordSessionId) {
        List<RecordVideoBean> videoBean = DoorAccessOrmUtil.queryRecordVideoBeanBySession(recordSessionId);
        if(videoBean == null || videoBean.size() == 0){
            return false;
        }
        RecordVideoBean recordVideoBean = videoBean.get(0);
        recordVideoBean.chatTime = System.currentTimeMillis() - recordVideoBean.startTime;
        DoorAccessOrmUtil.update(recordVideoBean);
        IntercomManager.Intercom  intercom = IntercomManager.getInstance().getIntercom(familyID);
        if(intercom == null){
            return false;
        }
        return intercom.sessionManager.stopRecord(sessionId);
    }
}
