package com.jingxi.smartlife.pad.sdk.doorAccess.base;

import android.text.TextUtils;

import com.intercom.sdk.IntercomConstants;
import com.intercom.sdk.IntercomManager;
import com.intercom.sdk.SecurityMessage;
import com.intercom.sdk.SmartHomeManager;
import com.intercom.sdk.SmartHomeMessage;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.SecurityStateBean;

import java.util.ArrayList;
import java.util.List;

/**
 * @author bjj
 * SecurityAlarmDialog
 * SecuritySettingDialog
 */
public class DoorSecurityUtil {
    private static List<OnSecurityChangedListener> listeners = new ArrayList<>();

    public static void registerListener(OnSecurityChangedListener listener){
        if(listeners.contains(listener)){
            return;
        }
        listeners.add(listener);
    }

    public static void unRegisterLister(OnSecurityChangedListener listener){
        listeners.remove(listener);
    }


    public static void onSecurityMessage(IntercomManager.Intercom intercom, SmartHomeManager.SecurityDevice device, SmartHomeMessage message){
        if (TextUtils.equals(message.getCmd(), IntercomConstants.kSmarthomeState)
                || TextUtils.equals(message.getCmd(), IntercomConstants.kSmarthomeDevice)
                || TextUtils.equals(message.getCmd(), IntercomConstants.kSmarthomeSwitch)
                || TextUtils.equals(message.getCmd(), IntercomConstants.kSmarthomeQuery)) {
            int state = device.deviceConfig().security_state;
            noticeState(intercom.id,state, TextUtils.equals(message.getCmd(), IntercomConstants.kSmarthomeQuery));
        }
        else if (TextUtils.equals(message.getCmd(), IntercomConstants.kSmarthomeCancel)) {
            noticeCancelAlarm(intercom,device);
        }
    }

    public static void onSecurityAlarm(IntercomManager.Intercom intercom, SmartHomeManager.SecurityDevice device, SmartHomeMessage smartHomeMessage, SecurityMessage securityMessage) {
        if(securityMessage.getCmd().equalsIgnoreCase(DoorFinal.SECURITY_ALERT)){
            noticeAlarm(intercom,securityMessage.getState(),device);
        }
    }


    /**
     * 切换安防状态
     */
    public static void switchState(String familyDockSn,boolean on){
//         {"ack":false,"broadcast":false,"cmd":"switch","content":"eyJzZWN1cml0eV9zdGF0ZSI6MH0K","from":"1497234257325658","proxy_id":"1496136497079886","result":0,"sn":"","source":4,"to":"security"}
//         其中base64为：
//         {"security_state":1}
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyDockSn);
        if(intercom == null){
            return;
        }
        SmartHomeManager smartHomeManager = intercom.smartHomeManager;
        if(smartHomeManager == null){
            return;
        }
        List<SmartHomeManager.SecurityDevice> devices = smartHomeManager.devices();
        if(devices.isEmpty()){
            return;
        }
        for(SmartHomeManager.SecurityDevice device : devices){
            smartHomeManager.switchDefence(device,on);
        }
    }

    /**
     * 查询安防状态
     */
    public static int queryState(String familyDockSn){
        //{"ack":false,"broadcast":false,"cmd":"query","from":"1497234257325658","proxy_id":"1496136497079886","result":0,"sn":"","source":4,"to":"security"}
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyDockSn);
        if(intercom == null){
            return SecurityStateBean.STATE_OFFLINE;
        }
        SmartHomeManager smartHomeManager = intercom.smartHomeManager;
        if(smartHomeManager == null){
            return SecurityStateBean.STATE_OFFLINE;
        }
        List<SmartHomeManager.SecurityDevice> devices = smartHomeManager.devices();
        if(devices.isEmpty()){
            noticeState(familyDockSn, SecurityStateBean.STATE_OFFLINE,true);
            return SecurityStateBean.STATE_OFFLINE;
        }
        for(SmartHomeManager.SecurityDevice device : devices){
            smartHomeManager.queryState(device);
        }
        return devices.get(0).deviceConfig().security_state;
    }

    /**
     * 取消报警
     */
    public static void cancelWarning(String familyDockSn){
        //{"ack":false,"broadcast":false,"cmd":"cancel","from":"1497234257325658","proxy_id":"1496136497079886","result":0,"sn":"","source":4,"to":"security"}
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyDockSn);
        if(intercom == null){
            return;
        }
        SmartHomeManager smartHomeManager = intercom.smartHomeManager;
        if(smartHomeManager == null){
            return;
        }
        List<SmartHomeManager.SecurityDevice> devices = smartHomeManager.devices();
        if(devices.isEmpty()){
            return;
        }
        for(SmartHomeManager.SecurityDevice device : devices){
            smartHomeManager.turnOffAlarm(device);
        }
    }

    private static void noticeAlarm(IntercomManager.Intercom intercom, List<SecurityMessage.StateBean> stateBeans, SmartHomeManager.SecurityDevice device){
        for(OnSecurityChangedListener listener : listeners){
            listener.onAlarm(intercom.id,stateBeans,device);
        }
    }

    private static void noticeCancelAlarm(IntercomManager.Intercom intercom, SmartHomeManager.SecurityDevice device){
        for(OnSecurityChangedListener listener : listeners){
            listener.onCancelAlarm(intercom.id,device);
        }
    }

    private static void noticeState(String familyDockSn, int state, boolean isFromQuery){
        for(OnSecurityChangedListener listener : listeners){
            listener.onStateChanged(familyDockSn,state,isFromQuery);
        }
    }

    public interface OnSecurityChangedListener{

        /**
         * 家庭安防状态   {@link SecurityStateBean#STATE_NODEFENCE} {@link SecurityStateBean#STATE_UNDEFENCE} {@link SecurityStateBean#STATE_DEFENCE}
         * @param familyDockSn
         * @param state
         * @param isFromQuery
         */
        void onStateChanged(String familyDockSn, int state, boolean isFromQuery);

        /**
         * 收到安防报警
         * @param familyDockSn
         * @param stateBeans 传感器
         * @param device     安防设备
         */
        void onAlarm(String familyDockSn,List<SecurityMessage.StateBean> stateBeans, SmartHomeManager.SecurityDevice device);

        /**
         * 报警取消
         * @param familyDockSn
         * @param device        安防设备
         */
        void onCancelAlarm(String familyDockSn, SmartHomeManager.SecurityDevice device);

    }
}
