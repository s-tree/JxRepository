package com.intercom.sdk;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

public class IntercomConfigure {

    /**
     * 整个系统初始化配置
     */
    public static class AppConf {
        /**
         * 本机产品的渠道码，如果是定制版本需要协议约定一个新的渠道码
         */
        public String app_version;

        public String channel;
        /**
         * 底层缓存的目录，最好设置在sdcard上
         * 本机临时配置文件保存在workdir/conf目录下
         */
        public String work_dir;
        /**
         * 保存访客记录得位置
         * 为了兼容旧版本，需要设置在：sdcard/data/doorkeeper/access/record
         * 全新安装无所谓，但也必须保存在sdcard中
         */
        public String media_dir;

        //日志是否保存到文件中，系统启动时，会自动生成新得日志文件名
        public boolean log_to_file;

        //日志得详细程度，debug可以设置为Info，release可以设置为fatal
        public int log_level;

        //底层用timezone来设置默认的DNS服务器地址
        //如果设备没有配置DNS（不管手工还是自动），则采用默认DNS来解析
        public String timezone;

        public AppConf(String app_version,
                       String channel,
                       String work_dir,
                       String media_dir,
                       boolean log_to_file,
                       int log_level) {
            this.app_version = app_version;
            this.channel = (channel == null || channel.isEmpty()) ? "JX" : channel;
            this.work_dir = work_dir;
            this.media_dir = media_dir;
            this.log_to_file = log_to_file;
            this.log_level = log_level;
            TimeZone zone = TimeZone.getDefault();
            if (zone != null) {
                this.timezone = zone.getDisplayName(false, TimeZone.SHORT);
            }
        }

        public String toJson() {
            Bundle bundle = new Bundle();
            bundle.putString("app_ver", this.app_version);
            bundle.putString("channel", this.channel);
            bundle.putString("work_dir", this.work_dir);
            bundle.putString("media_dir", this.media_dir);
            bundle.putBoolean("log_to_file", this.log_to_file);
            bundle.putInt("log_level", this.log_level);
            bundle.putString("timezone", this.timezone);
            return BundleToJSON.toString(bundle);
        }
    }

    /**
     * 设置本机得终端属性
     */
    public static class ClientConf {
        public int type; //NetClientTypeClient
        public int sub_type; //NetClientSubTypePad
        public String family_id;
        public String alias;
        public String button_key;
        public String pushid;
        public String sn;

        public ClientConf() {
            this.type = IntercomConstants.NetClientType.NetClientTypeClient;
            this.sub_type = IntercomConstants.NetClientSubType.NetClientSubTypePad;
            this.family_id = "";
            this.alias = "";
            this.button_key = "";
            this.pushid = "";
            this.sn = "";
        }

        public ClientConf(int type,
                          int sub_type,
                          String family_id,
                          String button_key,
                          String alias,
                          String pushid,
                          String sn) {
            this.type = type;
            this.sub_type = sub_type;
            this.family_id = family_id;
            this.button_key = button_key;
            this.alias = alias;
            this.pushid = pushid;
            this.sn = sn;
        }

        public String toJson() {
            Bundle bundle = new Bundle();
            bundle.putInt("type", this.type);
            bundle.putInt("sub_type", this.sub_type);
            bundle.putString("family_id", this.family_id);
            bundle.putString("alias", this.alias);
            bundle.putString("button_key", this.button_key);
            bundle.putString("pushid", this.pushid);
            bundle.putString("sn", this.sn);
            return BundleToJSON.toString(bundle);
        }
    }

    /**
     * 这里配置系统中保留端口
     * 这些端口已经固定分配给指定的单元，我们在通讯的时候，需要动态分配端口，会跳过这些端口
     * 防止影响其他模块的正常功能
     */
    public static class PortConf {
        /**
         * port range，是本模块分配udp，tcp，以及媒体端口的范围
         */
        public String port_range;
        public String tcp_reserver;
        public String udp_reserver;

        public PortConf() {
            this.port_range = "30000,34000,35000";
            this.tcp_reserver = "";
            this.udp_reserver = "";
        }

        public PortConf(String port_range, String tcp_reserver, String udp_reserver) {
            if (port_range == null)
                this.port_range = "30000,34000,35000";
            else
                this.port_range = port_range;
            this.tcp_reserver = tcp_reserver;
            this.udp_reserver = udp_reserver;
        }

        public String toJson() {
            Bundle bundle = new Bundle();
            bundle.putString("port_range", this.port_range);
            bundle.putString("tcp", this.tcp_reserver);
            bundle.putString("udp", this.udp_reserver);
            return BundleToJSON.toString(bundle);
        }
    }

    /**
     * 一体机，由终端来控制MCU
     * 配置可以从代理配置中读取
     * NOTE:在android上，BUS名称必须为抽象命令空间
     * 就是在名称之前加上‘@’符号，底层自动转换为抽象命令空间
     * https://blog.csdn.net/qq_35904259/article/details/61204130
     */
    public static class MCUConf {
        /**
         * 没有不包含路由的底座，应该不需要开启看门狗功能
         * 直接置空即可
         */
        public String watchdog; //"60000:10000:1"
        public String serial; ///dev/ttyS1:115200
        public String security_bus_name;

        public int level = -1;
        public int baud_rate;
        public String threshold;
        public int recheck_area_delay;
        public String recheck_area_type;

        public MCUConf(String watchdog,
                       String serial,
                       String security_bus_name) {
            this.watchdog = watchdog;
            this.serial = serial;
            this.security_bus_name = security_bus_name;
        }

        public MCUConf(String watchdog,
                       String serial,
                       String security_bus_name,
                       int level,
                       int baud_rate,
                       String threshold,
                       int recheck_area_delay,
                       String recheck_area_type) {
            this.watchdog = watchdog;
            this.serial = serial;
            this.security_bus_name = security_bus_name;
            this.level = level;
            this.baud_rate = baud_rate;
            this.threshold = threshold;
            this.recheck_area_delay = recheck_area_delay;
            this.recheck_area_type = recheck_area_type;
        }

        public String toJson() {
            Bundle bundle = new Bundle();
            bundle.putString("watchdog", this.watchdog);
            bundle.putString("serial", this.serial);
            bundle.putString("security_bus_name", this.security_bus_name);
            if(level != -1){
                bundle.putInt("level", this.level);
                bundle.putInt("baud_rate", this.baud_rate);
                bundle.putString("threshold", this.threshold);
                bundle.putInt("recheck_area_delay", this.recheck_area_delay);
                bundle.putString("recheck_area_type", this.recheck_area_type);
            }
            return BundleToJSON.toString(bundle);
        }
    }

    public static class ProxyConf {
        public int lan_proxy_broadcast_port;
        public String multicast_address;
        public int heartbeat_interval;
        public boolean enable_lan_broadcast;
        public boolean lan_discovery_enable;
        public String proxy_server;
        public String ssl_cert_path;
        public String ssl_cert_private_key;
        public String lan_broadcast_exclude_interface;
        public boolean master_device;

        public ProxyConf() {
            this.lan_proxy_broadcast_port = 10000;
            this.multicast_address = "238.18.18.1";
            this.heartbeat_interval = 60;
            this.enable_lan_broadcast = true;
            this.lan_discovery_enable = true;
            this.proxy_server = "";
            this.ssl_cert_path = "";
            this.ssl_cert_private_key = "";
            this.lan_broadcast_exclude_interface = "eth1";
            this.master_device = false;
        }

        public ProxyConf(int lan_proxy_broadcast_port,
                         String multicast_address,
                         int heartbeat_interval,
                         boolean enable_lan_broadcast,
                         boolean lan_discovery_enable,
                         String proxy_server,
                         String ssl_cert_path,
                         String ssl_cert_private_key) {
            this.lan_proxy_broadcast_port = lan_proxy_broadcast_port;
            this.multicast_address = multicast_address;
            this.heartbeat_interval = heartbeat_interval;
            this.enable_lan_broadcast = enable_lan_broadcast;
            this.lan_discovery_enable = lan_discovery_enable;
            this.proxy_server = proxy_server;
            this.ssl_cert_path = ssl_cert_path;
            this.ssl_cert_private_key = ssl_cert_private_key;
            this.lan_broadcast_exclude_interface = "eth1";
            this.master_device = false;
        }

        public String toJson() {
            Bundle bundle = new Bundle();
            bundle.putInt("lan_proxy_broadcast_port", this.lan_proxy_broadcast_port);
            bundle.putString("multicast_address", this.multicast_address);
            bundle.putInt("heartbeat_interval", this.heartbeat_interval);
            bundle.putBoolean("enable_lan_broadcast", this.enable_lan_broadcast);
            bundle.putBoolean("lan_discovery_enable", this.lan_discovery_enable);
            bundle.putString("proxy_server", this.proxy_server);
            bundle.putString("lan_broadcast_exclude_interface", this.lan_broadcast_exclude_interface);
            bundle.putBoolean("master_device", this.master_device);
            //如果需要支持TLS，需要提供证书位置和令牌
            bundle.putString("ssl_cert_path", this.ssl_cert_path);
            bundle.putString("ssl_cert_private_key", this.ssl_cert_private_key);
            return BundleToJSON.toString(bundle);
        }
    }

    public static class ServerConfig {
        public String url;
        public String auth_user;
        public String auth_pwd;
        public String cache_filename;
        public int retry_interval;

        public ServerConfig(String url,
                            String auth_user,
                            String auth_pwd,
                            String cache_filename,
                            int retry_interval) {
            this.url = url;
            this.auth_user = auth_user;
            this.auth_pwd = auth_pwd;
            if (cache_filename == null || cache_filename.length() < 1) {
                this.cache_filename = "client_sip.json";
            } else {
                this.cache_filename = cache_filename;
            }
            this.retry_interval = retry_interval;
        }

        public String toJson() {
            Bundle bundle = new Bundle();
            bundle.putString("url", this.url);
            bundle.putString("user", this.auth_user);
            bundle.putString("pwd", this.auth_pwd);
            bundle.putString("file", this.cache_filename);
            bundle.putInt("interval", this.retry_interval);
            return BundleToJSON.toString(bundle);
        }
    }

    public static class CaptureConfig {
        public int capture_video_width;
        public int capture_video_height;
        public int capture_video_fps;
        public int capture_video_format;

        public int camera_type;
        public String camera_name;
        public boolean uvc;
        public int max_cache;

        public boolean screen_portrait;

        public CaptureConfig() {
            this.capture_video_width = 640;
            this.capture_video_height = 480;
            this.capture_video_fps = 25;
            this.capture_video_format = 7;////PIXEL_FORMAT_NV21
            this.camera_type = 1;
            this.camera_name = IntercomConstants.kFrontCameraName;
            this.uvc = false;
            this.max_cache = 4;
            this.screen_portrait = false;
        }

        public Bundle ToBundle() {
            Bundle capture = new Bundle();
            capture.putInt("width", capture_video_width);
            capture.putInt("height", capture_video_height);
            capture.putInt("fps", capture_video_fps);
            capture.putInt("format", capture_video_format);

            Bundle camera_name_dict = new Bundle();
            camera_name_dict.putInt("type", camera_type);
            camera_name_dict.putString("value", camera_name);
            capture.putBundle("camera_name", camera_name_dict);
            capture.putBoolean("uvc", this.uvc);
            capture.putInt("cache", this.max_cache);
            capture.putBoolean("screen_portrait", this.screen_portrait);
            return capture;
        }

        public String ToString() {
            Bundle bundle = ToBundle();
            return BundleToJSON.toString(bundle);
        }
    }

    public static class VideoCodecConfig {
        public int video_encode_profile;
        public int video_encode_avg_bps;
        public int video_encode_max_bps;
        public int video_encode_gopsize;
        public double video_encode_qcompress;
        public double video_encode_qblur;
        public int video_encode_qmin;
        public int video_encode_qmax;
        public int video_encode_crf;
        public int video_encode_codec;
        public int video_frame_mtu;
        public String video_encode_preset;
        public String video_encode_tune;
        public int video_encode_codec_width;
        public int video_encode_codec_height;
        public int frame_rate;

        public int media_codec_encoder_color_format;

        public int video_decode_engine;

        public int video_encode_engine;

        public VideoCodecConfig() {
            //FF_PROFILE_H264_BASELINE，兼容性好
            this.video_encode_profile = 0;
            //平均码率，比如： 256000，我们不用码率来控制，设置为0
            //如果通过码率来控制，将crf = 0;
            this.video_encode_avg_bps = 0;
            //最大码率，比如： 256000
            this.video_encode_max_bps = 0;
            //关键帧的间隔，我们设置30帧包含一个关键帧，网络比较理想的情况话
            //这个值越大越节省带宽，经常的，设置为300
            //但是越大的值丢包恢复需要越久的时间
            this.video_encode_gopsize = 30;

            this.video_encode_qcompress = 0;
            this.video_encode_qblur = 0;

            /**
             * 我们正是使用crf来控制编码，优先保证画面质量，取值范围(0-51)
             * 0:无损压缩，数值越大，质量越差，生成的码流越小。
             * 18-28是一个合理的范围，18被认为视觉无损。
             * 我们默认采用23，质量很好，但码流略大
             */
            this.video_encode_crf = 23;
            this.video_encode_qmin = 10;
            this.video_encode_qmax = 30;

            //kCodecH264,指定编码格式, 1: H264
            this.video_encode_codec = 1;
            //控制编码器输出NALU大小,不超过UDP的MTU范围
            this.video_frame_mtu = 0;

            this.video_encode_preset = "veryfast";
            this.video_encode_tune = "animation+zerolatency";

            //我们可以指定编码视频的尺寸，可以低于摄像头尺寸
            this.video_encode_codec_width = 640;
            this.video_encode_codec_height = 480;
            this.frame_rate = 25;

            this.media_codec_encoder_color_format = 0x13;

            //视频编码和解码引擎,0: FFMPEG, 1: MediaCodec, 2: MPP
            //移动端使用FFMPEG，平板根据平台可以选择使用 FFMPEG，或者MediaCodec，只有经过仔细验证，才可以使用MPP
            this.video_decode_engine = 0;
            this.video_encode_engine = 0;
        }

        public Bundle ToBundle() {
            Bundle encoder = new Bundle();

            encoder.putInt("profile", video_encode_profile);
            encoder.putInt("avg_bps", video_encode_avg_bps);
            encoder.putInt("max_bps", video_encode_max_bps);
            encoder.putInt("gop_size", video_encode_gopsize);
            encoder.putDouble("qcompress", video_encode_qcompress);
            encoder.putDouble("qblur", video_encode_qblur);
            encoder.putInt("qmin", video_encode_qmin);
            encoder.putInt("qmax", video_encode_qmax);
            encoder.putInt("crf", video_encode_crf);
            encoder.putString("preset", video_encode_preset);
            encoder.putString("tune", video_encode_tune);
            encoder.putInt("codec", video_encode_codec);
            encoder.putInt("mtu", video_frame_mtu);
            encoder.putInt("codec_width", video_encode_codec_width);
            encoder.putInt("codec_height", video_encode_codec_height);
            encoder.putInt("fps", this.frame_rate);
            encoder.putInt("media_codec_encoder_color_format", this.media_codec_encoder_color_format);
            encoder.putInt("video_decode_engine", this.video_decode_engine);
            encoder.putInt("video_encode_engine", this.video_encode_engine);
            return encoder;
        }

        public String ToString() {
            Bundle bundle = ToBundle();
            return BundleToJSON.toString(bundle);
        }
    }

    public static class IntercomConfig {
        public CaptureConfig capture_conf;
        public VideoCodecConfig video_codec_conf;

        public int audio_samplerate;
        public int audio_channels;
        public int bits_per_sample;
        public boolean disable_aec;
        public int aec_latency;
        public int audio_engine;

        /**
         * 控制音频延迟,一般情况可以设置80000~120000,表示音频延迟缓冲区最大时间长度
         * 如果为了保证最低延迟，可以设置为0,此刻需要保证是局域网连接室外机或者直连
         */
        public long max_audio_delay_us;

        public boolean audio_low_latency;

        /**
         * 发送到对方的音频增益参数 [1~30?],0:do not agc
         */
        public int audio_play_agc_level;
        /**
         * 发送到对方的音频增益参数 [1~30?],0:do not agc
         */
        public int audio_send_agc_level;

        //please see webrtc: WebRtcAgc_config_t: default is 9
        public int audio_play_agc_compression_gain_db;

        //please see webrtc: WebRtcAgc_config_t: default is 9
        public int audio_send_agc_compression_gain_db;

        public boolean audio_play_denoise;

        public boolean audio_send_denoise;

        /**
         * 黑屏的参数(R,G,B,A):"128,128,128,0
         */
        public String blank_color;

        /**
         * 会话初始化最长等待时间，默认为60s即可
         */
        public int max_session_wait_time;

        /**
         * 楼宇对讲会话最长持续时间，默认为200s即可
         */
        public int intercom_max_session_connect_time;

        /**
         * 特殊设备: 目前就是p2p,ext
         */
        public String special_p2p_device;

        public String speical_ext_device;

        public IntercomConfig(CaptureConfig capture_conf, VideoCodecConfig video_codec_conf) {

            this.capture_conf = capture_conf;
            this.video_codec_conf = video_codec_conf;

            this.audio_samplerate = 8000;
            this.audio_channels = 1;
            this.bits_per_sample = 16;

            /**
             * 底层在语音对讲的时候，首先通过WebRtcAudioEffects来判断Framework是否提供AEC能力
             * 如果没有提供，则使用软件AEC能力。
             */
            this.disable_aec = false;

            /**
             * 经过测试，RT3288延时 80MS，MIC功率调制到 30%(tinymix 16 30)
             * 室外机音量在80%左右
             * RK3288 放音增益16000，同时去噪
             * 效果比较好
             */
            this.aec_latency = 80;

            this.audio_engine = IntercomConstants.AudioEngine.AudioEngine_JAVA;

            this.audio_play_agc_level = 0;
            this.audio_send_agc_level = 0;

            this.audio_play_agc_compression_gain_db = 20;

            this.audio_send_agc_compression_gain_db = 20;

            this.audio_play_denoise = false;
            this.audio_send_denoise = false;

            /**
             * 一般，我们推荐120000微秒，这样可以兼具到云端传输和局域网传输，均能保证音频品质
             * 只在产品评测的时候可以使用40000，会显著的降低音频延迟，但如果这个值太低，可能导致
             * 声音抖动
             */
            this.max_audio_delay_us = 120000;

            /**
             * 音频低延迟，需要下列条件才能使用:
             * 1)室外机与室内机局域网连接，中间尽量少走交换机或者路由器，理想情况就是直连
             * 2)产品评测时要求尽可能地的音频延迟
             * audio_low_latency=true，网络层将不再使用Jitter buffer缓冲，直接从网络层收包并实时交付音频播放器
             * 如果网络连接比较复杂，将可能导致乱序的问题，此刻会影响音频品质
             */

            this.audio_low_latency = false;

            this.blank_color = "128.0.0.0";

            //通话等待时长(秒)
            this.max_session_wait_time = 60;

            //门禁设备最长连接时间(秒),一般不会超过300秒
            //全视通室外机并未限制通话时长，我们在代理中设置了最长通话时间
            this.intercom_max_session_connect_time = 300;

            //户户通设备，[名称,LAN最长通话时间(秒),WAN最长通话时间(秒)]
            this.special_p2p_device = "p2p,1800,300";
            //室内通设备，[名称,LAN最长通话时间(秒),WAN最长通话时间(秒)]
            //考虑到云端资源的占用，可以对云端通话时长进行不一样的限制
            //LAN通话，最长可以允许24小时
            this.speical_ext_device = "ext,2592000,86400";
        }

        public String toJson() {
            if (video_codec_conf.video_encode_codec_width < 1
                    || video_codec_conf.video_encode_codec_height < 1) {
                video_codec_conf.video_encode_codec_width = this.capture_conf.capture_video_width;
                video_codec_conf.video_encode_codec_height = this.capture_conf.capture_video_height;
            }
            if (video_codec_conf.frame_rate < 1) {
                video_codec_conf.frame_rate = this.capture_conf.capture_video_fps;
            }

            Bundle device_audio_conf = new Bundle();
            device_audio_conf.putInt("sample_rate", audio_samplerate);
            device_audio_conf.putInt("channels", audio_channels);
            device_audio_conf.putInt("bits_per_sample", bits_per_sample);
            device_audio_conf.putBoolean("disable_aec", disable_aec);
            device_audio_conf.putInt("aec_latency", this.aec_latency);
            device_audio_conf.putInt("audio_engine", this.audio_engine);
            device_audio_conf.putLong("max_audio_delay_us", this.max_audio_delay_us);
            device_audio_conf.putBoolean("audio_low_latency", this.audio_low_latency);

            Bundle dictionary = new Bundle();
            dictionary.putInt("audio_play_agc_level", audio_play_agc_level);
            dictionary.putInt("audio_send_agc_level", audio_send_agc_level);
            dictionary.putInt("audio_play_agc_compression_gain_db", audio_play_agc_compression_gain_db);
            dictionary.putInt("audio_send_agc_compression_gain_db", audio_send_agc_compression_gain_db);
            dictionary.putBoolean("audio_play_denoise", audio_play_denoise);
            dictionary.putBoolean("audio_send_denoise", audio_send_denoise);
            dictionary.putString("blank_color", blank_color);
            dictionary.putInt("max_session_wait_time", max_session_wait_time);
            dictionary.putInt("intercom_max_session_connect_time", intercom_max_session_connect_time);

            dictionary.putString("special_p2p_device", this.special_p2p_device);
            dictionary.putString("speical_ext_device", this.speical_ext_device);
            dictionary.putBundle("capture", this.capture_conf.ToBundle());
            dictionary.putBundle("video_codec", this.video_codec_conf.ToBundle());
            dictionary.putBundle("device_audio", device_audio_conf);
            return BundleToJSON.toString(dictionary);
        }
    }

    public static class SipAuth {
        public String username;
        public String userid;
        public String passwd;

        public SipAuth() {
            this.username = "";
            this.userid = "";
            this.passwd = "";
        }
    }

    public static class SipProxy {
        public String proxy;
        public String identity;
        public String route;
        public String contact_param;
        public int expires;

        public SipProxy() {
            proxy = "";
            identity = "";
            route = "";
            contact_param = "";
            expires = 300;
        }
    }

    public static class SipConfig {
        public int session_expires;
        public boolean use_rport;
        public boolean reuse_authorization;
        public boolean expire_old_registration_contacts;
        public int dscp;
        public boolean use_ipv6;
        public int sip_port_range;
        public int sip_listen_port;
        public String transport;
        public boolean one_matching_codec;
        public boolean use_double_registrations;
        public boolean add_dates;
        public int keepalive_period;
        public boolean tcp_tls_keepalive;
        public String user_agent;
        public boolean use_exosip2_version;
        public String default_contact;
        public int max_calls;
        public String answer_options;
        public boolean prevent_colliding_calls;
        public String cert_password;

        /**
         * 支持多个账号
         */
        public List<SipAuth> auths;
        public List<SipProxy> proxies;

        /**
         * ICE 配置，一般只需要配置 stun_server
         */
        public String turn_server;
        public String turn_username;
        public String turn_pwd;
        public String turn_auth_type;
        public String turn_pwd_type;
        public String turn_conn_type;
        public String turn_auth_realm;
        public String stun_server;
        public boolean loopaddr;
        public boolean aggressive;

        public SipConfig() {
            this.session_expires = 0;
            this.use_rport = true;
            this.reuse_authorization = false;
            this.expire_old_registration_contacts = false;
            this.dscp = 0x1a;
            this.use_ipv6 = false;
            this.sip_port_range = 0;
            this.sip_listen_port = 0;
            this.transport = "UDP"; //UDP | TCP
            this.one_matching_codec = false;
            this.use_double_registrations = false;
            this.add_dates = false;
            this.keepalive_period = 300;
            this.tcp_tls_keepalive = false;
            this.user_agent = "jxhousekeeper/1.0";
            this.use_exosip2_version = true;
            this.default_contact = "";
            this.max_calls = 10;
            this.answer_options = "";
            this.prevent_colliding_calls = false;
            this.auths = new ArrayList<>();
            this.proxies = new ArrayList<>();

            this.turn_server = "";
            this.turn_username = "";
            this.turn_pwd = "";
            this.turn_auth_type = "static";
            this.turn_pwd_type = "plain";
            this.turn_conn_type = "udp";
            this.turn_auth_realm = "";
            this.stun_server = "";
            this.loopaddr = true;
            this.aggressive = true;
        }

        public SipConfig(String user_id,
                         String password,
                         String transport,
                         String sip_server,
                         int server_port,
                         int stun_port,
                         boolean use_ice) {
            String proxy_name = "";
            String identity = "";
            String stun_server = "";

            if (sip_server != null) {
                proxy_name = String.format("<sip:%s:%d>", sip_server, server_port);
                identity = String.format("sip:%s@%s:%d", user_id, sip_server, server_port);
                stun_server = String.format("%s:%d", sip_server, stun_port);
            }
            if (transport != null && !transport.equalsIgnoreCase("UDP")) {
                this.transport = transport;
            }
            this.session_expires = 0;
            this.use_rport = true;
            this.reuse_authorization = false;
            this.expire_old_registration_contacts = false;
            this.dscp = 0x1a;
            this.use_ipv6 = false;
            this.sip_port_range = 0;
            this.sip_listen_port = 0;
            this.one_matching_codec = false;
            this.use_double_registrations = false;
            this.add_dates = false;
            this.keepalive_period = 300;
            this.tcp_tls_keepalive = false;
            this.user_agent = "jxhousekeeper/1.0";
            this.use_exosip2_version = true;
            this.default_contact = "";
            this.max_calls = 10;
            this.answer_options = "";
            this.prevent_colliding_calls = false;
            this.auths = new ArrayList<>();
            this.proxies = new ArrayList<>();
            if (user_id != null) {
                SipAuth auth = new SipAuth();
                auth.userid = user_id;
                auth.username = user_id;
                auth.passwd = password;
                this.auths.add(auth);
            }

            if (!proxy_name.isEmpty()) {
                SipProxy proxy = new SipProxy();
                proxy.proxy = proxy_name;
                proxy.identity = identity;
                this.proxies.add(proxy);
            }
            if (use_ice) {
                this.turn_server = "";
                this.turn_username = "";
                this.turn_pwd = "";
                this.turn_auth_type = "static";
                this.turn_pwd_type = "plain";
                this.turn_conn_type = "udp";
                this.turn_auth_realm = "";
                this.stun_server = stun_server;
                this.loopaddr = true;
                this.aggressive = true;
            }
        }

        public String toJson() {

            ArrayList<Bundle> auth_array = new ArrayList<>();

            for (SipAuth auth : auths) {
                Bundle dict = new Bundle();
                dict.putString("username", auth.username);
                dict.putString("userid", auth.userid);
                dict.putString("passwd", auth.passwd);
                auth_array.add(dict);
            }

            ArrayList<Bundle> proxy_array = new ArrayList<>();
            for (SipProxy proxy : proxies) {
                Bundle dict = new Bundle();
                dict.putString("proxy", proxy.proxy);
                dict.putString("identity", proxy.identity);
                dict.putString("route", proxy.route);
                dict.putString("contact_param", proxy.contact_param);
                dict.putInt("expires", proxy.expires);
                proxy_array.add(dict);
            }

            Bundle sip = new Bundle();
            sip.putInt("session_expires", this.session_expires);
            sip.putBoolean("use_rport", this.use_rport);
            sip.putBoolean("reuse_authorization", this.reuse_authorization);
            sip.putBoolean("expire_old_registration_contacts", this.expire_old_registration_contacts);
            sip.putInt("dscp", this.dscp);
            sip.putBoolean("use_ipv6", this.use_ipv6);
            sip.putInt("sip_port_range", this.sip_port_range);
            sip.putInt("sip_listen_port", this.sip_listen_port);
            sip.putString("transport", this.transport);
            sip.putBoolean("one_matching_codec", this.one_matching_codec);
            sip.putBoolean("use_double_registrations", this.use_double_registrations);
            sip.putBoolean("add_dates", this.add_dates);
            sip.putInt("keepalive_period", this.keepalive_period);
            sip.putBoolean("tcp_tls_keepalive", this.tcp_tls_keepalive);
            sip.putString("user_agent", this.user_agent);
            sip.putBoolean("use_exosip2_version", this.use_exosip2_version);
            sip.putString("default_contact", this.default_contact);
            sip.putInt("max_calls", this.max_calls);
            sip.putString("answer_options", this.answer_options);
            sip.putBoolean("prevent_colliding_calls", this.prevent_colliding_calls);

            if (auth_array.size() > 0) {
                sip.putSerializable("auth", auth_array);
            }
            if (proxy_array.size() > 0) {
                sip.putSerializable("proxy", proxy_array);
            }

            Bundle conf = new Bundle();
            if (!this.stun_server.isEmpty()) {
                Bundle ice = new Bundle();
                ice.putString("turn_server", this.turn_server);
                ice.putString("turn_username", this.turn_username);
                ice.putString("turn_pwd", this.turn_pwd);
                ice.putString("turn_auth_type", this.turn_auth_type);
                ice.putString("turn_pwd_type", this.turn_pwd_type);
                ice.putString("turn_conn_type", this.turn_conn_type);
                ice.putString("turn_auth_realm", this.turn_auth_realm);
                ice.putString("stun_server", this.stun_server);
                ice.putBoolean("loopaddr", this.loopaddr);
                ice.putBoolean("aggressive", this.aggressive);
                conf.putBundle("ice", ice);
            }

            conf.putBundle("sip", sip);

            if (this.cert_password != null && !this.cert_password.isEmpty()) {
                Bundle cert = new Bundle();
                cert.putString("pwd", this.cert_password);
                conf.putBundle("cert", cert);
            }
            return BundleToJSON.toString(conf);
        }
    }
}
