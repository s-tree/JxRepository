package com.jingxi.smartlife.pad.sdk.doorAccess.base.bean;

import android.text.TextUtils;

/**
 * Created by Administrator on 2018/1/8.
 */

public class SecurityStateBean {

    /**
     * 无设备
     */
    public static final int STATE_NODEFENCE = -1;

    /**
     * 撤防状态
     */
    public static final int STATE_UNDEFENCE = 0;

    /**
     * 布防状态
     */
    public static int STATE_DEFENCE = 1;

    /**
     * 离线
     */
    public static int STATE_OFFLINE = 2;

    public String houseNO;

    public String familyDockSn;

    public int state;

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof String){
            return TextUtils.equals(familyDockSn,obj.toString());
        }
        if(obj instanceof SecurityStateBean){
            return TextUtils.equals(familyDockSn,((SecurityStateBean) obj).familyDockSn);
        }
        return false;
    }
}
