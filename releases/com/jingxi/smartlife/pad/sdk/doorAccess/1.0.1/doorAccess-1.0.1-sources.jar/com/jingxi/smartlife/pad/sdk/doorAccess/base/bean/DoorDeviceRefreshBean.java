package com.jingxi.smartlife.pad.sdk.doorAccess.base.bean;

import com.intercom.sdk.IntercomManager;

/**
 * @author bjj
 * a empty bean to notice DoorManagerFragment refresh it's device list while proxy state had changed
 * pushed from
 * {@link com.jingxi.smartlife.install.door.DoorMessageCallback#onIntercomProxyStateChanged(IntercomManager.Intercom, String, boolean)}
 * {@link com.jingxi.smartlife.install.door.DoorMessageCallback#onIntercomProxyOnlineStateChanged(IntercomManager.Intercom, String, int, boolean)}
 * {@link com.jingxi.smartlife.install.door.DoorMessageCallback#onIntercomClientOnlineStateChanged(IntercomManager.Intercom, String, String, int, boolean)}
 * {@link com.jingxi.smartlife.install.door.DoorMessageCallback#onIntercomClientStateChanged(IntercomManager.Intercom, String, boolean)}
 */
public class DoorDeviceRefreshBean {
}
