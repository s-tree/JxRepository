package com.jingxi.smartlife.pad.sdk.doorAccess.base.ui;

public interface DoorAccessListUI {

    /**
     * 设备列表发生变更
     */
    void refreshList();

}
