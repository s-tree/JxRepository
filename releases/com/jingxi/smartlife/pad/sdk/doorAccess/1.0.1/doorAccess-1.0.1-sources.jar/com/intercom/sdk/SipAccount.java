package com.intercom.sdk;

/**
 * sip账号格式：sip:userid@server
 * sip:test_001@120.25.197.113
 */
public class SipAccount {

  private String userid;

  private String server;

  public SipAccount(String account) {
    this.userid = null;
    this.server = null;
    String username = getUserName(account);
    if (username != null && !username.isEmpty()) {
      String[] arr = username.split("@", 2);
      if (arr.length > 0)
        this.userid = arr[0];
      if (arr.length > 1)
        this.server = arr[1];
    }
  }

  public String getUserid() {
    return userid;
  }

  public String getServer() {
    return server;
  }

  /**
   * 可能写成这样 <sip:userid@server>，要去掉<>
   */
  private String getUserName(String account) {
    if (account.isEmpty())
      return null;

    int start = 0;
    int end = account.length() - 1;

    if (account.charAt(start) == '<')
      start = 1;
    if (account.charAt(end) == '>')
      end -= 1;

    if (start >= end)
      return null;

    String out = account.substring(start, end + 1);
    String[] arr = out.split(":");
    if (arr.length < 1)
      return null;
    if (arr.length < 2)
      return arr[0];
    return arr[1];
  }
}
