package com.jingxi.smartlife.pad.sdk.doorAccess.base.orm;

import com.jingxi.smartlife.pad.sdk.utils.JXContextWarpper;
import com.litesuits.orm.LiteOrm;
import com.litesuits.orm.db.DataBaseConfig;

public class LiteOrmUtil {
    private static int MAXSAVECOUNT = 50;
    /**
     * MB
     */
    private static int MINAVAVAILALESIZE = 500;
    private static LiteOrm doorAccessOrm;
    private static final String DB_NAME = "doorAccess";
    private static final boolean debug = false;
    private static final int DB_VERSION = 1;

    protected static LiteOrm getLiteOrm(){
        if (doorAccessOrm == null) {
            synchronized (LiteOrmUtil.class){
                if(doorAccessOrm == null){
                    DataBaseConfig config = new DataBaseConfig(JXContextWarpper.context, DB_NAME, debug, DB_VERSION, null);
                    doorAccessOrm = LiteOrm.newCascadeInstance(config);
                }
            }
        }
        return doorAccessOrm;
    }
}
