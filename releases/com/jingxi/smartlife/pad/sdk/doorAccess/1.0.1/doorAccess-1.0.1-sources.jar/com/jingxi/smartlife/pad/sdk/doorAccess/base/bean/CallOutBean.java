package com.jingxi.smartlife.pad.sdk.doorAccess.base.bean;

import com.intercom.sdk.IntercomMessage;
import com.intercom.sdk.NetClient;

public class CallOutBean {
    public int router;
    public NetClient netClient;
    public IntercomMessage message;
}
