package com.intercom.sdk;

/**
 * 如果代理运行于嵌入式设备，一般都包含物理按键
 * 代理会检测按键事件，并将按键事件打包发送给在线的终端
 * 终端需要处理按键信息，并作出相应的动作
 */

/**
 * ack : false
 * button_key : 122323
 * cmd : monitor
 * from : 1497234257325658
 * session_id : 112121121122
 * time : 1509581110589196
 * to :
 */

public class ButtonMessage {
  private String from;
  private String to;
  private String cmd;
  private String proxy_id;
  private String button_key;
  private String time;
  private boolean ack;

  public boolean isAck() {
    return ack;
  }

  public void setAck(boolean ack) {
    this.ack = ack;
  }

  public String getButton_key() {
    return button_key;
  }

  public void setButton_key(String button_key) {
    this.button_key = button_key;
  }

  public String getCmd() {
    return cmd;
  }

  public void setCmd(String cmd) {
    this.cmd = cmd;
  }

  public String getFrom() {
    return from;
  }

  public void setFrom(String from) {
    this.from = from;
  }

  public String getProxy_id() {
    return proxy_id;
  }

  public void setProxy_id(String proxy_id) {
    this.proxy_id = proxy_id;
  }

  public String getTime() {
    return time;
  }

  public void setTime(String time) {
    this.time = time;
  }

  public String getTo() {
    return to;
  }

  public void setTo(String to) {
    this.to = to;
  }
}
