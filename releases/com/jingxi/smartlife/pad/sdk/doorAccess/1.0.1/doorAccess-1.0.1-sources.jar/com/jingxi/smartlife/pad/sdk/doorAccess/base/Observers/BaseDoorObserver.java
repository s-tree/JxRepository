package com.jingxi.smartlife.pad.sdk.doorAccess.base.Observers;

import com.intercom.sdk.IntercomConstants;
import com.intercom.sdk.IntercomManager;
import com.intercom.sdk.IntercomMessage;
import com.intercom.sdk.IntercomSessionManager;
import com.intercom.sdk.NetClient;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorManagerUtil;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorSessionManager;

/**
 * @author bjj
 * the return of all method is means need to updateUI
 * IntercomMessage 需要判断 ack
 * ack   true  : 自己发送的消息的回包
 *       false : 对方发送的消息
 */
public class BaseDoorObserver {

    /**
     * 收到呼叫请求，此时还未正式响铃，只是发起请求，未呼叫
     * @param intercom
     * @param router
     * @param netClient
     * @param message
     * @return
     */
    boolean onInvite(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message){
        if(!DoorSessionManager.canCalling(message.getSession_id())){
            message.setResult(IntercomConstants.IntercomMessageResult.IntercomMessageResultDeviceBusy);
        }else{
            message.setResult(IntercomConstants.IntercomMessageResult.IntercomMessageResultOK);
        }
        DoorManagerUtil.accept(intercom,router,netClient,message);
        return false;
    }

    /**
     * 仅有室内通会收到call 消息,SDK 中不需要处理
     * @param intercom
     * @param router
     * @param netClient
     * @param message
     * @return
     */
    boolean onCall(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message){
        if(message.isAck()){
            return false;
        }
        if(!DoorSessionManager.canCalling(message.getSession_id())){
            message.setResult(IntercomConstants.IntercomMessageResult.IntercomMessageResultDeviceBusy);
        }else{
            message.setResult(IntercomConstants.IntercomMessageResult.IntercomMessageResultOK);
        }
        DoorManagerUtil.accept(intercom,router,netClient,message);
        return false;
    }

    /**
     * 呼叫进入
     * @param intercom
     * @param router
     * @param netClient
     * @param message
     * @return
     */
    boolean onRinging(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message){
        IntercomSessionManager.IntercomSession session = intercom.sessionManager.findSession(message.getSession_id());
        if(session != null){
            session.ringing();
        }
        return true;
    }

    /**
     * 呼叫接听
     * @param intercom
     * @param router
     * @param netClient
     * @param message
     * @return
     */
    boolean onPickup(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message){
        if(!message.isAck()){
            // 对方接听
            IntercomSessionManager.IntercomSession session = intercom.sessionManager.findSession(message.getSession_id());
            if(session != null){
                session.connected();
            }
        }
        return true;
    }

    /**
     * 呼叫被其他用户接听
     * @param intercom
     * @param router
     * @param netClient
     * @param message
     * @return
     */
    boolean onPickupByOther(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message){
        return true;
    }

    /**
     * 通话挂断
     * @param intercom
     * @param router
     * @param netClient
     * @param message
     * @return
     */
    boolean onHangup(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message){
        return true;
    }

    /**
     * 门禁开锁
     * @param intercom
     * @param router
     * @param netClient
     * @param message
     * @return
     */
    boolean onUnLock(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message){
        return true;
    }

    /**
     * 通话/呼叫超时
     * @param intercom
     * @param router
     * @param netClient
     * @param message
     * @return
     */
    boolean onTimeOut(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message){
        return true;
    }
}
