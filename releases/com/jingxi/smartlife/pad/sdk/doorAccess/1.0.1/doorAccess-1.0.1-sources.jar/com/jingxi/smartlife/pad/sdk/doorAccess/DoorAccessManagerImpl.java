package com.jingxi.smartlife.pad.sdk.doorAccess;

import android.view.SurfaceView;

import com.intercom.sdk.IntercomObserver;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorDeviceManager;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorInitUtil;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorManagerUtil;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorSessionManager;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.Observers.DoorMessageDispatcher;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorDevice;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorRecordBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.orm.DoorAccessOrmUtil;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.DoorAccessConversationUI;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.DoorAccessListUI;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.DoorAccessListener;

import java.util.List;

public final class DoorAccessManagerImpl extends DoorAccessManager {

    protected DoorAccessManagerImpl(){
        DoorInitUtil.getInstance().initDoorAccess();
    }

    @Override
    public void setListUIListener(DoorAccessListUI listener) {
        DoorSessionManager.setListUI(listener);
    }

    @Override
    public void setConversationUIListener(DoorAccessConversationUI listener) {
        DoorSessionManager.setConversationUI(listener);
    }

    @Override
    public void setDoorAccessListener(DoorAccessListener listener) {
        DoorMessageDispatcher.setDoorListener(listener);
    }

    @Override
    public void initAccess(String familyID, String buttonKey) {
        DoorInitUtil.startFamily(familyID,buttonKey);
    }

    @Override
    public void unInitAccess(String familyID) {
        DoorInitUtil.stopFamily(familyID);
    }

    @Override
    public String monitor(String familyID,DoorDevice doorDevice) {
        return DoorManagerUtil.monitor(familyID,doorDevice);
    }

    @Override
    public List<DoorDevice> getDevices(String familyID) {
        return DoorDeviceManager.getFamilyDevices(familyID);
    }

    /**
     * 获取设备在线状态
     */
    @Override
    public void checkDeviceOnline(String familyID){
        DoorDeviceManager.checkDeviceOnline(familyID);
    }

    @Override
    public void acceptCall(String sessionId) {
        DoorManagerUtil.pickUp(
                DoorSessionManager.getCurrentIntercom(sessionId),
                sessionId);
    }

    @Override
    public void hangupCall(String sessionId) {
        DoorManagerUtil.hangUp(
                DoorSessionManager.getCurrentIntercom(sessionId),
                sessionId);
    }

    @Override
    public void updateCallWindow(String sessionId,SurfaceView surfaceView) {
        DoorManagerUtil.updateRemoteSurface(
                DoorSessionManager.getCurrentIntercom(sessionId),
                sessionId,
                surfaceView);
    }

    @Override
    public List<DoorRecordBean> getHistoryList(String familyID,@DoorRecordBean.RECORD_TYPE int type,int pageStart,int pageSize) {
        return DoorAccessOrmUtil.queryRecords(familyID,type,pageStart,pageSize);
    }

    @Override
    public void startPlayBack(String sessionId) {
        DoorManagerUtil.startPlayBack(sessionId);
    }

    @Override
    public void pausePlayBack(String sessionId) {
        DoorManagerUtil.stopPlayBack(sessionId);
    }

    @Override
    public void seekPlayBack(String sessionId,int seek) {
        DoorManagerUtil.seekPlayBack(sessionId,seek);
    }

    @Override
    public void updatePlayBackWindow(String sessionId,SurfaceView surfaceView) {
        DoorManagerUtil.updatePlayBackSurface(sessionId,surfaceView);
    }

    @Override
    public void addPlayBackListener(IntercomObserver.OnPlaybackListener onPlaybackListener) {
        DoorManagerUtil.addPlayBackListener(onPlaybackListener);
    }

    @Override
    public void removePlayBackListener(IntercomObserver.OnPlaybackListener onPlaybackListener){
        DoorManagerUtil.removePlayBackListener(onPlaybackListener);
    }

}
