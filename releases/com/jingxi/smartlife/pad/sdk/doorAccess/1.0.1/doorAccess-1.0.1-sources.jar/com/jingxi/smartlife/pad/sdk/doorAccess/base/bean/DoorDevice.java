package com.jingxi.smartlife.pad.sdk.doorAccess.base.bean;

import com.intercom.sdk.IntercomNetDevice;

public class DoorDevice extends IntercomNetDevice.SubDevice {
    /**
     * 室内通
     */
    public static final int TYPE_EXT = -2;
    /**
     * 户户通
     */
    public static final int TYPE_P2P = -1;
    /**
     * 门口机
     */
    public static final int TYPE_DOOR = 1;
    /**
     * 单元机（室外机）
     */
    public static final int TYPE_UNIT = 2;
    /**
     * 物业管理机
     */
    public static final int TYPE_MANAGER = 3;

    public DoorDevice() {
        super("", "", "", "", true, true, 0);
    }

    public static DoorDevice parse(IntercomNetDevice.SubDevice subDevice){
        return new DoorDevice(subDevice.index,subDevice.name,subDevice.ip,subDevice.alias,subDevice.duplex,subDevice.hasVoice,subDevice.deviceType);
    }

    private DoorDevice(String index, String name, String ip, String alias, boolean duplex, boolean hasVoice, int deviceType) {
        super(index, name, ip, alias, duplex, hasVoice, deviceType);
    }

    //重新分类
    private int    myDeviceType;
    //设备所表示的图片
    //http://image.house-keeper.cn/door/door_device_0.png
    private String imgPic;
    //设备锁表示的本地图片
    private int    imgResource;

    /**
     * 外呼消息时 所属NetDeviceItem 的name
     */
    private String calledName;

    public int getMyDeviceType() {
        return myDeviceType;
    }

    public void setMyDeviceType(int myDeviceType) {
        this.myDeviceType = myDeviceType;
    }

    public String getImgPic() {
        return imgPic;
    }

    public void setImgPic(String imgPic) {
        this.imgPic = imgPic;
    }

    public int getImgResource() {
        return imgResource;
    }

    public void setImgResource(int imgResource) {
        this.imgResource = imgResource;
    }

    public String getCalledName() {
        return calledName;
    }

    public void setCalledName(String calledName) {
        this.calledName = calledName;
    }
}
