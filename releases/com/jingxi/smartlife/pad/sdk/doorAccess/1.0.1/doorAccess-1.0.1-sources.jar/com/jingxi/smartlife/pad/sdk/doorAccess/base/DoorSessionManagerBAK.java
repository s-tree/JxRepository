//package com.jingxi.smartlife.pad.sdk.doorAccess.base;
//
//import android.support.annotation.IntDef;
//import android.text.TextUtils;
//
//import com.intercom.sdk.IntercomManager;
//import com.intercom.sdk.IntercomMessage;
//import com.intercom.sdk.NetClient;
//import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorAccessSession;
//import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorDevice;
//import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorEvent;
//import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.ExtDeviceBean;
//import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.DoorAccessConversationUI;
//import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.DoorAccessListUI;
//
//import java.lang.annotation.Retention;
//import java.lang.annotation.RetentionPolicy;
//import java.util.HashMap;
//import java.util.Map;
//
//public class DoorSessionManagerBAK {
//    /**
//     * Session 管理
//     */
//    /**
//     * 用IntDef 包含几个常量
//     * 枚举类名用接口替代
//     */
//    @IntDef({FREE,MONITOR,RINGING,CHATTING,PLAY_BACK})
//    @Retention(RetentionPolicy.SOURCE)
//    public @interface Status{}
//
//    //空闲
//    public static final int FREE = 0;
//    //本地看监控
//    public static final int MONITOR = 1;
//    //有响铃
//    public static final int RINGING = 2;
//    //接听呼叫通话中
//    public static final int CHATTING = 3;
//    //正在回放
//    public static final int PLAY_BACK = 4;
//
////    private static @Status int mStatus ;
////    private static DoorEvent mDoorEvent;
////    private static String mSessionId;
////    private static DoorDevice currentDevice;
////    private static ExtDeviceBean extDeviceBean;
//    private static DoorAccessListUI listUI;
//    private static DoorAccessConversationUI conversationUI;
//
//    private static Map<String,DoorAccessSession> sessions = new HashMap<>();
//
//    public static void setListUI(DoorAccessListUI mListUI){
//        listUI = mListUI;
//    }
//
//    public static DoorAccessListUI getListUI() {
//        return listUI;
//    }
//
//    public static DoorAccessConversationUI getConversationUI() {
//        return conversationUI;
//    }
//
//    public static void setConversationUI(DoorAccessConversationUI conversationUI) {
//        DoorSessionManagerBAK.conversationUI = conversationUI;
//    }
//
//    public static IntercomManager.Intercom getCurrentIntercom(String sessionId){
//
//        return mDoorEvent != null ? mDoorEvent.intercom : null;
//    }
//
//    public static IntercomMessage getCurrentMessage(){
//        return mDoorEvent != null ? mDoorEvent.message : null;
//    }
//
//    public static int getCurrentRouter(){
//        return mDoorEvent != null ? mDoorEvent.router : DoorEvent.TYPE_DOOR;
//    }
//
//    public static NetClient getCurrentNetClient(){
//        return mDoorEvent != null ? mDoorEvent.netClient : null;
//    }
//
//    public static DoorDevice getCurrentDevice() {
//        return currentDevice;
//    }
//
//    public static void setCurrentDevice(DoorDevice currentDevice) {
//        DoorSessionManagerBAK.currentDevice = currentDevice;
//    }
//
//    public static ExtDeviceBean getExtDeviceBean() {
//        return extDeviceBean;
//    }
//
//    public static void setExtDeviceBean(ExtDeviceBean extDeviceBean) {
//        DoorSessionManagerBAK.extDeviceBean = extDeviceBean;
//    }
//
//    public static int getStatus() {
//        return mStatus;
//    }
//
//    private static void setStatus(@Status int newState){
//        mStatus = newState;
//    }
//
//    public static DoorEvent getDoorEvent() {
//        return mDoorEvent;
//    }
//
//    public static void setDoorEvent(DoorEvent doorEvent) {
//        mDoorEvent = doorEvent;
//    }
//
//    public static String getSessionId() {
//        return mSessionId;
//    }
//
//    public static void setSessionId(String sessionId) {
//        mSessionId = sessionId;
//    }
//
//    public static void setFamilyDockSn(String familyDockSn){
//        if(mDoorEvent == null){
//            mDoorEvent = new DoorEvent();
//            mDoorEvent.intercom = IntercomManager.getInstance().getIntercom(familyDockSn);
//        }
//    }
//
//    public static String getFamilyDockSn(){
//        if(mDoorEvent == null || mDoorEvent.intercom == null){
//            return null;
//        }
//        return mDoorEvent.intercom.id;
//    }
//
//    public static int getRingingType(){
//        if(mDoorEvent == null){
//            return DoorEvent.TYPE_DOOR;
//        }
//        return mDoorEvent.type;
//    }
//
//    /**
//     * 当前状态是否可以弹出门禁响铃
//     * @return
//     */
//    public static boolean canCalling(String sessionId){
//        return mStatus == FREE
//                || mStatus == PLAY_BACK
//                || mStatus == MONITOR
//                || TextUtils.equals(sessionId,mSessionId);
//    }
//
//    public static boolean equals(String newSessionId){
//        return TextUtils.equals(mSessionId,newSessionId);
//    }
//
//    public static void monitor(DoorDevice subDevice, String sessionId){
//        currentDevice = subDevice;
//        mStatus = MONITOR;
//        mDoorEvent = null;
//        mSessionId = sessionId;
//    }
//
//    public static void ringing(DoorEvent doorEvent){
//        if(doorEvent == null){
//            return;
//        }
//        mDoorEvent = doorEvent;
//        mStatus = RINGING;
//        mSessionId = doorEvent.message.getSession_id();
//        currentDevice = DoorDeviceManager.getDeviceByName(mDoorEvent.message.getUsername());
//    }
//
//    public static void pickUp(){
//        if(mStatus == RINGING){
//            mStatus = CHATTING;
//        }
//    }
//
//    public static void hangup(){
//        mStatus = FREE;
//        mDoorEvent = null;
//        mSessionId = null;
//    }
//
//}
