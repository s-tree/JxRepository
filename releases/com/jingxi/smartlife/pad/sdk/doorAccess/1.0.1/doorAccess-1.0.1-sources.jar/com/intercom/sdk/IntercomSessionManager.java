package com.intercom.sdk;

import android.os.Bundle;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * 门禁会话管理类
 */
public class IntercomSessionManager {

  public static class SessionState {
    public static final int SessionStateIdle = 0;
    public static final int SessionStateReady = 1;
    public static final int SessionStateRinging = 2;
    public static final int SessionStateConnected = 3;
  }

  public static class SessionDir {
    public static final int SessionDirCallout = 0;
    public static final int SessionDirCallin = 1;
  }

  /**
   * 本机client_id
   */
  public String localClientId;

  /**
   * 会话容器: <session_id, IntercomSession>
   */
  private Map<String, IntercomSession> sessions;


  private OnInternalIntercomSessionListener listener;

  public interface OnInternalIntercomSessionListener {

    boolean sendIntercomMessage(Bundle bundle);

    boolean sendIntercomCommand(Bundle bundle);
  }

  public IntercomSessionManager(OnInternalIntercomSessionListener listener, String localClientId) {
    this.listener = listener;
    this.localClientId = localClientId;
    this.sessions = new HashMap<>();
  }

  private boolean sendIntercomMessage(int router, NetClient netClient, IntercomMessage message) {
    Bundle bundle = new Bundle();
    bundle.putString("scheme", IntercomConstants.kIntercomScheme);
    bundle.putInt("router", router);
    boolean result = false;
    try {
      Gson g = new Gson();
      String client_string = g.toJson(netClient);
      String message_string = g.toJson(message);
      bundle.putString("client", client_string);
      bundle.putString("message", message_string);
      if (this.listener != null) {
        result = this.listener.sendIntercomMessage(bundle);
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }

  /**
   * 给门禁模块发消息
   *
   * @param session
   * @param message
   * @return
   */
  private boolean sendIntercomMessage(IntercomSession session, IntercomMessage message) {
    return sendIntercomMessage(session.router, session.netClient, message);
  }

  /**
   * 给门禁模块发命令
   *
   * @param command
   * @param session_id
   * @param message
   * @return
   */
  private boolean sendIntercomCommand(String command, String session_id, String message) {
    Bundle bundle = new Bundle();
    bundle.putString("scheme", IntercomConstants.kIntercomScheme);
    bundle.putString("command", command);
    if (session_id != null) {
      bundle.putString("session_id", session_id);
    }
    if (message != null) {
      bundle.putString("message", message);
    }
    if (this.listener != null) {
      return this.listener.sendIntercomCommand(bundle);
    }
    return false;
  }

  public IntercomSession findSession(String session_id) {
    if (sessions.isEmpty())
      return null;
    return sessions.get(session_id);
  }

  public void addSession(IntercomSession session) {
    sessions.put(session.session_id, session);
  }

  public void removeSession(String session_id) {
    if (sessions.isEmpty())
      return;
    sessions.remove(session_id);
  }

  public int size() {
    return sessions.size();
  }

  public Map<String, IntercomSession> sessions() {
    return sessions;
  }

  /**
   * 室内通会话，我们查询某个终端是否在会话中，如果在就是忙碌状态
   * peerClientId 只在室内通有效
   *
   * @param client_id
   * @return
   */
  public boolean clientBusy(String client_id) {
    if (sessions.isEmpty())
      return false;

    for (Map.Entry<String, IntercomSession> entry : sessions.entrySet()) {
      if (entry.getValue().peerClientId != null
        && client_id.equalsIgnoreCase(entry.getValue().peerClientId)) {
        return true;
      }
    }
    return false;
  }

  /**
   * 某个设备是否忙碌，需要判断代理，设备名，和用户名(就是室外机的号码)
   * 三个条件都满足，说明这个设备正在通话
   *
   * @param proxy_id
   * @param deviceName
   * @param userName
   * @return
   */
  public boolean deviceBusy(String proxy_id, String deviceName, String userName) {
    if (sessions.isEmpty())
      return false;

    for (Map.Entry<String, IntercomSession> entry : sessions.entrySet()) {
      if (!proxy_id.equalsIgnoreCase(entry.getValue().netClient.getClient_id()))
        continue;

      if (!entry.getValue().requestMessage.getTo().equalsIgnoreCase(deviceName))
        continue;

      if (entry.getValue().requestMessage.getUsername().equalsIgnoreCase(userName)) {
        return true;
      }
    }
    return false;
  }

  public boolean callout(int router, NetClient netClient, IntercomMessage message) {
    if (message.getTo() == null)
      return false;

    IntercomMessage new_message = (IntercomMessage) message.clone();
    new_message.setFrom(localClientId);
    IntercomSession session = new IntercomSession(SessionDir.SessionDirCallout,
      router,
      netClient,
      new_message);
    boolean result = sendIntercomMessage(session, new_message);

    if (result) {
      session.ready();
      addSession(session);
    }
    return result;
  }

  public boolean accept(int router, NetClient netClient, IntercomMessage message) {
    IntercomMessage new_message = (IntercomMessage) message.clone();

    new_message.setAck(true);
    new_message.setFrom(localClientId);
    new_message.setTo(message.getFrom());
    new_message.setResult(IntercomConstants.IntercomMessageResult.IntercomMessageResultOK);

    IntercomSession session = new IntercomSession(SessionDir.SessionDirCallin,
      router,
      netClient,
      new_message);
    boolean result = sendIntercomMessage(session, new_message);
    if (result) {
      session.ready();
      addSession(session);
    }
    return result;
  }

  public boolean decline(int router, NetClient netClient, IntercomMessage message, int reason) {
    IntercomMessage new_message = (IntercomMessage) message.clone();

    new_message.setAck(true);
    new_message.setFrom(localClientId);
    new_message.setTo(message.getFrom());
    new_message.setResult(reason);

    IntercomSession session = new IntercomSession(SessionDir.SessionDirCallin,
      router,
      netClient,
      new_message);
    return sendIntercomMessage(session, new_message);
  }

  public boolean hangUp(String session_id) {
    IntercomSession session = findSession(session_id);
    if (session == null)
      return false;

    IntercomMessage message = (IntercomMessage) session.requestMessage.clone();
    if (session.dir == SessionDir.SessionDirCallin
      && (session.state == SessionState.SessionStateReady
      || session.state == SessionState.SessionStateRinging)) {
      message.setCmd(IntercomConstants.kIntercomCommandLeaveSession);
    } else {
      message.setCmd(IntercomConstants.kIntercomCommandHangup);
    }

    boolean result = sendIntercomMessage(session, message);
    if (result) {
      sessions.remove(session_id);
    }
    return result;
  }

  public boolean pickUp(String session_id) {
    IntercomSession session = findSession(session_id);
    if (session == null)
      return false;

    IntercomMessage message = (IntercomMessage) session.requestMessage.clone();
    message.setCmd(IntercomConstants.kIntercomCommandPickup);

    boolean result = sendIntercomMessage(session, message);
    if (result) {
      session.connected();
    }
    return result;
  }

  public void hangUpAll() {
    if (sessions.isEmpty())
      return;

    Set<String> keyset = sessions.keySet();
    if (!keyset.isEmpty()) {
      Set<String> c = new HashSet<>(keyset);
      for (String key : c) {
        hangUp(key);
      }
    }
  }

  public boolean unlock(String session_id) {
    IntercomSession session = findSession(session_id);
    if (session == null)
      return false;

    return unlock(session.router,
      session.netClient,
      session_id,
      session.requestMessage.getTo());
  }

  public boolean unlock(int router,
                        NetClient netClient,
                        String session_id,
                        String device) {
    IntercomMessage message = new IntercomMessage();
    message.setFrom(localClientId);
    message.setTo(device);
    message.setCmd(IntercomConstants.kIntercomCommandUnlock);
    if (session_id != null) {
      message.setSession_id(session_id);
    }
    return sendIntercomMessage(router, netClient, message);
  }

  public boolean enableVideo(String session_id, boolean enable) {
    IntercomSession session = findSession(session_id);
    if (session == null)
      return false;

    session.videoEnable = enable;

    Bundle bundle = new Bundle();
    bundle.putBoolean("enable", enable);
    String message = BundleToJSON.toString(bundle);
    return sendIntercomCommand("video_control", session_id, message);
  }

  public boolean enableAudio(String session_id, boolean local, boolean enable) {
    IntercomSession session = findSession(session_id);
    if (session == null)
      return false;

    if (local) {
      session.localAudioEnable = enable;
    } else {
      session.remoteAudioEnable = enable;
    }

    Bundle bundle = new Bundle();
    bundle.putBoolean("local", local);
    bundle.putBoolean("enable", enable);
    String message = BundleToJSON.toString(bundle);
    return sendIntercomCommand("audio_control", session_id, message);
  }

  public boolean takeSnapshot(String session_id) {
    IntercomSession session = findSession(session_id);
    if (session == null)
      return false;
    return sendIntercomCommand("take_snapshot", session_id, null);
  }

  public boolean setupSip(String config) {
    if (config != null) {
      return sendIntercomCommand("start_sip", null, config);
    }
    return sendIntercomCommand("stop_sip", null, null);
  }

  public static boolean supportRecord(String deviceId) {
    return !(deviceId.equalsIgnoreCase("ext")
      || deviceId.equalsIgnoreCase("p2p"));
  }

  /**
   * 门禁会话数据结构
   */
  public static class IntercomSession implements Cloneable {
    public int state;

    public int dir;

    public int router;

    public String session_id;

    public NetClient netClient;
    /**
     * 收到请求活着发起请求的那个IntercomMessage
     * 后续还可能用到这些信息，所以缓存起来
     */
    public IntercomMessage requestMessage;

    public boolean videoEnable;

    public boolean localAudioEnable;

    public boolean remoteAudioEnable;

    /**
     * 只有室内通才有效
     */
    public String peerClientId;

    public IntercomSession(int dir, int router, NetClient netClient, IntercomMessage message) {
      this.dir = dir;
      this.router = router;
      this.netClient = netClient;
      this.requestMessage = message;
      this.session_id = message.getSession_id();
      this.videoEnable = true;
      this.localAudioEnable = true;
      this.remoteAudioEnable = true;
      this.peerClientId = null;
      this.state = SessionState.SessionStateIdle;

      if (message.getTo().equalsIgnoreCase("ext")) {
        try {
          String str = IntercomManager.base64(false, message.getContent());
          JSONObject jsonObject = new JSONObject(str);
          this.peerClientId = jsonObject.getString("client_id");
        } catch (JSONException e) {
          e.printStackTrace();
        }
      }
    }

    public void ready() {
      this.state = SessionState.SessionStateReady;
    }

    public void ringing() {
      this.state = SessionState.SessionStateRinging;
    }

    public void connected() {
      this.state = SessionState.SessionStateConnected;
    }

    @Override
    public Object clone() {
      IntercomSession session = null;
      try {
        session = (IntercomSession) super.clone();
      } catch (CloneNotSupportedException e) {
        e.printStackTrace();
      }
      return session;
    }
  }
}
