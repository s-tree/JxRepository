package com.jingxi.smartlife.pad.sdk.doorAccess.base.ui;

import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorEvent;

public interface DoorAccessConversationUI {

    /**
     * 视频流开始传输
     */
    void startTransPort();

    /**
     * 新事件
     */
    void refreshEvent(DoorEvent event);
}
