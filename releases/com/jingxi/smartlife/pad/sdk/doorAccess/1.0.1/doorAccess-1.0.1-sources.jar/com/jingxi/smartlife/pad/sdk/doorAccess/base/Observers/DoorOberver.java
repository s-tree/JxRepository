package com.jingxi.smartlife.pad.sdk.doorAccess.base.Observers;

import com.intercom.sdk.IntercomConstants;
import com.intercom.sdk.IntercomManager;
import com.intercom.sdk.IntercomMessage;
import com.intercom.sdk.NetClient;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorDeviceManager;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorManagerUtil;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorSessionManager;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorDevice;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorEvent;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorRecordBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.orm.DoorAccessOrmUtil;
import com.jingxi.smartlife.pad.sdk.utils.JXLogUtil;

public class DoorOberver extends BaseDoorObserver {

    @Override
    public boolean onRinging(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message) {
        /**
         * 此次monitor 的包，直接接听,且更新DoorSessionManager 中的DoorEvent
         */
        if(DoorSessionManager.getStatus(message.getSession_id()) == DoorSessionManager.MONITOR){
            DoorManagerUtil.pickUp(intercom,message.getSession_id());
            DoorEvent event = new DoorEvent();
            event.netClient = netClient;
            event.intercom = intercom;
            event.message = message;
            event.type = DoorEvent.TYPE_DOOR;
            event.sessionId = message.getSession_id();
            event.cmd = message.getCmd();
            DoorSessionManager.setDoorEvent(message.getSession_id(),event);
            return false;
        }

        DoorRecordBean recordBean = DoorRecordBean.parseDoorRecord(
                intercom.id,
                IntercomConstants.kIntercomScheme,
                message.getFrom(),
                message.getUsername(),
                message.getSession_id(),
                DoorRecordBean.CALL_EVENT_RECEIVER);
        DoorAccessOrmUtil.saveRecord(recordBean);
        return super.onRinging(intercom,router,netClient,message);
    }

    @Override
    public boolean onPickup(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message) {
        if(DoorSessionManager.getStatus(message.getSession_id()) == DoorSessionManager.MONITOR){
            /**
             * 查看监控时不需要让对方有声音和画面
             * 如果是物业的场景需要有声音
             */
            DoorManagerUtil.enableLocalVideo(intercom.id,message.getSession_id(),false);
            DoorDevice doorDevice = DoorSessionManager.getCurrentDevice(message.getSession_id());
            if(doorDevice == null || !DoorDeviceManager.isWuYe(doorDevice)){
                DoorManagerUtil.enableLocalAudio(intercom.id,message.getSession_id(),false);
            }
        }
        DoorAccessOrmUtil.updateChatSuccess(message.getSession_id());
        return super.onPickup(intercom,router,netClient,message);
    }

    @Override
    public boolean onPickupByOther(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message) {
        return super.onPickupByOther(intercom,router,netClient,message);
    }

    @Override
    public boolean onHangup(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message) {
        DoorAccessOrmUtil.updateEndTime(message.getSession_id());
        DoorAccessOrmUtil.updateChatHangup(message.getSession_id(),message.isAck());
        return super.onHangup(intercom,router,netClient,message);
    }
}
