// Copyright 2014 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

package com.intercom.media;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

import com.intercom.base.Log;
import com.intercom.base.annotations.CalledByNative;
import com.intercom.base.annotations.JNINamespace;

/**
 * This class implements a factory of Android Video Capture objects for Chrome.
 * The static createVideoCapture() returns either a "normal" VideoCaptureAndroid
 * or a "special" VideoCaptureTango. Cameras are identified by |id|, where Tango
 * cameras have |id| above the standard ones. Video Capture objects allocated
 * via createVideoCapture() are explicitly owned by the caller.
 * ChromiumCameraInfo is an internal class with some static methods needed from
 * the rest of the class to manipulate the |id|s of normal and special devices.
 **/
@JNINamespace("media")
@SuppressWarnings("deprecation")
class VideoCaptureFactory {
    // Internal class to encapsulate camera device id manipulations.
    static class ChromiumCameraInfo {
        private static int sNumberOfSystemCameras = -1;
        private static final String TAG = "cr.media";

        private static int getNumberOfCameras(Context appContext) {
            if (sNumberOfSystemCameras == -1) {
                // getNumberOfCameras() would not fail due to lack of permission, but the
                // following operations on camera would. "No permission" isn't a fatal
                // error in WebView, specially for those applications which have no purpose
                // to use a camera, but "load page" requires it. So, output a warning log
                // and carry on pretending the system has no camera(s).  This optimization
                // applies only to pre-M on Android because that is when runtime permissions
                // were introduced.
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M
                        && appContext.getPackageManager().checkPermission(
                                   Manifest.permission.CAMERA, appContext.getPackageName())
                                != PackageManager.PERMISSION_GRANTED) {
                    sNumberOfSystemCameras = 0;
                    Log.w(TAG, "Missing android.permission.CAMERA permission, "
                                    + "no system camera available.");
                } else {
                    if (isLReleaseOrLater()) {
                        sNumberOfSystemCameras = VideoCaptureCamera2.getNumberOfCameras(appContext);
                    } else {
                        sNumberOfSystemCameras = VideoCaptureAndroid.getNumberOfCameras();
                    }
                }
            }
            return sNumberOfSystemCameras;
        }
    }

    private static boolean isLReleaseOrLater() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP;
    }

    @CalledByNative
    static boolean isLegacyOrDeprecatedDevice(int id, Context appContext) {
        return !isLReleaseOrLater() || VideoCaptureCamera2.isLegacyDevice(appContext,id);
    }

    // Factory methods.
    @CalledByNative
    static VideoCapture createVideoCapture(
            Context context, int id, long nativeVideoCaptureDeviceAndroid) {
        if (isLegacyOrDeprecatedDevice(id,context)) {
            return new VideoCaptureAndroid(context, id, nativeVideoCaptureDeviceAndroid);
        }
        return new VideoCaptureCamera2(context, id, nativeVideoCaptureDeviceAndroid);
    }

    @CalledByNative
    static int getNumberOfCameras(Context appContext) {
        return ChromiumCameraInfo.getNumberOfCameras(appContext);
    }

    @CalledByNative
    static int getCaptureApiType(int id, Context appContext) {
        if (isLegacyOrDeprecatedDevice(id,appContext)) {
            return VideoCaptureAndroid.getCaptureApiType(id);
        }
        return VideoCaptureCamera2.getCaptureApiType(id,appContext);
    }

    @CalledByNative
    static int getFacingMode(int id, Context appContext) {
        if (isLegacyOrDeprecatedDevice(id,appContext)) {
            return VideoCaptureAndroid.getFacingMode(id);
        }
        return VideoCaptureCamera2.getFacingMode(id,appContext);
    }

    @CalledByNative
    static String getDeviceName(int id, Context appContext) {
        if (isLegacyOrDeprecatedDevice(id,appContext)) {
            return VideoCaptureAndroid.getName(id);
        }
        return VideoCaptureCamera2.getName(id, appContext);
    }

    @CalledByNative
    static VideoCaptureFormat[] getDeviceSupportedFormats(Context appContext, int id) {
        if (isLegacyOrDeprecatedDevice(id,appContext)) {
            return VideoCaptureAndroid.getDeviceSupportedFormats(id);
        }
        return VideoCaptureCamera2.getDeviceSupportedFormats(appContext, id);
    }

    @CalledByNative
    static int getCaptureFormatWidth(VideoCaptureFormat format) {
        return format.getWidth();
    }

    @CalledByNative
    static int getCaptureFormatHeight(VideoCaptureFormat format) {
        return format.getHeight();
    }

    @CalledByNative
    static int getCaptureFormatFramerate(VideoCaptureFormat format) {
        return format.getFramerate();
    }

    @CalledByNative
    static int getCaptureFormatPixelFormat(VideoCaptureFormat format) {
        return format.getPixelFormat();
    }
}
