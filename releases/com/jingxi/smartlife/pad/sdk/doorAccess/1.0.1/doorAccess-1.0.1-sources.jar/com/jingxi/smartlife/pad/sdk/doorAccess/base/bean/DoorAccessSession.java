package com.jingxi.smartlife.pad.sdk.doorAccess.base.bean;

import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorSessionManager;

public class DoorAccessSession {

    public DoorAccessSession(String sessionID) {
        this.sessionID = sessionID;
    }

    /**
     * 当前状态
     */
    public @DoorSessionManager.Status int status;
    /**
     * 当前session
     */
    public String sessionID;
    /**
     * 当前设备
     */
    public DoorDevice currentDevice;
    /**
     * 当前事件
     */
    public DoorEvent doorEvent;
}
