package com.intercom.sdk;

import android.os.Bundle;

public class IntercomObserver {

  public interface OnAppListener {

    /**
     * App 模块异步初始化callback，在这个callback之后
     * 继续初始化Intercom
     *
     * @param result:成功/失败，失败一般由不正确的参数引起的
     */
    void onIntercomAppIntialized(boolean result);

    /**
     * 底层对于媒体资源的使用情况
     *
     * @param media_type:TransportMediaType:TransportMediaTypeAudio/TransportMediaTypeVideo
     * @param state:StreamState:StreamStateStart/StreamStateStop
     */
    void onIntercomMediaDeviceStateChanged(int media_type,
                                           int state);

    /**
     * 如果启动了MCU，这里可能收到MCU的消息，比如对智能门锁的控制，电梯的控制消息等
     *
     * @param type:MCUMessageType
     * @param ack:是否是回复包
     * @param result:0：成功，其他错误
     * @param message:消息正文，一般为json格式
     */
    void onMCUMessageArrival(int type, boolean ack, int result, String message);

    /**
     * MCU的连接状态发生改变
     *
     * @param online
     */
    void onMCUStateChanged(boolean online);

    /**
     * 按键事件，由MCU触发，一般用来处理一下状态
     *
     * @param event:事件，pressed：1,released:2,long_pressed:3
     * @param id:按键标识
     * @param sound:按键的声音id
     */
    void onButtonEvent(int event, String id, String sound);

    /**
     * 按键点击事件，一般我们需要处理这个callback
     * 代表着一个动作的发生
     *
     * @param id
     */
    void onButtonClick(String id);
  }

  public interface OnPlaybackListener {
    /**
     * 媒体播放的回调事件
     * event:
     * public static class MediaPlayEvent {
     * public static final int MediaPlayEventDuration = 0;
     * public static final int MediaPlayEventProgress = 1;
     * public static final int MediaPlayEventCompleted = 2;
     * }
     */

    void onMediaPlayEvent(String session_id, int event, long value);
  }

  /**
   * 初始化门禁实例的callback，可能有多个家庭，会有多个实例
   */
  public interface OnIntercomClientListener {
    void onIntercomClientInitializeResult(IntercomManager.Intercom intercom, boolean result);
  }

  /**
   * 门禁实例的代理callback
   */
  public interface OnProxyListener {
    void onIntercomProxyStateChanged(IntercomManager.Intercom intercom,
                                     String proxy_id,
                                     boolean online);

    void onIntercomProxyOnlineStateChanged(IntercomManager.Intercom intercom,
                                           String proxy_id,
                                           int router,
                                           boolean online);

    void onIntercomClientStateChanged(IntercomManager.Intercom intercom,
                                      String client_id,
                                      boolean online);

    void onIntercomClientOnlineStateChanged(IntercomManager.Intercom intercom,
                                            String client_id,
                                            String proxy_id,
                                            int router,
                                            boolean online);

    void onIntercomInternetStateChanged(IntercomManager.Intercom intercom,
                                        boolean online);

    /**
     * 收到远端的按键消息
     *
     * @param router
     * @param netClient
     * @param message
     */
    void onIntercomButtonMessageArrival(IntercomManager.Intercom intercom,
                                        int router,
                                        NetClient netClient,
                                        ButtonMessage message);

    /**
     * 其他未知消息
     *
     * @param bundle
     */
    void onIntercomProxyMessageArrival(IntercomManager.Intercom intercom,
                                       Bundle bundle);
  }

  /**
   * 门禁会话的callback，关联到某个家庭
   */
  public interface OnIntercomListener {
    /**
     * 收到门禁消息，具体需要解析IntercomMessage
     *
     * @param router
     * @param netClient
     * @param message
     */
    void onIntercomMessageArrival(IntercomManager.Intercom intercom,
                                  int router,
                                  NetClient netClient,
                                  IntercomMessage message);

    /**
     * 某路会话的对方视频的第一个关键帧已经收到，接下来就可以创建快照了
     * takeSnapshot
     *
     * @param session_id
     */
    void onIntercomVideoReady(IntercomManager.Intercom intercom,
                              String session_id);

    /**
     * 某路会话的快照创建成功，保存到filename指定的文件中(JPEG)格式
     *
     * @param session_id
     * @param filename
     */
    void onIntercomSnapshotReady(IntercomManager.Intercom intercom,
                                 String session_id,
                                 String filename);

    /**
     * 本机sip登陆状态变化
     * public static class SipRegistrationState {
     * public static final int SipRegistrationNone = 0;
     * public static final int SipRegistrationProgress = 1;
     * public static final int SipRegistrationOk = 2;
     * public static final int SipRegistrationCleared = 3;
     * public static final int SipRegistrationFailed = 4;
     * }
     *
     * @param proxy
     * @param state
     */
    void onIntercomSipStateChanged(IntercomManager.Intercom intercom,
                                   String proxy,
                                   int state);

    /**
     * 某个会话媒体流发生变化
     *
     * @param session_id
     * @param media_type
     * @param state
     */
    void onIntercomStreamStateChanged(IntercomManager.Intercom intercom,
                                      String session_id,
                                      int media_type,
                                      int state);

    /**
     * 某个会话的传输层发生变化
     *
     * @param session_id
     * @param media_type
     */
    void onStreamTransportStart(IntercomManager.Intercom intercom,
                                String session_id,
                                int media_type);

    void onIntercomTransportStatistics(IntercomManager.Intercom intercom,
                                       String session_id,
                                       int media_type,
                                       int interval,
                                       long recv_bytes,
                                       long send_bytes);

    void onIntercomTransportIceNegotiationResult(IntercomManager.Intercom intercom,
                                                 String session_id,
                                                 int media_type,
                                                 int result);
  }

  /**
   * 智能家居的callback，关联到某个家庭
   */
  public interface OnSmartHomeListener {
    void onSmartHomeSecurityDeviceStateChanged(IntercomManager.Intercom intercom,
                                               SmartHomeManager.SecurityDevice device,
                                               boolean online);

    void onSmartHomeSecurityDeviceOnlineStateChanged(IntercomManager.Intercom intercom,
                                                     SmartHomeManager.SecurityDevice device,
                                                     int router,
                                                     boolean online);

    void onSmartHomeMessage(IntercomManager.Intercom intercom,
                            SmartHomeManager.SecurityDevice device,
                            SmartHomeMessage message);

    void onSmartHomeAlarm(IntercomManager.Intercom intercom,
                          SmartHomeManager.SecurityDevice device,
                          SmartHomeMessage smartHomeMessage,
                          SecurityMessage securityMessage);
  }

  public static class IntercomAppListener extends EventListener<OnAppListener> {

    public void onIntercomAppIntialized(boolean result) {
      for (OnAppListener listener : listeners.keySet()) {
        if (listener != null) {
          listener.onIntercomAppIntialized(result);
        }
      }
    }

    public void onIntercomMediaDeviceStateChanged(int media_type,
                                                  int state) {
      for (OnAppListener listener : listeners.keySet()) {
        if (listener != null) {
          listener.onIntercomMediaDeviceStateChanged(media_type, state);
        }
      }
    }

    public void onMCUMessageArrival(int type, boolean ack, int result, String message) {
      for (OnAppListener listener : listeners.keySet()) {
        if (listener != null) {
          listener.onMCUMessageArrival(type, ack, result, message);
        }
      }
    }

    public void onMCUStateChanged(boolean online) {
      for (OnAppListener listener : listeners.keySet()) {
        if (listener != null) {
          listener.onMCUStateChanged(online);
        }
      }
    }

    public void onButtonEvent(int event, String id, String sound) {
      for (OnAppListener listener : listeners.keySet()) {
        if (listener != null) {
          listener.onButtonEvent(event, id, sound);
        }
      }
    }

    public void onButtonClick(String id) {
      for (OnAppListener listener : listeners.keySet()) {
        if (listener != null) {
          listener.onButtonClick(id);
        }
      }
    }
  }

  public static class PlaybackListener extends EventListener<OnPlaybackListener> {
    public void onMediaPlayEvent(String session_id, int event, long value) {
      for (OnPlaybackListener listener : listeners.keySet()) {
        if (listener != null) {
          listener.onMediaPlayEvent(session_id, event, value);
        }
      }
    }
  }

  public static class IntercomClientListener extends EventListener<OnIntercomClientListener> {
    public void onIntercomClientInitializeResult(IntercomManager.Intercom intercom, boolean result) {
      for (OnIntercomClientListener listener : listeners.keySet()) {
        if (listener != null) {
          listener.onIntercomClientInitializeResult(intercom, result);
        }
      }
    }
  }

  public static class ProxyListener extends EventListener<OnProxyListener> {

    public void onIntercomProxyStateChanged(IntercomManager.Intercom intercom, String proxy_id, boolean online) {
      for (OnProxyListener listener : listeners.keySet()) {
        if (listener != null) {
          listener.onIntercomProxyStateChanged(intercom, proxy_id, online);
        }
      }
    }

    public void onIntercomProxyOnlineStateChanged(IntercomManager.Intercom intercom, String proxy_id, int router, boolean online) {
      for (OnProxyListener listener : listeners.keySet()) {
        if (listener != null) {
          listener.onIntercomProxyOnlineStateChanged(intercom, proxy_id, router, online);
        }
      }
    }

    public void onIntercomClientStateChanged(IntercomManager.Intercom intercom, String client_id, boolean online) {
      for (OnProxyListener listener : listeners.keySet()) {
        if (listener != null) {
          listener.onIntercomClientStateChanged(intercom, client_id, online);
        }
      }
    }

    public void onIntercomClientOnlineStateChanged(IntercomManager.Intercom intercom, String client_id, String proxy_id, int router, boolean online) {
      for (OnProxyListener listener : listeners.keySet()) {
        if (listener != null) {
          listener.onIntercomClientOnlineStateChanged(intercom, client_id, proxy_id, router, online);
        }
      }
    }

    public void onIntercomInternetStateChanged(IntercomManager.Intercom intercom, boolean online) {
      for (OnProxyListener listener : listeners.keySet()) {
        if (listener != null) {
          listener.onIntercomInternetStateChanged(intercom, online);
        }
      }
    }

    public void onIntercomButtonMessageArrival(IntercomManager.Intercom intercom, int router, NetClient netClient, ButtonMessage message) {
      for (OnProxyListener listener : listeners.keySet()) {
        if (listener != null) {
          listener.onIntercomButtonMessageArrival(intercom, router, netClient, message);
        }
      }
    }

    public void onIntercomProxyMessageArrival(IntercomManager.Intercom intercom, Bundle bundle) {
      for (OnProxyListener listener : listeners.keySet()) {
        if (listener != null) {
          listener.onIntercomProxyMessageArrival(intercom, bundle);
        }
      }
    }
  }

  public static class IntercomListener extends EventListener<OnIntercomListener> {
    public void onIntercomMessageArrival(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message) {
      for (OnIntercomListener listener : listeners.keySet()) {
        if (listener != null) {
          listener.onIntercomMessageArrival(intercom, router, netClient, message);
        }
      }
    }

    public void onIntercomVideoReady(IntercomManager.Intercom intercom, String session_id) {
      for (OnIntercomListener listener : listeners.keySet()) {
        if (listener != null) {
          listener.onIntercomVideoReady(intercom, session_id);
        }
      }
    }

    public void onIntercomSnapshotReady(IntercomManager.Intercom intercom, String session_id, String filename) {
      for (OnIntercomListener listener : listeners.keySet()) {
        if (listener != null) {
          listener.onIntercomSnapshotReady(intercom, session_id, filename);
        }
      }
    }

    public void onIntercomSipStateChanged(IntercomManager.Intercom intercom, String proxy, int state) {
      for (OnIntercomListener listener : listeners.keySet()) {
        if (listener != null) {
          listener.onIntercomSipStateChanged(intercom, proxy, state);
        }
      }
    }

    public void onIntercomStreamStateChanged(IntercomManager.Intercom intercom, String session_id, int media_type, int state) {
      for (OnIntercomListener listener : listeners.keySet()) {
        if (listener != null) {
          listener.onIntercomStreamStateChanged(intercom, session_id, media_type, state);
        }
      }
    }

    public void onStreamTransportStart(IntercomManager.Intercom intercom, String session_id,
                                       int media_type) {
      for (OnIntercomListener listener : listeners.keySet()) {
        if (listener != null) {
          listener.onStreamTransportStart(intercom, session_id, media_type);
        }
      }
    }

    public void onIntercomTransportStatistics(IntercomManager.Intercom intercom, String session_id,
                                              int media_type,
                                              int interval,
                                              long recv_bytes,
                                              long send_bytes) {
      for (OnIntercomListener listener : listeners.keySet()) {
        if (listener != null) {
          listener.onIntercomTransportStatistics(intercom, session_id, media_type, interval, recv_bytes, send_bytes);
        }
      }
    }

    public void onIntercomTransportIceNegotiationResult(IntercomManager.Intercom intercom,
                                                        String session_id,
                                                        int media_type,
                                                        int result) {
      for (OnIntercomListener listener : listeners.keySet()) {
        if (listener != null) {
          listener.onIntercomTransportIceNegotiationResult(intercom, session_id, media_type, result);
        }
      }
    }
  }

  public static class SmartHomeListener extends EventListener<OnSmartHomeListener> {

    /**
     * 安防设备上下线，注意，上线的时候，设备还没拿到详细的配置
     * 在收到query命令的时候才会收到
     *
     * @param device
     * @param online
     */
    public void onSmartHomeSecurityDeviceStateChanged(IntercomManager.Intercom intercom, SmartHomeManager.SecurityDevice device,
                                                      boolean online) {
      for (OnSmartHomeListener listener : listeners.keySet()) {
        if (listener != null) {
          listener.onSmartHomeSecurityDeviceStateChanged(intercom, device, online);
        }
      }
    }

    public void onSmartHomeSecurityDeviceOnlineStateChanged(IntercomManager.Intercom intercom, SmartHomeManager.SecurityDevice device,
                                                            int router,
                                                            boolean online) {
      for (OnSmartHomeListener listener : listeners.keySet()) {
        if (listener != null) {
          listener.onSmartHomeSecurityDeviceOnlineStateChanged(intercom, device, router, online);
        }
      }
    }

    public void onSmartHomeMessage(IntercomManager.Intercom intercom, SmartHomeManager.SecurityDevice device,
                                   SmartHomeMessage message) {
      for (OnSmartHomeListener listener : listeners.keySet()) {
        if (listener != null) {
          listener.onSmartHomeMessage(intercom, device, message);
        }
      }
    }

    public void onSmartHomeAlarm(IntercomManager.Intercom intercom,
                                 SmartHomeManager.SecurityDevice device,
                                 SmartHomeMessage smartHomeMessage,
                                 SecurityMessage securityMessage) {
      for (OnSmartHomeListener listener : listeners.keySet()) {
        if (listener != null) {
          listener.onSmartHomeAlarm(intercom, device, smartHomeMessage, securityMessage);
        }
      }
    }
  }
}
