package com.jingxi.smartlife.pad.sdk.doorAccess.base.Observers;

import com.intercom.sdk.IntercomManager;
import com.intercom.sdk.IntercomMessage;
import com.intercom.sdk.NetClient;

public class ExtOberver extends BaseDoorObserver {

    @Override
    public boolean onRinging(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message) {
        return super.onRinging(intercom,router,netClient,message);
    }

    @Override
    public boolean onPickup(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message) {
        return super.onPickup(intercom,router,netClient,message);
    }

    @Override
    public boolean onPickupByOther(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message) {
        return super.onPickupByOther(intercom,router,netClient,message);
    }

    @Override
    public boolean onHangup(IntercomManager.Intercom intercom, int router, NetClient netClient, IntercomMessage message) {
        return super.onHangup(intercom,router,netClient,message);
    }
}
