package com.jingxi.smartlife.pad.sdk.doorAccess.base;

import com.intercom.sdk.IntercomConfigure;
import com.intercom.sdk.IntercomConstants;

public class DoorConfigs {
    private static final String APP_CHANNEL = "jx_dr";
    public static final String DOOR_LOG_TAG = "door";
    private static final String PATH = "sdcard/data/doorkeeper/access/";//文件保存路径
    public static String MEDIA_DIR = PATH + "record/";
    private static final String NO_VIDEO_JPG = "novideo.jpg";
    private static final String INTERCOM_SERVER_URL = "http://120.77.237.47:7070/opensip/v2/register";
    private static final String PROXY_MULTICAST_ADDRESS = "238.18.18.1";
    private static final String PROXY_SERVER_URL = "http://120.77.237.47:16888";

    public static String getAppConf() {
        IntercomConfigure.AppConf appConf = new IntercomConfigure.AppConf(APP_CHANNEL,
                PATH,
                MEDIA_DIR, true, IntercomConstants.LogLevel.Info);
        return appConf.toJson();
    }

    public static String getIntercomConfig() {
        return new IntercomConfigure.IntercomConfig().toJson();
    }

    public static byte[][] getNoVideoImage() {
        return null;
//        byte[][] arr = new byte[1][];
//        arr[0] = utils.readResourceFromFile(BaseA, NO_VIDEO_JPG);
//        return arr;
    }

    public static String getClientConf(String familyDockSN,String buttonKey) {
        IntercomConfigure.ClientConf clientConf = new IntercomConfigure.ClientConf(
                IntercomConstants.NetClientType.NetClientTypeClient,
                IntercomConstants.NetClientSubType.NetClientSubTypePad,
                null,
                familyDockSN,
                buttonKey,
                null,
                "");
        return clientConf.toJson();
    }

    public static String getOtherConf() {
        IntercomConfigure.OtherConf otherConf = new IntercomConfigure.OtherConf(
                "30000,35000,40000",
                null,
                null);
        return otherConf.toJson();
    }

    public static String getProxyConfig() {
        return new IntercomConfigure.ProxyConf(10000,
                PROXY_MULTICAST_ADDRESS,
                60,
                true,
                true,
                PROXY_SERVER_URL,
                "",
                "",
                5,
                300).toJson();
    }

    public static String getServerConfig() {
        return new IntercomConfigure.ServerConfig(
                INTERCOM_SERVER_URL,
                "",
                "",
                "",
                0).toJson();
    }
}
