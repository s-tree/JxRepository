package com.intercom.sdk;

/**
 * ack : true
 * broadcast : false
 * cmd : auth
 * content :
 * from : knx
 * sn : 00CA450101620000
 * proxy_id : 1496136497079886
 * result : 0
 * source : 0
 * state : 0
 * to :
 */

public class SmartHomeMessage {

  public static class MessageSource {
    public static final int MessageSourceSecurityCenter = 0;
    public static final int MessageSourceDevice = 1;
    public static final int MessageSourceProxy = 2;
    public static final int MessageSourceClientPad = 3;
    public static final int MessageSourceClientEmbedded = 4;
  }

  private boolean ack;
  private boolean broadcast;
  private String cmd;
  private String content;
  private String from;
  private String sn;
  private String proxy_id;
  private int result;
  private int source;
  private int state;
  private String to;
  private String time;
  private String source_id;

  public boolean isAck() {
    return ack;
  }

  public void setAck(boolean ack) {
    this.ack = ack;
  }

  public boolean isBroadcast() {
    return broadcast;
  }

  public void setBroadcast(boolean broadcast) {
    this.broadcast = broadcast;
  }

  public String getCmd() {
    return cmd;
  }

  public void setCmd(String cmd) {
    this.cmd = cmd;
  }

  public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }

  public String getFrom() {
    return from;
  }

  public void setFrom(String from) {
    this.from = from;
  }

  public String getSn() {
    return sn;
  }

  public void setSn(String sn) {
    this.sn = sn;
  }

  public String getProxy_id() {
    return proxy_id;
  }

  public void setProxy_id(String proxy_id) {
    this.proxy_id = proxy_id;
  }

  public int getResult() {
    return result;
  }

  public void setResult(int result) {
    this.result = result;
  }

  public int getSource() {
    return source;
  }

  public void setSource(int source) {
    this.source = source;
  }

  public int getState() {
    return state;
  }

  public void setState(int state) {
    this.state = state;
  }

  public String getTo() {
    return to;
  }

  public void setTo(String to) {
    this.to = to;
  }

  public String getTime() {
    return this.time;
  }

  public void setTime(String time) {
    this.time = time;
  }

  public String getSource_id(){return this.source_id;}

  public void setSource_id(String source_id){ this.source_id = source_id;}
}
