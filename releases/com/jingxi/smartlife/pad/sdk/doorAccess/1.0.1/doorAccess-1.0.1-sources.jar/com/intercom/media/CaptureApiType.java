// Copyright 2013 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.
package com.intercom.media;
class CaptureApiType {
   static final int API1 = 0;
   static final int API2_LEGACY = 1;
   static final int API2_FULL = 2;
   static final int API2_LIMITED = 3;
   static final int TANGO = 4;
   static final int API_TYPE_UNKNOWN = 5;
}