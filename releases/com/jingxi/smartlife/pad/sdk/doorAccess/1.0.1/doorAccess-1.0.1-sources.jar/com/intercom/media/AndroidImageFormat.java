// Copyright 2013 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.
package com.intercom.media;
class AndroidImageFormat {
   static final int NV21 = 17;
   static final int YUV_420_888 = 35;
   static final int YV12 = 842094169;
   static final int UNKNOWN = 0;

}