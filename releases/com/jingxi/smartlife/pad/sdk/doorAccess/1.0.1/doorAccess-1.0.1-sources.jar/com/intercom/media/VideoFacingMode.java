// Copyright 2013 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.
package com.intercom.media;
class VideoFacingMode {
   static final int MEDIA_VIDEO_FACING_NONE = 0;
   static final int MEDIA_VIDEO_FACING_USER = 1;
   static final int MEDIA_VIDEO_FACING_ENVIRONMENT = 2;
}