package com.jingxi.smartlife.pad.sdk.doorAccess.base.orm;

import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorRecordBean;
import com.litesuits.orm.db.assit.QueryBuilder;

import java.util.List;

public class DoorAccessOrmUtil extends LiteOrmUtil {

    public static void saveRecord(DoorRecordBean recordBean){
        getLiteOrm().save(recordBean);
    }

    public static void deleteRecord(DoorRecordBean recordBean){
        getLiteOrm().delete(recordBean);
    }

    public static List<DoorRecordBean> queryRecords(String familyID,@DoorRecordBean.RECORD_TYPE int type,int pageStart,int pageSize){
        QueryBuilder<DoorRecordBean> queryBuilder = QueryBuilder.create(DoorRecordBean.class)
                .whereEquals("familyID",familyID)
                .whereAppendAnd()
                .whereEquals("record_type",type)
                .appendOrderDescBy("startTime")
                .limit(pageStart, pageSize);
        return getLiteOrm().query(queryBuilder);
    }

    public static List<DoorRecordBean> queryRecordBySession(String sessionId){
        QueryBuilder<DoorRecordBean> queryBuilder = QueryBuilder.create(DoorRecordBean.class)
                .whereEquals("session_id",sessionId);
        return getLiteOrm().query(queryBuilder);
    }


    public static void clearRecord(){
        getLiteOrm().deleteAll(DoorRecordBean.class);
    }

    public static void updateThumb(String sessionId,String thumbPath){
        List<DoorRecordBean> recordBeans = queryRecordBySession(sessionId);
        if(recordBeans == null || recordBeans.isEmpty()){
            return;
        }
        for(DoorRecordBean recordBean : recordBeans){
            recordBean.thumbPath = thumbPath;
        }
        getLiteOrm().update(recordBeans);
    }

    public static void updateEndTime(String sessionId){
        List<DoorRecordBean> recordBeans = queryRecordBySession(sessionId);
        if(recordBeans == null || recordBeans.isEmpty()){
            return;
        }
        for(DoorRecordBean recordBean : recordBeans){
            recordBean.chat_time = (int) ((System.currentTimeMillis() - recordBean.startTime) / 1000);
        }
        getLiteOrm().update(recordBeans);
    }

    /**
     * 更新通话成功的事件
     * @param sessionId
     */
    public static void updateChatSuccess(String sessionId){
        List<DoorRecordBean> recordBeans = queryRecordBySession(sessionId);
        if(recordBeans == null || recordBeans.isEmpty()){
            return;
        }
        for(DoorRecordBean recordBean : recordBeans){
            if(recordBean.chatEvent == DoorRecordBean.CALL_EVENT_CALLOUT){
                recordBean.chatEvent = DoorRecordBean.CALL_EVENTCALLOUT_CHATTING;
            }
            else if(recordBean.chatEvent == DoorRecordBean.CALL_EVENT_RECEIVER){
                recordBean.chatEvent = DoorRecordBean.CALL_EVENT_RECEIVER_CHATTING;
            }
        }
        getLiteOrm().update(recordBeans);
    }

    /**
     * 更新通话挂断的事件
     * 外呼时有取消和被挂断
     * 收到呼叫时有被取消和自己挂断
     * @param sessionId
     */
    public static void updateChatHangup(String sessionId,boolean fromSelf){
        List<DoorRecordBean> recordBeans = queryRecordBySession(sessionId);
        if(recordBeans == null || recordBeans.isEmpty()){
            return;
        }
        for(DoorRecordBean recordBean : recordBeans){
            if(recordBean.chatEvent == DoorRecordBean.CALL_EVENT_CALLOUT){
                recordBean.chatEvent = fromSelf ? DoorRecordBean.CALL_EVENT_CALLOUT_CANCEL : DoorRecordBean.CALL_EVENT_CALLOUT_REJECT;
            }
            else if(recordBean.chatEvent == DoorRecordBean.CALL_EVENT_RECEIVER){
                recordBean.chatEvent = fromSelf ? DoorRecordBean.CALL_EVENT_RECEIVER_REJECT : DoorRecordBean.CALL_EVENT_RECEIVER_CANCEL;
            }
        }
        getLiteOrm().update(recordBeans);
    }

}
