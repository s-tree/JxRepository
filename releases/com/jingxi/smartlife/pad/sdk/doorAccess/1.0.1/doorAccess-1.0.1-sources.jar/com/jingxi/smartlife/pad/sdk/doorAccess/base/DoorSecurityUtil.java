package com.jingxi.smartlife.pad.sdk.doorAccess.base;

import android.text.TextUtils;

import com.intercom.sdk.IntercomConstants;
import com.intercom.sdk.IntercomManager;
import com.intercom.sdk.SecurityMessage;
import com.intercom.sdk.SmartHomeManager;
import com.intercom.sdk.SmartHomeMessage;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.SecurityStateBean;

import java.util.ArrayList;
import java.util.List;

/**
 * @author bjj
 * SecurityAlarmDialog
 * SecuritySettingDialog
 */
public class DoorSecurityUtil {
    private static List<OnSecurityChangedListener> listeners = new ArrayList<>();

    public static void registerListener(OnSecurityChangedListener listener){
        if(listeners.contains(listener)){
            return;
        }
        listeners.add(listener);
    }

    public static void unRegisterLister(OnSecurityChangedListener listener){
        listeners.remove(listener);
    }


    public static void onSecurityMessage(IntercomManager.Intercom intercom, SmartHomeManager.SecurityDevice device, SmartHomeMessage message){
        if (TextUtils.equals(message.getCmd(), IntercomConstants.kSmarthomeState)
                || TextUtils.equals(message.getCmd(), IntercomConstants.kSmarthomeDevice)
                || TextUtils.equals(message.getCmd(), IntercomConstants.kSmarthomeSwitch)
                || TextUtils.equals(message.getCmd(), IntercomConstants.kSmarthomeQuery)) {
            int state = device.deviceConfig().security_state;
            noticeState(intercom.id,state, TextUtils.equals(message.getCmd(), IntercomConstants.kSmarthomeQuery));
        }
        else if (TextUtils.equals(message.getCmd(), IntercomConstants.kSmarthomeCancel)) {
            noticeCancelAlarm(intercom,device);
        }
    }

    public static void onSecurityAlarm(IntercomManager.Intercom intercom, SmartHomeManager.SecurityDevice device, SmartHomeMessage smartHomeMessage, SecurityMessage securityMessage) {
        if(securityMessage.getCmd().equalsIgnoreCase(DoorFinal.SECURITY_ALERT)){
            noticeAlarm(intercom,securityMessage.getState(),device);
        }
    }


    /**
     * 切换安防状态
     */
    public static void switchState(String familyDockSn, boolean isOn){
//         {"ack":false,"broadcast":false,"cmd":"switch","content":"eyJzZWN1cml0eV9zdGF0ZSI6MH0K","from":"1497234257325658","proxy_id":"1496136497079886","result":0,"sn":"","source":4,"to":"security"}
//         其中base64为：
//         {"security_state":1}
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyDockSn);
        if(intercom == null){
            return;
        }
        SmartHomeManager smartHomeManager = intercom.smartHomeManager;
        if(smartHomeManager == null){
            return;
        }
        List<SmartHomeManager.SecurityDevice> devices = smartHomeManager.devices();
        if(devices.isEmpty()){
            return;
        }
        for(SmartHomeManager.SecurityDevice device : devices){
            smartHomeManager.switchDefence(device);
        }
    }

    /**
     * 查询安防状态
     */
    public static void queryState(String familyDockSn){
        //{"ack":false,"broadcast":false,"cmd":"query","from":"1497234257325658","proxy_id":"1496136497079886","result":0,"sn":"","source":4,"to":"security"}
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyDockSn);
        if(intercom == null){
            return;
        }
        SmartHomeManager smartHomeManager = intercom.smartHomeManager;
        if(smartHomeManager == null){
            return;
        }
        List<SmartHomeManager.SecurityDevice> devices = smartHomeManager.devices();
        if(devices.isEmpty()){
            noticeState(familyDockSn, SecurityStateBean.STATE_OFFLINE,true);
            return;
        }
        for(SmartHomeManager.SecurityDevice device : devices){
            smartHomeManager.queryState(device);
        }
    }

    /**
     * 取消报警
     */
    public static void cancelWarning(String familyDockSn){
        //{"ack":false,"broadcast":false,"cmd":"cancel","from":"1497234257325658","proxy_id":"1496136497079886","result":0,"sn":"","source":4,"to":"security"}
        IntercomManager.Intercom intercom = IntercomManager.getInstance().getIntercom(familyDockSn);
        if(intercom == null){
            return;
        }
        SmartHomeManager smartHomeManager = intercom.smartHomeManager;
        if(smartHomeManager == null){
            return;
        }
        List<SmartHomeManager.SecurityDevice> devices = smartHomeManager.devices();
        if(devices.isEmpty()){
            return;
        }
        for(SmartHomeManager.SecurityDevice device : devices){
            smartHomeManager.turnOffAlarm(device);
        }
    }

    private static void noticeAlarm(IntercomManager.Intercom intercom, List<SecurityMessage.StateBean> stateBeans, SmartHomeManager.SecurityDevice device){
    }

    private static void noticeCancelAlarm(IntercomManager.Intercom intercom, SmartHomeManager.SecurityDevice device){
    }

    private static void noticeState(String familyDockSn, int state, boolean isFromQuery){
        for(OnSecurityChangedListener listener : listeners){
            listener.onStateChanged(familyDockSn,state,isFromQuery);
        }
    }

    public interface OnSecurityChangedListener{

        void onStateChanged(String familyDockSn, int state, boolean isFromQuery);

    }
}
