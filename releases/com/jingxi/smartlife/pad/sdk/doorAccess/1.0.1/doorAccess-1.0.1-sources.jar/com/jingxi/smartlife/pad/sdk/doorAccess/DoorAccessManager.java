package com.jingxi.smartlife.pad.sdk.doorAccess;

import android.view.SurfaceView;

import com.intercom.sdk.IntercomObserver;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorDevice;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorRecordBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.DoorAccessConversationUI;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.DoorAccessListUI;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.DoorAccessListener;

import java.util.List;

public abstract class DoorAccessManager {
    private static DoorAccessManager instance;

    public static DoorAccessManager getInstance(){
        if(instance == null){
            synchronized (DoorAccessManager.class){
                if(instance == null){
                    instance = new DoorAccessManagerImpl();
                }
            }
        }
        return instance;
    }

    /**
     * 设备列表页面时监听设备变化
     * @param listener
     */
    abstract void setListUIListener(DoorAccessListUI listener);

    /**
     * 会话页面时监听新事件
     * @param listener
     */
    abstract void setConversationUIListener(DoorAccessConversationUI listener);

    /**
     * 监听开锁和呼叫事件
     * @param listener
     */
    abstract void setDoorAccessListener(DoorAccessListener listener);

    /**
     *
     * @param familyID      初始化对应的门禁
     * @param buttonKey
     */
    abstract void initAccess(String familyID, String buttonKey);

    /**
     *
     * @param familyID      反初始化对应的门禁
     */
    abstract void unInitAccess(String familyID);

    /**
     * 获取所有在线的设备
     * @return
     */
    abstract List<DoorDevice> getDevices(String familyID);

    /**
     * 获取设备在线状态
     */
    abstract void checkDeviceOnline(String familyID);

    /**
     * 外呼
     * @return sessionId
     */
    abstract String monitor(String familyID, DoorDevice doorDevice);

    /**
     * 接听呼叫
     */
    abstract void acceptCall(String sessionId);

    /**
     * 挂断呼叫
     */
    abstract void hangupCall(String sessionId);

    /**
     * 更新门禁呼叫视图
     * @param surfaceView
     */
    abstract void updateCallWindow(String sessionId, SurfaceView surfaceView);

    /**
     * 获取回放列表
     * @param type {@link DoorRecordBean#RECORD_TYPE_DOOR} or {@link DoorRecordBean#RECORD_TYPE_P2P}
     * @param pageStart     数据的起始下标 0 ...{n}
     * @param pageSize      每次获取到的数据量
     */
    abstract List<DoorRecordBean> getHistoryList(String familyID, @DoorRecordBean.RECORD_TYPE int type, int pageStart, int pageSize);

    /**
     * 开始回放
     */
    abstract void startPlayBack(String sessionId);

    /**
     * 暂停回放
     */
    abstract void pausePlayBack(String sessionId);

    /**
     * 调整回放进度
     */
    abstract void seekPlayBack(String sessionId, int seek);

    /**
     * 更新回放视图
     * @param surfaceView
     */
    abstract void updatePlayBackWindow(String sessionId, SurfaceView surfaceView);

    /**
     * 回放记录的监听
     * @param onPlaybackListener
     */
    abstract void addPlayBackListener(IntercomObserver.OnPlaybackListener onPlaybackListener);

    /**
     * 删除回放监听
     * @param onPlaybackListener
     */
    abstract void removePlayBackListener(IntercomObserver.OnPlaybackListener onPlaybackListener);
}
