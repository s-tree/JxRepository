package com.intercom.sdk;

import android.os.Bundle;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 读写INI文件，包含Windows格式和Unix格式
 * Windows格式 ：
 * [section]
 * key=value
 * Unix格式没有section，我们使用""标识默认Section
 */

public class INIWriter {
    //key=value
    public static int kTypeValue = 0;
    //comment, ; or #开头的注释语句
    public static int kTypeComment = 1;

    private boolean withBOM;

    public List<Section> sections;

    public INIWriter() {
        this.sections = new ArrayList<>();
        this.withBOM = false;
    }

    public boolean isWithBOM() {
        return this.withBOM;
    }

    public static byte[] readFileToBytes(File file) {
        int size = (int) file.length();
        if (size < 1)
            return null;

        byte[] bytes = new byte[size];
        BufferedInputStream buf = null;
        int result = 0;
        try {
            buf = new BufferedInputStream(new FileInputStream(file));
            result = buf.read(bytes, 0, bytes.length);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (buf != null) {
                try {
                    buf.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return result == size ? bytes : null;
    }

    public static String readFileToString(File file) {
        byte[] bytes = readFileToBytes(file);
        if (bytes == null)
            return null;

        if (hasUTF8BOM(bytes))
            return new String(bytes, 3, bytes.length - 3, StandardCharsets.UTF_8);
        return new String(bytes, StandardCharsets.UTF_8);
    }

    public void initFromBytes(byte[] stream) {
        String input;
        this.withBOM = hasUTF8BOM(stream);

        if (this.withBOM) {
            input = new String(stream, 3, stream.length - 3, StandardCharsets.UTF_8);
        } else {
            input = new String(stream, StandardCharsets.UTF_8);
        }
        parser(input);
    }

    public void initFromFile(File file) {
        byte[] bytes = readFileToBytes(file);
        if (bytes != null) {
            initFromBytes(bytes);
        }
    }

    public void clear() {
        this.sections.clear();
    }

    public void add(String name,
                    String key,
                    String value) {
        for (Section section : sections) {
            if (section.name.equalsIgnoreCase(name)) {
                section.add(key, value);
                return;
            }
        }
        Section section = new Section(name);
        section.add(key, value);
        sections.add(section);
    }

    public void addComment(String name,
                           String key,
                           String comment) {
        for (Section section : sections) {
            if (section.name.equalsIgnoreCase(name)) {
                section.addComment(key, comment);
                break;
            }
        }
    }

    public void commentKey(String name,
                           String key) {
        for (Section section : sections) {
            if (section.name.equalsIgnoreCase(name)) {
                section.commentKey(key);
                break;
            }
        }
    }

    public void remove(String name,
                       String key) {
        for (Section section : sections) {
            if (section.name.equalsIgnoreCase(name)) {
                section.remove(key);
                break;
            }
        }
    }

    public String toString() {
        StringBuilder output = new StringBuilder();
        for (Section section : sections) {
            if (section.isEmpty())
                continue;
            output.append(section.toString());
        }
        return output.toString();
    }

    public boolean commit(File file, boolean force_bom) {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        if (force_bom) {
            output.write(0xef);
            output.write(0xbb);
            output.write(0xbf);
        }
        boolean result = false;
        try {
            for (Section section : sections) {
                if (section.isEmpty())
                    continue;
                output.write(section.toString().getBytes(StandardCharsets.UTF_8));
            }
            result = writeFile(file, output.toByteArray());
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                output.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return result;
    }


    public Bundle getSection(String name) {
        for (Section section : sections) {
            if (section.name.equalsIgnoreCase(name)) {
                Bundle bundle = new Bundle();
                for (KVBean bean : section.kv) {
                    if (bean.type == kTypeComment) continue;
                    bundle.putString(bean.key, bean.value);
                }
                return bundle;
            }
        }
        return null;
    }

    public List<String> getKeySet(String name) {
        List<String> l = new ArrayList<>();
        for (Section section : sections) {
            if (section.name.equalsIgnoreCase(name)) {
                for (KVBean bean : section.kv) {
                    if (bean.type == kTypeComment) continue;
                    l.add(bean.key);
                }
                break;
            }
        }
        return l;
    }

    public String getValue(String name, String key) {
        for (Section section : sections) {
            if (section.name.equalsIgnoreCase(name)) {
                for (KVBean bean : section.kv) {
                    if (bean.type == kTypeComment)
                        continue;
                    if (bean.key.equalsIgnoreCase(key))
                        return bean.value;
                }
            }
        }
        return null;
    }

    private void parser(String stream) {
        Section section = new Section("");
        StringTokenizer t = new StringTokenizer(stream, "\r\n");
        while (t.hasMoreTokens()) {
            String line = t.nextToken();
            if (line.charAt(0) == '[') {
                String name = getSectionName(line);
                if (!name.equalsIgnoreCase(section.name)) {
                    if (!section.isEmpty()) {
                        sections.add(section);
                    }
                    section = new Section(name);
                }
            } else {
                section.addLine(line);
            }
        }
        if (!section.isEmpty()) {
            sections.add(section);
        }
    }

    public static class Section {
        public String name;
        public List<KVBean> kv;

        public Section(String name) {
            this.name = name;
            this.kv = new ArrayList<>();
        }

        public void addLine(String line) {
            KVBean bean = new KVBean();
            if (line.charAt(0) == '#' || line.charAt(0) == ';') {
                bean.key = line;
                bean.type = kTypeComment;
            } else if (!splitKeyValue(line, bean)) {
                bean.key = line;
                bean.type = kTypeComment;
            }
            kv.add(bean);
        }

        public void add(String key, String value) {
            for (KVBean bean : kv) {
                if (bean.type == kTypeComment)
                    continue;

                if (bean.key.equalsIgnoreCase(key)) {
                    bean.value = value;
                    return;
                }
            }

            KVBean bean = new KVBean();
            bean.key = key;
            bean.value = value;
            kv.add(bean);
        }

        public void commentKey(String key) {
            for (KVBean bean : kv) {
                if (bean.type == kTypeComment)
                    continue;

                if (bean.key.equalsIgnoreCase(key)) {
                    bean.type = kTypeComment;
                    bean.key = String.format("#%s=%s", bean.key, bean.value);
                    bean.value = "";
                    return;
                }
            }
        }

        public void addComment(String key, String comment) {
            List<KVBean> l = new ArrayList<>();
            boolean found = false;
            for (int i = 0; i < kv.size(); ++i) {
                if (kv.get(i).type == kTypeComment) {
                    l.add(kv.get(i));
                    continue;
                }
                if (!found && kv.get(i).key.equalsIgnoreCase(key)) {
                    boolean processed = false;
                    if (i > 0) {
                        if (kv.get(i - 1).type == kTypeComment
                                && kv.get(i - 1).key.equalsIgnoreCase(comment)) {
                            processed = true;
                        }
                    }
                    if (!processed) {
                        KVBean bean = new KVBean();
                        bean.key = comment;
                        bean.type = kTypeComment;
                        l.add(bean);
                    }
                    found = true;
                }
                l.add(kv.get(i));
            }
            kv = l;
        }

        public void remove(String key) {
            for (KVBean bean : kv) {
                if (bean.type == kTypeComment)
                    continue;
                if (bean.key.equalsIgnoreCase(key)) {
                    kv.remove(bean);
                    break;
                }
            }
        }

        public String toString() {
            StringBuilder output = new StringBuilder();
            if (!name.isEmpty()) {
                output.append(String.format("[%s]\r\n", name));
            }
            for (KVBean bean : kv) {
                if (bean.type == kTypeComment) {
                    output.append(String.format("%s\r\n", bean.key));
                } else {
                    output.append(String.format("%s=%s\r\n", bean.key, bean.value));
                }
            }
            return output.toString();
        }

        public boolean isEmpty() {
            return kv.isEmpty();
        }
    }


    public static class KVBean {
        public String key;
        public String value;
        public int type;

        public KVBean() {
            this.type = kTypeValue;
        }
    }

    private static boolean splitKeyValue(String line, KVBean bean) {
        /*
        StringTokenizer it = new StringTokenizer(line, "=");
        if (it.countTokens() < 1)
            return false;

        bean.key = it.nextToken().trim();
        if (it.hasMoreTokens()) {
            bean.value = it.nextToken().trim();
        }
        return true;
        */
        int idx = line.indexOf('=');
        if(idx < 0)
            return false;
        bean.key = line.substring(0,idx);
        if(idx != line.length()-1)
            bean.value = line.substring(idx+1,line.length());
        return true;
    }

    private static String getSectionName(String line) {
        String result;
        int idx = line.indexOf(']', 1);
        if (idx < 0)
            result = line.substring(1);
        else
            result = line.substring(1, idx);
        return result.trim();
    }

    private static boolean hasUTF8BOM(byte[] str) {
        if (str.length < 3)
            return false;
        return (str[0] & 0xFF) == 0xEF
                && (str[1] & 0xFF) == 0xBB
                && (str[2] & 0xFF) == 0xBF;
    }

    private static boolean makeSureFile(File file) {
        if (!file.exists()) {
            file.getParentFile().mkdirs();
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }
        }
        return true;
    }

    private static boolean writeFile(File file, byte[] bytes) {
        if (!makeSureFile(file))
            return false;

        FileOutputStream fos = null;
        boolean result = false;

        try {
            fos = new FileOutputStream(file);
            fos.write(bytes);
            result = true;
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                    result = false;
                }
            }
        }
        return result;
    }
}
