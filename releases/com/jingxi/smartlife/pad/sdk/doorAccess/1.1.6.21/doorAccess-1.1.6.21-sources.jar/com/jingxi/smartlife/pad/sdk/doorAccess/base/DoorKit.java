package com.jingxi.smartlife.pad.sdk.doorAccess.base;

import com.intercom.sdk.IntercomConstants;

public class DoorKit {

    /**
     * 初始化一些参数
     *
     * @param options
     */
    public static void init(Options options) {
        if (options == null) {
            return;
        }
        DoorConfigs.options = options;
    }

    public static Options getOptions() {
        return DoorConfigs.options;
    }

    public static class Options {
        protected static Options getDefault() {
            return new Options();
        }

        private Options() {

        }

        /**
         * {@link com.intercom.sdk.IntercomConstants.NetClientSubType}
         * 默认是平板
         * 平板是 NetClientSubTypePad
         * 移动端是 NetClientSubTypeMobile
         */
        public int platform = IntercomConstants.NetClientSubType.NetClientSubTypePad;

        /**
         * 室内通使用
         * 该设备的备注
         */
        public String alias = null;

        /**
         * 一个唯一值，用于此设备的id，如不传，则为程序生成
         */
        public String clientID = null;

        /**
         * 最大可保存的记录数量
         */
        public int maxRecordCount = 50;

        /**
         * 离线推送的ali
         */
        public String publishID = "";

        /**
         * 代理服务器地址
         */
        public String proxyServerUrl = DoorConfigs.PROXY_SERVER_URL;

        /**
         * 代理服务器重连
         */
        public int proxyRetryInterval = 5;

        /**
         * 代理服务器心跳间隔
         */
        public int proxykeepalive = 30;

        /**
         * 渠道
         */
        public String channel = DoorConfigs.APP_CHANNEL;

        /**
         * 门禁服务工作的存储空间目录
         */
        public String doorAccessWorkDir = DoorConfigs.PATH;

        /**
         * 门禁服务的注册服务器
         */
        public String intercomServerUrl = DoorConfigs.INTERCOM_SERVER_URL;
        /**
         * 证书路径
         */
        public String sslCertPath       = DoorConfigs.sslCertPath;

        public String deviceMonitorUrl = DoorConfigs.DEVICE_MONITOR_URL;
    }
}
