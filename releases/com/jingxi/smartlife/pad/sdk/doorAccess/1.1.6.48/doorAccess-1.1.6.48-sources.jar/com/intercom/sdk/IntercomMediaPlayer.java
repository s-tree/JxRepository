package com.intercom.sdk;

import android.os.Bundle;
import android.view.Surface;

import com.intercom.base.Log;

import java.lang.ref.WeakReference;

/**
 * 门禁记录回放类
 */
public class IntercomMediaPlayer {

    private static final String TAG = "player";

    private final WeakReference<IntercomManager> manager;

    private String session_id;

    private boolean local_audio_enable;

    private boolean remote_audio_enable;

    private boolean started;

    public IntercomMediaPlayer(IntercomManager manager,
                               String session_id) {
        this.manager = new WeakReference<>(manager);
        this.session_id = session_id;
        this.local_audio_enable = true;
        this.remote_audio_enable = true;
        this.started = false;
    }

    @Override
    protected void finalize() {
        stop();
    }

    private boolean sendCommand(Bundle bundle) {
        IntercomManager manager = this.manager.get();
        if (manager != null) {
            return manager.sendAppCommand(bundle);
        }
        Log.v(TAG, "sendCommand failed");
        return false;
    }

    public String getSession_id() {
        return session_id;
    }

    public void setSession_id(String session_id) {
        this.session_id = session_id;
    }

    public boolean start() {
        if (this.started)
            return true;

        Bundle bundle = new Bundle();
        bundle.putString("scheme", IntercomConstants.kMediaPlayScheme);
        bundle.putString("command", "start");
        bundle.putString("session_id", session_id);
        this.started = sendCommand(bundle);
        return this.started;
    }

    /**
     * 在销毁对象之前，必须stop，否则底层不会销毁
     *
     * @return
     */
    public boolean stop() {
        if (!this.started)
            return true;

        Bundle bundle = new Bundle();
        bundle.putString("scheme", IntercomConstants.kMediaPlayScheme);
        bundle.putString("command", "stop");
        bundle.putString("session_id", session_id);
        boolean result = sendCommand(bundle);
        this.started = false;
        return result;
    }

    /**
     * @param local:true: 表示录制的时候室内机的声音，false: 表示室外机的声音
     * @return
     */
    public boolean switchAudio(boolean local) {
        Bundle message = new Bundle();
        message.putString("track", local ? "local" : "remote");

        if (local) {
            this.local_audio_enable = !this.local_audio_enable;
            message.putBoolean("enable", this.local_audio_enable);
        } else {
            this.remote_audio_enable = !this.remote_audio_enable;
            message.putBoolean("enable", this.remote_audio_enable);
        }

        Bundle bundle = new Bundle();
        bundle.putString("scheme", IntercomConstants.kMediaPlayScheme);
        bundle.putString("session_id", session_id);
        bundle.putString("command", "switch");
        bundle.putString("message", BundleToJSON.toString(message));
        return sendCommand(bundle);
    }

    /**
     * @param progress :百分比
     */
    public boolean seek(int progress) {
        Bundle bundle = new Bundle();
        bundle.putString("scheme", IntercomConstants.kMediaPlayScheme);
        bundle.putString("session_id", session_id);
        bundle.putString("command", "seek");
        bundle.putInt("progress", progress);
        return sendCommand(bundle);
    }

    /**
     * @param surface:null将不再渲染，同时clear画面为黑色
     * @return:
     */
    public boolean updateSurface(Surface surface) {
        IntercomManager manager = this.manager.get();
        if (manager == null)
            return false;
        return manager.updatePlaybackSurface(session_id, surface);
    }
}
