package com.jingxi.smartlife.pad.sdk.doorAccess.base.utils;

import android.media.AudioAttributes;
import android.media.SoundPool;
import android.util.ArrayMap;

import com.jingxi.smartlife.pad.sdk.doorAccess.R;
import com.jingxi.smartlife.pad.sdk.utils.JXContextWrapper;


public class SoundUtil {

    public interface SoundKey{

        String KEY = "key";
        String BELL = "bell";
        String CANCEL = "cancel";
        String DEPLOY_DONE = "deploy_done";
        String RESET_DEVICE = "reset_device";
        String SECURITY_OFF = "security_off";
        String SECURITY_ON = "security_on";
        String SERVICE_NOT_CONFIG = "service_not_config";
        String SERVICE_START = "service_start";
        String SERVICE_STOP = "service_stop";
        String STARTUP = "startup";
        String WARNING = "warnning";
    }

    private static SoundUtil instance;
    private ArrayMap<String,Integer> sounds = new ArrayMap<>();

    public static SoundUtil getInstance(){
        if(instance == null){
            synchronized (SoundUtil.class){
                if(instance == null){
                    instance = new SoundUtil();
                }
            }
        }
        return instance;
    }

    private SoundPool soundPool;
    private int lastStreamId = 0;

    private SoundUtil(){
        AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
        soundPool = new SoundPool.Builder().setMaxStreams(2).setAudioAttributes(audioAttributes).build();
        sounds.put(SoundKey.KEY,soundPool.load(JXContextWrapper.context, R.raw.key,1));
        sounds.put(SoundKey.BELL,soundPool.load(JXContextWrapper.context, R.raw.bell,1));
        sounds.put(SoundKey.CANCEL,soundPool.load(JXContextWrapper.context, R.raw.cancel,1));
        sounds.put(SoundKey.DEPLOY_DONE,soundPool.load(JXContextWrapper.context, R.raw.deploy_done,1));
        sounds.put(SoundKey.RESET_DEVICE,soundPool.load(JXContextWrapper.context, R.raw.reset_device,1));
        sounds.put(SoundKey.SECURITY_OFF,soundPool.load(JXContextWrapper.context, R.raw.security_off,1));
        sounds.put(SoundKey.SECURITY_ON,soundPool.load(JXContextWrapper.context, R.raw.security_on,1));
        sounds.put(SoundKey.SERVICE_NOT_CONFIG,soundPool.load(JXContextWrapper.context, R.raw.service_not_config,1));
        sounds.put(SoundKey.SERVICE_START,soundPool.load(JXContextWrapper.context, R.raw.service_start,1));
        sounds.put(SoundKey.SERVICE_STOP,soundPool.load(JXContextWrapper.context, R.raw.service_stop,1));
        sounds.put(SoundKey.STARTUP,soundPool.load(JXContextWrapper.context, R.raw.startup,1));
        sounds.put(SoundKey.WARNING,soundPool.load(JXContextWrapper.context, R.raw.warnning,1));
    }

    public void playButton(String keyName){
        if(!sounds.containsKey(keyName)){
            return;
        }
        releaseLastSound();
        try {
            lastStreamId = soundPool.play(sounds.get(keyName),1,1,0,0,1);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
    }

    private void releaseLastSound(){
        if(lastStreamId != 0){
            soundPool.stop(lastStreamId);
        }
    }

}
