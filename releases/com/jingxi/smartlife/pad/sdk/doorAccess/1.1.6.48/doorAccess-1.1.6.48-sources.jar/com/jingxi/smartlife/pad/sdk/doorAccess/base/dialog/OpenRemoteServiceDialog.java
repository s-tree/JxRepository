package com.jingxi.smartlife.pad.sdk.doorAccess.base.dialog;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;
import android.view.WindowManager;

import com.intercom.sdk.IntercomManager;
import com.jingxi.smartlife.pad.sdk.doorAccess.R;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorKit;
import com.jingxi.smartlife.pad.sdk.utils.JXContextWrapper;

public class OpenRemoteServiceDialog extends BaseChildLibDialog implements View.OnClickListener{

    private static OpenRemoteServiceDialog instance = null;

    public static synchronized void showDialog(){
        if(instance == null){
            instance = new OpenRemoteServiceDialog(JXContextWrapper.context);
        }
        if(instance.isShowing()){
            return;
        }
        instance.show();
    }

    private View cancel,confirm;

    /**
     * 对话框
     *
     * @param context 上下文
     */
    public OpenRemoteServiceDialog(@NonNull Context context) {
        super(context);
        getWindow().setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
    }

    @Override
    protected int[][] getChildViewPrefenceWidth() {
        return null;
    }

    @Override
    protected int[][] getChildViewPrefenceHeight() {
        int[][] childHeight = new int[2][2];
        childHeight[0][0] = R.id.buttomLinear;
        childHeight[0][1] = 30;

        childHeight[1][0] = R.id.dialog_message;
        childHeight[1][1] = 70;
        return childHeight;
    }

    @Override
    public void getChildViews(View rootView) {
        cancel = rootView.findViewById(R.id.cancel);
        confirm = rootView.findViewById(R.id.confirm);
        cancel.setOnClickListener(this);
        confirm.setOnClickListener(this);
    }

    @Override
    protected boolean getHideInput() {
        return true;
    }

    @Override
    protected float getWidth() {
        return 0.4f;
    }

    @Override
    protected float getHeight() {
        return 0.35f;
    }

    @Override
    protected int getLayoutResID() {
        return R.layout.layout_dialog_remoteservice;
    }

    @Override
    protected boolean getCanceledOnTouchOutside() {
        return true;
    }

    @Override
    public int getWindowType() {
        return WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;
    }

    @Override
    public void onClick(View v) {
        dismiss();
        if(v.getId() == R.id.confirm){
            IntercomManager.getInstance().startService(DoorKit.getOptions().remoteServiceConf);
        }
    }
}
