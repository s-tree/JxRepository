package com.jingxi.smartlife.pad.sdk.doorAccess.base.dialog;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by Administrator on 2018/6/13.
 */

public abstract class BaseChildLibDialog extends BaseLibDialog {
    /**
     * 对话框
     *
     * @param context 上下文
     */
    public BaseChildLibDialog(@NonNull Context context) {
        super(context);
        getChildViews(rootView);
        setChildWidthAndHeight(rootView,width,height);
        darkFillScreen();
    }

    /**
     * 子布局相对rootView的宽度
     * @return  int[][] view的id  |  相对的比例，例如  0.3 -> 30
     */
    protected abstract int[][] getChildViewPrefenceWidth();

    protected abstract int[][] getChildViewPrefenceHeight();

    public abstract void getChildViews(View rootView);

    private void setChildWidthAndHeight(View root, float rootWidth, float rootHeight){
        int[][] widthBili = getChildViewPrefenceWidth();
        if(widthBili != null && widthBili.length > 0){
            for(int i = 0 ; i < widthBili.length ; i++){
                View child = root.findViewById(widthBili[i][0]);
                if(child == null){
                    continue;
                }
                ViewGroup.LayoutParams params = child.getLayoutParams();
                params.width = (int) (rootWidth * widthBili[i][1] / 100);
            }
        }

        int[][] heightBili = getChildViewPrefenceHeight();
        if(heightBili != null && heightBili.length > 0){
            for(int i = 0 ; i < heightBili.length ; i++){
                View child = root.findViewById(heightBili[i][0]);
                if(child == null){
                    continue;
                }
                ViewGroup.LayoutParams params = child.getLayoutParams();
                params.height = (int) (rootHeight * heightBili[i][1] / 100);
            }
        }
    }
}
