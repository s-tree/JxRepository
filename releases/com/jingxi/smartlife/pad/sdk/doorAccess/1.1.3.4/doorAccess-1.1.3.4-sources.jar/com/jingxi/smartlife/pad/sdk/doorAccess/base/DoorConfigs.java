package com.jingxi.smartlife.pad.sdk.doorAccess.base;

import com.intercom.sdk.IntercomConfigure;
import com.intercom.sdk.IntercomConstants;

import java.util.HashMap;
import java.util.Map;

public class DoorConfigs {
    private static final String APP_CHANNEL = "jx_dr";
    public static final String DOOR_LOG_TAG = "door";
    private static final String PATH = "sdcard/data/doorkeeper/access/";//文件保存路径
    public static String MEDIA_DIR = PATH + "record/";
    private static final String NO_VIDEO_JPG = "novideo.jpg";
    private static final String INTERCOM_SERVER_URL = "http://120.77.237.47:7070/opensip/v2/register";
    private static final String PROXY_MULTICAST_ADDRESS = "238.18.18.1";
    private static final String PROXY_SERVER_URL = "http://120.77.237.47:16888";

    protected static int CLIENT_TYPE = IntercomConstants.NetClientSubType.NetClientSubTypePad;

    protected static String alias = null;

    protected static String clientID = null;

    public static int maxRecordCount = 50;

    /**
     * 初始化完成后保存的 familyID - clientID 对应表
     */
    protected static Map<String,String> clientIds = new HashMap<>();

    /**
     * {@link IntercomConstants.NetClientSubType}
     */
    public static void setClientType(int type){
        CLIENT_TYPE = type;
    }

    protected static String getAppConf() {
        IntercomConfigure.AppConf appConf = new IntercomConfigure.AppConf(APP_CHANNEL,
                PATH,
                MEDIA_DIR, true, IntercomConstants.LogLevel.Info);
        return appConf.toJson();
    }

    protected static String getIntercomConfig() {
        return new IntercomConfigure.IntercomConfig().toJson();
    }

    protected static byte[][] getNoVideoImage() {
        return null;
//        byte[][] arr = new byte[1][];
//        arr[0] = utils.readResourceFromFile(BaseA, NO_VIDEO_JPG);
//        return arr;
    }

    protected static String getClientConf(String familyDockSN,String buttonKey) {
        IntercomConfigure.ClientConf clientConf = new IntercomConfigure.ClientConf(
                IntercomConstants.NetClientType.NetClientTypeClient,
                CLIENT_TYPE,
                clientID,
                familyDockSN,
                buttonKey,
                alias,
                "");
        return clientConf.toJson();
    }

    protected static String getOtherConf() {
        IntercomConfigure.OtherConf otherConf = new IntercomConfigure.OtherConf(
                "30000,35000,40000",
                null,
                null);
        return otherConf.toJson();
    }

    protected static String getProxyConfig() {
        return new IntercomConfigure.ProxyConf(10000,
                PROXY_MULTICAST_ADDRESS,
                60,
                true,
                true,
                PROXY_SERVER_URL,
                "",
                "",
                5,
                300).toJson();
    }

    protected static String getServerConfig() {
        return new IntercomConfigure.ServerConfig(
                INTERCOM_SERVER_URL,
                "",
                "",
                "",
                0).toJson();
    }
}
