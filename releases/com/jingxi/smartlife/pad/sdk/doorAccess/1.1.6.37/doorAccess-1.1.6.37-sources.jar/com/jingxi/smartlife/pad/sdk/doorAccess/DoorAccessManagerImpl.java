package com.jingxi.smartlife.pad.sdk.doorAccess;

import android.view.SurfaceView;

import com.intercom.sdk.IntercomManager;
import com.intercom.sdk.IntercomObserver;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorDeviceManager;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorInitUtil;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorManagerUtil;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorMessageFactory;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorSecurityUtil;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.DoorSessionManager;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.Observers.DoorMessageDispatcher;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorDevice;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.DoorRecordBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.bean.ExtDeviceBean;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.orm.DoorAccessOrmUtil;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.DoorAccessConversationUI;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.DoorAccessListUI;
import com.jingxi.smartlife.pad.sdk.doorAccess.base.ui.DoorAccessListener;

import java.util.List;

public final class DoorAccessManagerImpl extends DoorAccessManager {

    protected DoorAccessManagerImpl(){
        DoorInitUtil.getInstance().initDoorAccess();
    }

    @Override
    public void setListUIListener(DoorAccessListUI listener) {
        DoorSessionManager.setListUI(listener);
    }

    @Override
    public void addConversationUIListener(DoorAccessConversationUI listener) {
        DoorSessionManager.addConversationUI(listener);
    }

    @Override
    public void removeConversationUIListener(DoorAccessConversationUI listener) {
        DoorSessionManager.removeConversationUI(listener);
    }

    @Override
    public void setDoorAccessListener(DoorAccessListener listener) {
        DoorMessageDispatcher.setDoorListener(listener);
    }

    @Override
    public void setExtDeviceChangedListener(DoorDeviceManager.OnExtDeviceChanged onExtDeviceChanged) {
        DoorDeviceManager.setOnExtDeviceChanged(onExtDeviceChanged);
    }

    @Override
    public void init() {
        DoorInitUtil.getInstance().initDoorAccess();
    }

    @Override
    public void unInit() {
        DoorInitUtil.getInstance().unInitDoorAccess();
    }

    @Override
    public boolean isProxyOffline(String familyID) {
        return DoorDeviceManager.isProxyOffline(familyID);
    }

    @Override
    public void startFamily(String familyID, String buttonKey) {
        DoorInitUtil.startFamily(familyID,buttonKey);
    }

    @Override
    public void stopAllFamily() {
        DoorManagerUtil.stopAllProxy();
    }

    @Override
    public void stopFamily(String familyID) {
        DoorInitUtil.stopFamily(familyID);
    }

    @Override
    public boolean isSupportP2P(String familyID) {
        return DoorDeviceManager.getP2PDeviceID(familyID) != null;
    }

    @Override
    public String monitor(String familyID,DoorDevice doorDevice) {
        return DoorManagerUtil.monitor(familyID,doorDevice);
    }

    @Override
    public String monitorP2P(String familyID, String calledNumber) {
        return DoorManagerUtil.callP2POut(familyID,calledNumber);
    }

    @Override
    public List<DoorDevice> getDevices(String familyID) {
        return DoorDeviceManager.getFamilyDevices(familyID);
    }

    /**
     * 获取设备在线状态
     */
    @Override
    public void checkDeviceOnline(String familyID){
        DoorDeviceManager.checkDeviceOnline(familyID);
    }

    @Override
    public void acceptCall(String sessionId) {
        DoorManagerUtil.pickUp(
                DoorSessionManager.getCurrentIntercom(sessionId),
                sessionId);
    }

    @Override
    public void hangupCall(String sessionId) {
        DoorManagerUtil.hangUp(
                DoorSessionManager.getCurrentIntercom(sessionId),
                sessionId);
    }

    @Override
    public void hangupCall(String sessionId, int result) {
        DoorManagerUtil.hangUp(DoorSessionManager.getCurrentIntercom(sessionId),sessionId, result);
    }

    @Override
    public void updateCallWindow(String sessionId,SurfaceView surfaceView) {
        DoorManagerUtil.updateRemoteSurface(
                DoorSessionManager.getCurrentIntercom(sessionId),
                sessionId,
                surfaceView);
    }

    @Override
    public void enableLocalToRemoteAudio(String familyID,String sessionId, boolean isEnable) {
        DoorManagerUtil.enableLocalAudio(familyID,sessionId,isEnable);
    }

    @Override
    public void enableRemoteToLocalAudio(String familyID,String sessionId, boolean isEnable) {
        DoorManagerUtil.enableRemoteAudio(familyID,sessionId,isEnable);
    }

    @Override
    public void enableLocalToRemoteVideo(String familyID,String sessionId,boolean isEnable){
        DoorManagerUtil.enableLocalVideo(familyID,sessionId,isEnable);
    }

    @Override
    public void updateLocalWindow(SurfaceView surfaceView) {
        DoorManagerUtil.updateLocalSurface(surfaceView);
    }

    @Override
    public String getHangupMessageByResult(int result) {
        return DoorMessageFactory.getHangupMessage(result);
    }

    @Override
    public List<DoorRecordBean> getHistoryListByType(String familyID,@DoorRecordBean.RECORD_TYPE int type,int pageStart,int pageSize) {
        return DoorAccessOrmUtil.queryRecordsByType(familyID,type,pageStart,pageSize);
    }

    @Override
    public List<DoorRecordBean> getHistoryListByDevice(String familyID,DoorDevice doorDevice,boolean needCallOut, int pageStart,int pageSize) {
        return DoorAccessOrmUtil.queryRecordsByDevice(familyID,doorDevice,needCallOut,pageStart,pageSize);
    }

    @Override
    public void deleteRecord(DoorRecordBean recordBean) {
        DoorAccessOrmUtil.deleteRecord(recordBean);
    }

    @Override
    public void deleteListRecord(List<DoorRecordBean> recordBeans) {
        DoorAccessOrmUtil.deleteListRecord(recordBeans);
    }

    @Override
    public void deleteAllByType(String familyID, int type) {
        DoorAccessOrmUtil.deleteAllByType(familyID,type);
    }

    @Override
    public void startPlayBack(String sessionId) {
        DoorManagerUtil.startPlayBack(sessionId);
    }

    @Override
    public void pausePlayBack(String sessionId) {
        DoorManagerUtil.stopPlayBack(sessionId);
    }

    @Override
    public void seekPlayBack(String sessionId,int seek) {
        DoorManagerUtil.seekPlayBack(sessionId,seek);
    }

    @Override
    public void updatePlayBackWindow(String sessionId,SurfaceView surfaceView) {
        DoorManagerUtil.updatePlayBackSurface(sessionId,surfaceView);
    }

    @Override
    public void addPlayBackListener(IntercomObserver.OnPlaybackListener onPlaybackListener) {
        DoorManagerUtil.addPlayBackListener(onPlaybackListener);
    }

    @Override
    public void removePlayBackListener(IntercomObserver.OnPlaybackListener onPlaybackListener){
        DoorManagerUtil.removePlayBackListener(onPlaybackListener);
    }

    @Override
    public void openDoor(String sessionID) {
        DoorManagerUtil.openDoor(DoorSessionManager.getCurrentIntercom(sessionID),sessionID);
    }

    @Override
    public boolean isSupportSecurity(String familyID) {
        return DoorDeviceManager.isSupportSecurity(familyID);
    }

    @Override
    public void addSecurityListener(DoorSecurityUtil.OnSecurityChangedListener listener) {
        DoorSecurityUtil.registerListener(listener);
    }

    @Override
    public void removeSecurityListener(DoorSecurityUtil.OnSecurityChangedListener listener) {
        DoorSecurityUtil.unRegisterLister(listener);
    }

    @Override
    public void switchSecurityStatus(String familyID) {
        DoorSecurityUtil.switchState(familyID);
    }

    @Override
    public int querySecurityStatus(String familyID) {
        return DoorSecurityUtil.queryState(familyID);
    }

    @Override
    public void cancelSecurityWarning(String familyID) {
        DoorSecurityUtil.cancelWarning(familyID);
    }

    @Override
    public boolean isSupportExt(String familyID) {
        return DoorDeviceManager.isSupportExt(familyID);
    }

    @Override
    public List<ExtDeviceBean> getExtDevices(String familyID,String buttonKey) {
        return DoorDeviceManager.getExtDevices(familyID,buttonKey);
    }

    @Override
    public String callExt(String familyID,ExtDeviceBean extDeviceBean, boolean isMonitor) {
        return DoorManagerUtil.callExtOut(familyID,extDeviceBean,isMonitor);
    }

    @Override
    public void resumeDoorAccess() {
        DoorManagerUtil.reStartAllProxy();
    }

    @Override
    public void check() {
        DoorInitUtil.getInstance().copyCertFiles();
    }

    @Override
    public void sendPushMessage(String message) {
        IntercomManager.getInstance().sendPushMessage(message);
    }

    @Override
    public void takeSnapshot(String familyId, String sessionId) {
        DoorManagerUtil.takeSnapshot(familyId, sessionId);
    }

    @Override
    public void enablePreview(boolean enable) {
        DoorManagerUtil.enablePreview(enable);
    }
}
