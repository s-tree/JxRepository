package com.intercom.sdk;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.Surface;

import com.google.gson.Gson;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 门禁的接口，包含一个或者多个Intercom实例
 * 每个Intercom实例表示一个家庭
 */
public class IntercomManager {

    private static final String TAG = "manager";

    private boolean initialized = false;

    private final IntercomAppCallbackHandler callback;

    private final Map<String, Intercom> intercoms;

    public final IntercomObserver.IntercomAppListener    app_listener;
    public final IntercomObserver.PlaybackListener       playback_listener;
    public final IntercomObserver.IntercomClientListener client_listener;
    public final IntercomObserver.IntercomListener       intercom_listener;
    public final IntercomObserver.ProxyListener          proxy_listener;
    public final IntercomObserver.SmartHomeListener      smarthome_listener;

    private static IntercomManager instance;

    public static IntercomManager getInstance() {
        if (instance == null) {
            synchronized (IntercomManager.class) {
                if (instance == null) {
                    instance = new IntercomManager();
                }
            }
        }
        return instance;
    }

    public IntercomManager() {
        this.callback = new IntercomAppCallbackHandler(this);
        this.playback_listener = new IntercomObserver.PlaybackListener();
        this.app_listener = new IntercomObserver.IntercomAppListener();
        this.client_listener = new IntercomObserver.IntercomClientListener();
        this.intercom_listener = new IntercomObserver.IntercomListener();
        this.proxy_listener = new IntercomObserver.ProxyListener();
        this.smarthome_listener = new IntercomObserver.SmartHomeListener();
        this.intercoms = new HashMap<>();
    }

    /**
     * 初始化门禁系统，需要提供基本的配置参数
     */
    public boolean initialize(Context context,
                              String app_conf,
                              String intercom_conf,
                              byte[][] arrays) {
        if (initialized)
            return true;
        initialized = nativeAppInitialize(context, app_conf, intercom_conf, arrays);
        return initialized;
    }

    /**
     * 卸载门禁所有资源
     */
    public void unInitialize() {
        if (initialized) {
            List<Intercom> tempList = new ArrayList<>(intercoms.values());
            for (Intercom icom : tempList) {
                icom.unInitialize();
            }
            intercoms.clear();
            nativeAppUnInitialize();
            initialized = false;
        }
    }

    /**
     * 添加一个门禁实例
     */
    public boolean addIntercom(String id,
                               String client_conf,
                               String other_conf) {
        if (!initialized)
            return false;

        if (intercoms.containsKey(id)) {
            return true;
        }

        Intercom intercom = new Intercom(this, id);

        if (intercom.initialize(client_conf, other_conf)) {
            intercoms.put(id, intercom);
            return true;
        }
        return false;
    }

    public void removeIntercom(String id) {
        Intercom intercom = intercoms.get(id);
        if (intercom != null) {
            intercom.unInitialize();
            intercoms.remove(id);
        }
    }

    public Intercom getIntercom(String id) {
        if (id == null) {
            if (intercoms.isEmpty())
                return null;
            List<Intercom> tempList = new ArrayList<>(intercoms.values());
            for (Intercom value : tempList) {
                return value;
            }
        }
        return intercoms.get(id);
    }

    public Collection<Intercom> getAllIntercom(){
        if(intercoms != null){
            return intercoms.values();
        }
        return new ArrayList<>();
    }

    /**
     * native层的通知
     *
     * @param bundle
     */
    private void onNativeAppMessageEvent(Bundle bundle) {
        if (callback != null) {
            Message m = new Message();
            m.what = 0;
            m.setData(bundle);
            callback.sendMessage(m);
        }
    }

    private static class IntercomAppCallbackHandler extends Handler {
        private final WeakReference<IntercomManager> manager;

        //package-private
        IntercomAppCallbackHandler(IntercomManager manager) {
            this.manager = new WeakReference<>(manager);
        }

        @Override
        public void handleMessage(Message message) {
            IntercomManager manager = this.manager.get();
            if (manager != null && message.what == 0) {
                manager.onAppMessageEvent(message.getData());
            } else {
                super.handleMessage(message);
            }
        }
    }


    /**
     * java层对底层消息的解析，整个事件的解析和分发都在这里完成
     *
     * @param bundle
     */
    void onAppMessageEvent(Bundle bundle) {

        if (bundle.containsKey("$id$")) {
            //某个家庭的消息
            String id = bundle.getString("$id$");
            Intercom intercom = getIntercom(id);
            if (intercom != null) {
                intercom.onIntercomMessageEvent(bundle);
            }
            return;
        }

        String scheme = bundle.getString("scheme");
        if (scheme == null || !bundle.containsKey("event"))
            return;

        int event = bundle.getInt("event");

        if (scheme.equalsIgnoreCase(IntercomConstants.kMediaPlayScheme)) {
            /*
             * 回放的事件解析和分发
             */
            String session_id = bundle.getString("session_id");
            long value = bundle.getLong("value");

            this.playback_listener.onMediaPlayEvent(session_id, event, value);

        } else if (scheme.equalsIgnoreCase(IntercomConstants.kMCUScheme)) {
            if (event == IntercomConstants.MCUEvent.Event_MCU_Message) {
                int type = bundle.getInt("type");
                boolean ack = bundle.getBoolean("ack");
                int result = bundle.getInt("result");
                String message = bundle.getString("message");
                this.app_listener.onMCUMessageArrival(type, ack, result, message);
            } else if (event == IntercomConstants.MCUEvent.Event_MCU_State_Changed) {
                boolean online = bundle.getBoolean("online");
                this.app_listener.onMCUStateChanged(online);
            } else if (event == IntercomConstants.MCUEvent.Event_MCU_Button_Event) {
                int type = bundle.getInt("type");
                String id = bundle.getString("id");
                String sound = bundle.getString("sound");
                this.app_listener.onButtonEvent(type, id, sound);
            } else if (event == IntercomConstants.MCUEvent.Event_MCU_Button_Click) {
                String id = bundle.getString("id");
                this.app_listener.onButtonClick(id);
            }
        } else if (scheme.equalsIgnoreCase(IntercomConstants.kAppScheme)) {
            if (event == IntercomConstants.AppEvent.Event_Media_Device_State_Changed) {
                int media_type = bundle.getInt("media_type");
                int state = bundle.getInt("state");
                this.app_listener.onIntercomMediaDeviceStateChanged(media_type, state);
            } else if (event == IntercomConstants.AppEvent.Event_App_Initialized) {
                boolean result = bundle.getBoolean("result");
                this.app_listener.onIntercomAppIntialized(result);
            }
        }
    }

    public boolean startMCU(String button_conf,
                            String mcu_conf) {
        if (!initialized)
            return false;
        return nativeMCUStart(button_conf, mcu_conf);
    }

    public void stopMCU() {
        if (!initialized)
            return;
        nativeMCUStop();
    }

    public boolean switchLight(boolean on, int delay_ms, boolean force) {
        Bundle bundle = new Bundle();
        bundle.putString("scheme", IntercomConstants.kMCUScheme);
        bundle.putString("command", "light_switch");
        bundle.putBoolean("on", on);
        bundle.putBoolean("force", force);
        bundle.putInt("delay", delay_ms);
        return nativeAppCommand(bundle);
    }

    public boolean lockLight(boolean enable) {
        Bundle bundle = new Bundle();
        bundle.putString("scheme", IntercomConstants.kMCUScheme);
        bundle.putString("command", "light_lock");
        bundle.putBoolean("enable", enable);
        return nativeAppCommand(bundle);
    }

    public boolean writeMCU(int type, boolean ack, int result, String message) {
        Bundle bundle = new Bundle();
        bundle.putString("scheme", IntercomConstants.kMCUScheme);
        bundle.putString("command", "message");
        bundle.putInt("type", type);
        bundle.putBoolean("ack", ack);
        bundle.putInt("result", result);
        bundle.putString("message", message);
        return nativeAppCommand(bundle);
    }

    public boolean switchCamera(String name) {
        Bundle bundle = new Bundle();
        bundle.putInt("type", 1);
        bundle.putString("value", name);

        Bundle message = new Bundle();
        message.putString("scheme", "app");
        message.putString("command", "switch_camera");
        message.putString("message", BundleToJSON.toString(bundle));
        return nativeAppCommand(message);
    }

    public boolean sendPushMessage(String message) {
        Bundle bundle = new Bundle();
        bundle.putBoolean("push", true);
        bundle.putString("message", message);
        return nativeAppMessage(bundle);
    }

    public boolean updatePlaybackSurface(String session_id,
                                         Surface surface) {
        return nativeUpdatePlaybackSurface(session_id, surface);
    }

    public boolean updatePreviewSurface(Surface surface) {
        return nativeUpdatePreviewSurface(surface);
    }

    public boolean sendAppCommand(Bundle bundle) {
        return nativeAppCommand(bundle);
    }

    public boolean sendAppMessage(Bundle bundle) {
        return nativeAppMessage(bundle);
    }

    /**
     * 创建一个回放的对象，需要用户自行销毁
     *
     * @param session_id
     * @return
     */
    public IntercomMediaPlayer createMediaPlayer(String session_id) {
        return new IntercomMediaPlayer(this, session_id);
    }

    /**
     * 回放用的player，需要手动创建
     */
    public IntercomMediaPlayer backPlayer;

    /**
     * 创建一个回放的对象，需要用户自行销毁
     *
     * @param session_id
     * @return
     */
    public IntercomMediaPlayer getMediaPlayer(String session_id) {
        if (backPlayer == null) {
            backPlayer = new IntercomMediaPlayer(this, session_id);
        } else if (!TextUtils.equals(session_id, backPlayer.getSession_id())) {
            /**
             * 本地需要播放的session 跟之前的不一样，就先stop
             */
            backPlayer.stop();
            backPlayer.setSession_id(session_id);
        }
        return backPlayer;
    }

    /**
     * 枚举回放记录，返回名称列表，不包含目录名
     *
     * @param work_dir
     * @return
     */
    public static String[] enumeratorRecord(String work_dir) {
        return nativeEnumeratorRecord(work_dir);
    }

    public static String getVersion() {
        return nativeGetVersion();
    }

    /**
     * 生成一个会话id，在callout时候使用
     *
     * @return
     */
    public static String createSessionId() {
        return nativeCreateSessionId();
    }

    /**
     * base64编解码，对IntercomManger相关接口中出现的base64编解码，均需要使用这个接口
     * 不能使用第三方提供的库
     *
     * @param encode
     * @param content
     * @return
     */
    public static String base64(boolean encode, String content) {
        if(encode && TextUtils.isEmpty(content)){
            return content;
        }
        return nativeBase64(encode, content);
    }

    /**
     * 3des加解密
     *
     * @param encode
     * @param key
     * @param content
     * @return
     */
    public static byte[] encode(boolean encode, String key, byte[] content) {
        return nativeEncode(encode, key, content);
    }

    public static String QueryLocalFamilyId(String server_work_dir) {
        return nativeQueryLocalFamilyId(server_work_dir);
    }

    public static String DecodeFamilyId(String content) {
        return nativeDecodeFamilyId(content);
    }

    public static class Intercom implements IntercomClientManager.OnInternalIntercomClientListener,
            IntercomSessionManager.OnInternalIntercomSessionListener,
            SmartHomeManager.OnInternalIntercomSmartHomeListener {

        public final  IntercomClientManager          clientManager;
        public        IntercomSessionManager         sessionManager;
        public        SmartHomeManager               smartHomeManager;
        private final WeakReference<IntercomManager> manager;

        public final String    id;
        private      NetClient netClient;
        private      String    last_button_message_time;


        private Intercom(IntercomManager manager, String id) {
            this.manager = new WeakReference<>(manager);
            this.id = id;
            this.netClient = null;
            this.clientManager = new IntercomClientManager(this);
            this.sessionManager = null;
            this.smartHomeManager = null;
            this.last_button_message_time = null;
        }

        public boolean initialize(String client_conf,
                                  String other_conf) {
            IntercomManager manager = this.manager.get();
            if (manager == null)
                return false;
            return manager.nativeCreateIntercom(id, client_conf, other_conf);
        }

        public void unInitialize() {
            IntercomManager manager = this.manager.get();
            if (manager != null)
                manager.nativeDestroyIntercom(id);
            clientManager.cleanup();
            sessionManager = null;
            smartHomeManager = null;
            netClient = null;
        }

        public NetClient getNetClient() {
            return this.netClient;
        }

        public boolean startProxy(String proxy_conf) {
            IntercomManager manager = this.manager.get();
            if (manager == null)
                return false;
            return manager.nativeProxyStart(this.id, proxy_conf);
        }

        public void stopProxy() {
            IntercomManager manager = this.manager.get();
            if (manager != null)
                manager.nativeProxyStop(this.id);

            clientManager.cleanup();
        }

        public boolean startIntercom(String server_conf) {
            IntercomManager manager = this.manager.get();
            if (manager == null)
                return false;
            return manager.nativeIntercomStart(this.id, server_conf);
        }

        /**
         * 停止对讲系统
         */
        public void stopIntercom() {
            sessionManager.hangUpAll();
            IntercomManager manager = this.manager.get();
            if (manager != null)
                manager.nativeIntercomStop(this.id);
        }

        /**
         * 终端允许远程配置代理，可以配置的项目有：
         * delay_alert_mobile:(int),当有新的呼叫，代理延迟多久通知云端的移动端，代理在部署之后，默认为10s
         * do_not_alert_mobile_if_pickup:(boolean),当延迟通知移动端之前，如果有终端已经接听，是否继续通知移动端，默认为不通知(true)
         * enable_multi_client:(boolean)，是否支持多终端接听，这里只是为了测试，默认是不允许的
         * disable_indoor_client_unlock:(boolean)，是否禁止室内机（平板和底座）开锁，默认不禁止。使用场景是：如果只是针对某些特定人群独自在家，家长
         * 可以通过手机/平板之类的禁止室内机开门，确保安全性
         * disable_indoor_client_unlock:(boolean)：禁止室内机开锁，代理会检查
         * force_delete_session_if_hangup:(boolean)：只要有人挂断，就挂断整个会话
         * disable_indoor_intercom:(boolean)：禁止室内机门禁功能，禁止之后，外呼会失败，访客呼叫收不到
         * disable_mobile_client_unlock:(boolean)：禁止移动端开锁功能，这个应该只能在平板上设置，移动端不能设置
         * <p>
         * 如果禁止了室内机接听，移动端的延迟通知随之失效，变成立即通知
         * 如果无法连接外网，disable_indoor_intercom会失效
         * <p>
         * 除了unlock/disable_indoor_intercom之外，其他的都可以在代理中预先配置好
         * <p>
         * 这些配置在代理重启之后就会恢复默认值，并不会持久化
         * 上述各项可以单独设置，最后打包成json通过下述方法发送即可
         */

        public boolean sendIntercomConfigure(int router,
                                             NetClient net_client, //代理
                                             String configure) {
            IntercomMessage message = new IntercomMessage();
            message.setCmd(IntercomConstants.kIntercomCommandConfigure);
            if (this.netClient != null) {
                message.setFrom(this.netClient.getClient_id());
            }
            message.setClient_id(net_client.getClient_id());
            message.setContent(configure);

            Bundle bundle = new Bundle();
            bundle.putString("scheme", IntercomConstants.kIntercomScheme);
            bundle.putInt("router", router);
            boolean result = false;
            try {
                Gson g = new Gson();
                String client_string = g.toJson(net_client);
                String message_string = g.toJson(message);
                bundle.putString("client", client_string);
                bundle.putString("message", message_string);
                result = this.sendIntercomMessage(bundle);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        }

        public boolean sendIntercomMessage(Bundle bundle) {
            IntercomManager manager = this.manager.get();
            if (manager == null)
                return false;
            return manager.nativeIntercomMessage(this.id, bundle);
        }

        public boolean sendIntercomCommand(Bundle bundle) {
            IntercomManager manager = this.manager.get();
            if (manager == null)
                return false;
            return manager.nativeIntercomCommand(this.id, bundle);
        }

        public boolean updateSurface(String session_id,
                                     Surface surface) {
            IntercomManager manager = this.manager.get();
            if (manager == null)
                return false;
            return manager.nativeUpdateSurface(this.id, session_id, surface);
        }

        private void onIntercomMessageEvent(Bundle bundle) {
            String scheme = bundle.getString("scheme");
            if (scheme == null || !bundle.containsKey("event"))
                return;

            int event = bundle.getInt("event");

            if (scheme.equalsIgnoreCase("client")) {
                if (event == 0) {
                    boolean result = bundle.getBoolean("result");
                    String client_string = null;
                    if (bundle.containsKey("client")) {
                        client_string = bundle.getString("client");
                    }
                    if (client_string != null) {
                        this.netClient = new Gson().fromJson(client_string, NetClient.class);
                        this.sessionManager = new IntercomSessionManager(this, this.netClient.getClient_id());
                        this.smartHomeManager = new SmartHomeManager(this, this.netClient);
                    }
                    IntercomManager manager = this.manager.get();
                    if (manager != null) {
                        manager.client_listener.onIntercomClientInitializeResult(this, result);
                    }
                }
            } else if (scheme.equalsIgnoreCase(IntercomConstants.kProxyScheme)) {
                /*
                 * 代理消息解析和分发
                 */
                if (event == IntercomConstants.IntercomProxyEvent.IntercomProxyEventProxyStateChanged) {

                    /*
                     * 代理上下线通知
                     */
                    int router = bundle.getInt("router");
                    boolean online = bundle.getBoolean("online");
                    String client_string = bundle.getString("client");
                    String device_string = bundle.getString("device");

                    IntercomClientManager.IntercomProxy proxy = IntercomClientManager.IntercomProxy.create(router,
                            client_string,
                            device_string);
                    if (proxy != null) {
                        this.clientManager.updateProxy(router, online, proxy);
                        if (this.smartHomeManager != null) {
                            this.smartHomeManager.onProxyStateChanged(router, online, proxy);
                        }
                    }

                } else if (event == IntercomConstants.IntercomProxyEvent.IntercomProxyEventClientStateChanged) {
                    /*
                     * 终端上下线通知
                     */
                    int router = bundle.getInt("router");
                    boolean online = bundle.getBoolean("online");
                    String client_string = bundle.getString("client");
                    String client_id = bundle.getString("client_id");//this is proxy id;
                    this.clientManager.updateClient(router, online, client_id, client_string);

                } else if (event == IntercomConstants.IntercomProxyEvent.IntercomProxyEventInternetProxyStateChanged) {
                    /**
                     * internet状态发生变化
                     */
                    boolean online = bundle.getBoolean("connect");
                    this.clientManager.changeInternetState(online);
                    IntercomManager manager = this.manager.get();
                    if (manager != null) {
                        manager.proxy_listener.onIntercomInternetStateChanged(this, online);
                    }
                }
            } else if (scheme.equalsIgnoreCase(IntercomConstants.kIntercomScheme)) {
                /**
                 * 门禁对讲消息解析和分发
                 */
                if (event == IntercomConstants.IntercomEvent.IntercomEventMessage) {
                    /**
                     * 收到门禁会话消息
                     */
                    int router = bundle.getInt("router");
                    String client_string = bundle.getString("client");
                    String message_string = bundle.getString("message");
                    NetClient netClient = new Gson().fromJson(client_string, NetClient.class);
                    IntercomMessage message = new Gson().fromJson(message_string, IntercomMessage.class);
                    IntercomManager manager = this.manager.get();
                    if (manager != null) {
                        manager.intercom_listener.onIntercomMessageArrival(this, router, netClient, message);
                    }

                } else if (event == IntercomConstants.IntercomEvent.IntercomVideoReady) {
                    /**
                     * 会话的视频已经到达，可以创建快照了
                     */
                    String session_id = bundle.getString("session_id");
                    IntercomManager manager = this.manager.get();
                    if (manager != null) {
                        manager.intercom_listener.onIntercomVideoReady(this, session_id);
                    }

                } else if (event == IntercomConstants.IntercomEvent.IntercomSnapshotReady) {

                    String session_id = bundle.getString("session_id");
                    String filename = bundle.getString("filename");
                    IntercomManager manager = this.manager.get();
                    if (manager != null) {
                        manager.intercom_listener.onIntercomSnapshotReady(this, session_id, filename);
                    }

                } else if (event == IntercomConstants.IntercomEvent.IntercomSipStateChanged) {

                    String proxy = bundle.getString("proxy");
                    int state = bundle.getInt("state");
                    IntercomManager manager = this.manager.get();
                    if (manager != null) {
                        manager.intercom_listener.onIntercomSipStateChanged(this, proxy, state);
                    }

                } else if (event == IntercomConstants.IntercomEvent.IntercomDtmfReady) {

                } else if (event == IntercomConstants.IntercomEvent.IntercomStreamStateChanged) {

                    String session_id = bundle.getString("session_id");
                    int media_type = bundle.getInt("media_type");
                    int state = bundle.getInt("state");
                    IntercomManager manager = this.manager.get();
                    if (manager != null) {
                        manager.intercom_listener.onIntercomStreamStateChanged(this, session_id, media_type, state);
                    }

                } else if (event == IntercomConstants.IntercomEvent.IntercomStreamTransportStarted) {

                    String session_id = bundle.getString("session_id");
                    int media_type = bundle.getInt("media_type");
                    IntercomManager manager = this.manager.get();
                    if (manager != null) {
                        manager.intercom_listener.onStreamTransportStart(this, session_id, media_type);
                    }

                } else if (event == IntercomConstants.IntercomEvent.IntercomStreamTransportStatistics) {
                    String session_id = bundle.getString("session_id");
                    int media_type = bundle.getInt("media_type");
                    int interval = bundle.getInt("interval");
                    long total_recv = bundle.getLong("total_recv");
                    long total_send = bundle.getLong("total_send");
                    IntercomManager manager = this.manager.get();
                    if (manager != null) {
                        manager.intercom_listener.onIntercomTransportStatistics(this, session_id, media_type, interval, total_recv, total_send);
                    }
                } else if (event == IntercomConstants.IntercomEvent.IntercomStreamTransportIceNegotiation) {
                    String session_id = bundle.getString("session_id");
                    int media_type = bundle.getInt("media_type");
                    int result = bundle.getInt("result");
                    IntercomManager manager = this.manager.get();
                    if (manager != null) {
                        manager.intercom_listener.onIntercomTransportIceNegotiationResult(this, session_id, media_type, result);
                    }
                }
            } else if (scheme.equalsIgnoreCase(IntercomConstants.kButtonScheme)) {
                /*
                 * 按键消息
                 */
                if (event == IntercomConstants.IntercomProxyEvent.IntercomProxyEventMessage) {
                    int router = bundle.getInt("router");
                    String client_string = bundle.getString("client");
                    String message_string = bundle.getString("message");
                    NetClient netClient = new Gson().fromJson(client_string, NetClient.class);
                    ButtonMessage message = new Gson().fromJson(message_string, ButtonMessage.class);
                    String time = message.getTime();
                    if (time != null && last_button_message_time != null && last_button_message_time.equalsIgnoreCase(time)) {
                        return;
                    }
                    last_button_message_time = time;

                    IntercomManager manager = this.manager.get();
                    if (manager != null) {
                        manager.proxy_listener.onIntercomButtonMessageArrival(this, router, netClient, message);
                    }
                }
            } else if (scheme.equalsIgnoreCase(IntercomConstants.kSmarthomeScheme)) {
                /*
                 * 智能家居消息
                 */
                if (event == IntercomConstants.IntercomProxyEvent.IntercomProxyEventMessage) {
                    int router = bundle.getInt("router");
                    String client_string = bundle.getString("client");
                    String message_string = bundle.getString("message");
                    NetClient netClient = new Gson().fromJson(client_string, NetClient.class);
                    SmartHomeMessage message = new Gson().fromJson(message_string, SmartHomeMessage.class);
                    if (netClient != null && message != null && this.smartHomeManager != null) {
                        this.smartHomeManager.onMessageArrival(router, netClient, message);
                    }
                }

            } else {
                /*
                 * 未知消息，可以用来扩展
                 */
                IntercomManager manager = this.manager.get();
                if (manager != null) {
                    manager.proxy_listener.onIntercomProxyMessageArrival(this, bundle);
                }
            }
        }

        public void onIntercomProxyStateChanged(String proxy_id,
                                                boolean online) {
            IntercomManager manager = this.manager.get();
            if (manager != null) {
                manager.proxy_listener.onIntercomProxyStateChanged(this, proxy_id, online);
            }
        }

        public void onIntercomProxyOnlineStateChanged(String proxy_id,
                                                      int router,
                                                      boolean online) {
            IntercomManager manager = this.manager.get();
            if (manager != null) {
                manager.proxy_listener.onIntercomProxyOnlineStateChanged(this, proxy_id, router, online);
            }
        }

        public void onIntercomClientStateChanged(String client_id,
                                                 boolean online) {
            IntercomManager manager = this.manager.get();
            if (manager != null) {
                manager.proxy_listener.onIntercomClientStateChanged(this, client_id, online);
            }
        }

        public void onIntercomClientOnlineStateChanged(String client_id,
                                                       String proxy_id,
                                                       int router,
                                                       boolean online) {
            IntercomManager manager = this.manager.get();
            if (manager != null) {
                manager.proxy_listener.onIntercomClientOnlineStateChanged(this, client_id, proxy_id, router, online);
            }
        }

        public void onSmartHomeSecurityDeviceStateChanged(SmartHomeManager.SecurityDevice device,
                                                          boolean online) {
            IntercomManager manager = this.manager.get();
            if (manager != null) {
                manager.smarthome_listener.onSmartHomeSecurityDeviceStateChanged(this, device, online);
            }
        }

        public void onSmartHomeSecurityDeviceOnlineStateChanged(SmartHomeManager.SecurityDevice device,
                                                                int router,
                                                                boolean online) {
            IntercomManager manager = this.manager.get();
            if (manager != null) {
                manager.smarthome_listener.onSmartHomeSecurityDeviceOnlineStateChanged(this, device, router, online);
            }
        }

        public void onSmartHomeMessage(SmartHomeManager.SecurityDevice device,
                                       SmartHomeMessage message) {
            IntercomManager manager = this.manager.get();
            if (manager != null) {
                manager.smarthome_listener.onSmartHomeMessage(this, device, message);
            }
        }

        public void onSmartHomeAlarm(SmartHomeManager.SecurityDevice device,
                                     SmartHomeMessage smartHomeMessage,
                                     SecurityMessage securityMessage) {
            IntercomManager manager = this.manager.get();
            if (manager != null) {
                manager.smarthome_listener.onSmartHomeAlarm(this, device, smartHomeMessage, securityMessage);
            }
        }
    }


    private native boolean nativeAppInitialize(Context context,
                                               String app_conf,
                                               String intercom_conf,
                                               byte[][] arrays);

    private native void nativeAppUnInitialize();


    private native boolean nativeMCUStart(String button_conf,
                                          String mcu_conf);

    private native void nativeMCUStop();

    private native boolean nativeUpdatePlaybackSurface(String session_id,
                                                       Surface surface);

    private native boolean nativeUpdatePreviewSurface(Surface surface);

    private native boolean nativeAppCommand(Bundle bundle);

    private native boolean nativeAppMessage(Bundle bundle);

    private static native String[] nativeEnumeratorRecord(String root_dir);

    private static native String nativeGetVersion();

    private static native String nativeCreateSessionId();

    private static native String nativeBase64(boolean encode, String content);

    private static native byte[] nativeEncode(boolean encode, String key, byte[] content);

    private static native String nativeQueryLocalFamilyId(String server_work_dir);

    private static native String nativeDecodeFamilyId(String content);

    //intercom JNI接口
    private native boolean nativeCreateIntercom(String id,
                                                String client_conf,
                                                String other_conf);

    private native void nativeDestroyIntercom(String id);

    private native boolean nativeProxyStart(String id,
                                            String proxy_conf);

    private native void nativeProxyStop(String id);

    private native boolean nativeIntercomStart(String id,
                                               String server_conf);

    private native void nativeIntercomStop(String id);

    private native boolean nativeIntercomMessage(String id,
                                                 Bundle bundle);

    private native boolean nativeIntercomCommand(String id,
                                                 Bundle bundle);

    private native boolean nativeUpdateSurface(String id,
                                               String session_id,
                                               Surface surface);

    static {
        System.loadLibrary("intercom");
    }
}
