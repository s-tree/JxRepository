package com.intercom.sdk;

import android.text.TextUtils;

import com.google.gson.Gson;

/**
 * from : 1496136497079886
 * to : 1496136497079881
 * cmd : invite
 * client_id : 1496136497079886
 * result : 0
 * ack : false
 * username : 0101101
 * session_id : 1496789106154438
 * record : false
 * audio : false
 * video : false
 * version : 1
 * content : whoami
 * contact : {"ice":"120.25.197.113:5060","account":"test_001@120.25.197.113"}
 * sdp : {"audio_address":"172.18.18.3:12344","video_address":"172.18.18.3.12346","audio_format":"InJ0cCI6IHRydWUsImNvZGVjIjogIlVMQVciLCJmb3JtYXQiOiAiODAwMDoxOjE2IiwidHMiOjMyMCwiZGlyIjoyLCJwdCI6MCxldmVudF9wdDoxMDEsZHRtZjoiKiIsIm1hcmsiOnRydWU=","video_format":"InJ0cCI6dHJ1ZSwiY29kZWMiOiJoMjY0IiwidHMiOjM2MDAsInciOjY0MCwiaCI6NDgwLCJleHRyYV9kYXRhIjoieHh4eCIsInBhY2tldGl6ZXIiOjEsImRpciI6MiwgInB0Ijo5NywiZWFybHlfbWVkaWEiOnRydWU="}
 */

public class IntercomMessage implements Cloneable {
    private String from;
    private String to;
    private String cmd;
    private String client_id;
    private int result;
    private boolean ack;
    private String username;
    private String device_name;
    private String session_id;
    private boolean record;
    private boolean audio;
    private boolean video;
    private int version;
    private String content;
    private ContactBean contact;
    private SdpBean sdp;

    public IntercomMessage() {
        version = 2;
    }

    @Override
    public Object clone() {
        IntercomMessage sc = null;
        try {
            sc = (IntercomMessage) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        return sc;
    }

  public IntercomMessage clone(boolean isExChangeFromAndTo, String cmd){
    IntercomMessage message = (IntercomMessage) clone();
    message.setAck(false);
    if(isExChangeFromAndTo){
      message.setFrom(getTo());
      message.setTo(getFrom());
    }
    if(!TextUtils.isEmpty(cmd))
      message.setCmd(cmd);
    return message;
  }

  public static IntercomMessage objectFromData(String str) {

        return new Gson().fromJson(str, IntercomMessage.class);
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public String getCmd() {
        return cmd;
    }

    public void setCmd(String cmd) {
        this.cmd = cmd;
    }

    public String getClient_id() {
        return client_id;
    }

    public void setClient_id(String client_id) {
        this.client_id = client_id;
    }

    public int getResult() {
        return result;
    }

    public void setResult(int result) {
        this.result = result;
    }

    public boolean isAck() {
        return ack;
    }

    public void setAck(boolean ack) {
        this.ack = ack;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDevice_name() {
        return device_name;
    }

    public void setDevice_name(String device_name) {
        this.device_name = device_name;
    }

    public String getSession_id() {
        return session_id;
    }

    public void setSession_id(String session_id) {
        this.session_id = session_id;
    }

    public boolean isRecord() {
        return record;
    }

    public void setRecord(boolean record) {
        this.record = record;
    }

    public boolean isAudio() {
        return audio;
    }

    public boolean isVideo() {
        return video;
    }

    public void setAudio(boolean audio) {
        this.audio = audio;
    }

    public void setVideo(boolean video) {
        this.video = video;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public ContactBean getContact() {
        return contact;
    }

    public void setContact(ContactBean contact) {
        this.contact = contact;
    }

    public SdpBean getSdp() {
        return sdp;
    }

  public void setSdp(SdpBean sdp) {
    this.sdp = sdp;
  }
  public boolean isP2p() {
    return this.from.equalsIgnoreCase("p2p");
  }

    public static class ContactBean {
        /**
         * ice : 120.25.197.113:5060
         * account : test_001@120.25.197.113
         */

        private String ice;
        private String account;

        public static ContactBean objectFromData(String str) {

            return new Gson().fromJson(str, ContactBean.class);
        }

        public String getIce() {
            return ice;
        }

        public void setIce(String ice) {
            this.ice = ice;
        }

        public String getAccount() {
            return account;
        }

        public void setAccount(String account) {
            this.account = account;
        }
    }

    public static class SdpBean {
        /**
         * audio_address : 172.18.18.3:12344
         * video_address : 172.18.18.3.12346
         * audio_format : InJ0cCI6IHRydWUsImNvZGVjIjogIlVMQVciLCJmb3JtYXQiOiAiODAwMDoxOjE2IiwidHMiOjMyMCwiZGlyIjoyLCJwdCI6MCxldmVudF9wdDoxMDEsZHRtZjoiKiIsIm1hcmsiOnRydWU=
         * video_format : InJ0cCI6dHJ1ZSwiY29kZWMiOiJoMjY0IiwidHMiOjM2MDAsInciOjY0MCwiaCI6NDgwLCJleHRyYV9kYXRhIjoieHh4eCIsInBhY2tldGl6ZXIiOjEsImRpciI6MiwgInB0Ijo5NywiZWFybHlfbWVkaWEiOnRydWU=
         */

        private String audio_address;
        private String video_address;
        private String audio_format;
        private String video_format;

        public static SdpBean objectFromData(String str) {

            return new Gson().fromJson(str, SdpBean.class);
        }

        public String getAudio_address() {
            return audio_address;
        }

        public void setAudio_address(String audio_address) {
            this.audio_address = audio_address;
        }

        public String getVideo_address() {
            return video_address;
        }

        public void setVideo_address(String video_address) {
            this.video_address = video_address;
        }

        public String getAudio_format() {
            return audio_format;
        }

        public void setAudio_format(String audio_format) {
            this.audio_format = audio_format;
        }

        public String getVideo_format() {
            return video_format;
        }

        public void setVideo_format(String video_format) {
            this.video_format = video_format;
        }
    }
}
